#!/bin/sh

# compress

dpkg -i /usr/local/middleware/gp/_gp_upgrade/package.deb

echo exit
