
/**
 *
 * 대시보드
 *
 */

(function () {

	$(function () {


		$("form").submit(function (e) {

			e.preventDefault();

			if ($("#userId").Empty(__("아이디를 입력하세요"))) return;
			if ($("#userPassword").Empty(__("비밀번호를 입력하세요"))) return;

			var params = new Params();
			params.put("userId", $("#userId").val());
			params.put("userPassword", $("#userPassword").val());

			// 로그인 요청
			ipc.send("authentication", params, function (res) {

				if (res.DM_RESULT == IPC.DM_RESULT_SUCCESS) {
					alert(__("로그인 되었습니다"));

					if (window.location.href.indexOf("?") == -1) window.location.href = "/Dashboard/Dashboard";
					else window.location.href = "/Intro/Step_01";
				} else {
					alert(__("로그인에 실패하였습니다"));
				}
			});
			
		});
	});
})();