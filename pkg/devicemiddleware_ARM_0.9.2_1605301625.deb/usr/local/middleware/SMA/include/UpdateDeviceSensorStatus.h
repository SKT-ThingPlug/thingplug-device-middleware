/**
 * @file UpdateDeviceSensorStatus.h
 *
 * @brief Update device sensor status command header
 *
 * Copyright (C) 2015. SPTek,All Rights Reserved.
 * Written 2015,by SPTek
 */

#ifndef __UPDATE_DEVICE_SENSOR_STATUS_H__
#define __UPDATE_DEVICE_SENSOR_STATUS_H__

#include "BaseCommand.h"
#include "SensorConfiguration.h"

/*
 ****************************************
 * Public Functions
 ****************************************
 */
int UpdateDeviceSensorStatus(SENSOR_ID_E target, char *data, int dataLength);
int UpdateDeviceSensorStatusCommandProcess(SPTekRECEIVE_MESSAGE_T *receiveMessage, char *contents, int length, SPTekSEND_MESSAGE_T
		*sendMessage);

#endif /* __UPDATE_DEVICE_SENSOR_STATUS_H__*/
