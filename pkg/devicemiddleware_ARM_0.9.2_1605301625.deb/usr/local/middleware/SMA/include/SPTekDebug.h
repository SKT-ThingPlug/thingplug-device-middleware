/*
 * SPT_Debug.h
 *
 *  Created on: 2015. 11. 16.
 *      Author: sidn
 */

#ifndef SPTEKDEBUG_H_
#define SPTEKDEBUG_H_

/* SPT_LOG_LEVEL
 * 로그 LEVEL을 설정한다.
 */
typedef enum tagSPTekLogLevel {
	LOG_LEVEL_NONE =0,
	LOG_LEVEL_VERBOSE,    // 모든 로그를 보여준다.
	LOG_LEVEL_DEBUG,
	LOG_LEVEL_INFO,
	LOG_LEVEL_WARM,
	LOG_LEVEL_ERROR,
	LOG_LEVEL_FATAL,
	LOG_LEVEL_DUMP,
	LOG_LEVER_MAX
} SPTekLOG_LEVEL_E;

typedef enum tagSPTekBooleanType {
	SPTekFalse = 0,
	SPTekTrue	
}SPTekBOOLEAN_TYPE_E;

#ifdef SPT_DEBUG_ENABLE
	#include <stdio.h>
    extern void DebugInit(SPTekBOOLEAN_TYPE_E enable, SPTekLOG_LEVEL_E level, FILE *stream);
	extern void DebugPrintf(const char *filename, int lineno, SPTekLOG_LEVEL_E level, const char *format, ...);
	extern void DebugDump(const char *title, const char* data, unsigned long lengths);

	#define SPTekDebugInit(enable, level, stream) DebugInit(enable, level, stream)
	#define SPTekDebugLog(level, ...)             DebugPrintf(__FILE__, __LINE__, level, ## __VA_ARGS__)
    #define SPTekDebugDump(title, data, lengths)  DebugDump(title, data, lengths)
#else
	#define SPTekDebugInit(enable, level, stream)        ((void)0)
	#define SPTekDebugLog(...)                           ((void)0)
    #define SPTekDebugDump(title, data, lengths)         ((void)0)
#endif

#endif /* SPTEKDEBUG_H_ */
