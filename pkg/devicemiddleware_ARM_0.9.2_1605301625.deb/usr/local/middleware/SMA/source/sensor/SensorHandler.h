/**
 * @file SensorHandler.h
 *
 * @brief Sensor handler header
 *
 * Copyright (C) 2015. SPTek,All Rights Reserved.
 * Written 2015,by SPTek 
 */

#ifndef __SENSOR_HANDLER_H__
#define __SENSOR_HANDLER_H__

#include "SensorConfiguration.h"

int SensorHandlerInit(int loadFlag,int argc, char* argv[]);

int SensorHandlerGetData(SENSOR_ID_E target, char *data, int *dataLength);
int SensorHandlerGetStatus(SENSOR_ID_E target,SENSOR_STATE_E *value);
int ControlSensor(SENSOR_ID_E target, char *control, int controlLength, char *result);

int RegisterSensorCommand(char commandTag, char *commandName, char* (*commandFunction)(char*));
int CancelSensorCommand(char *commandName);
int ExecuteSensorCommand(char *commandName, char *commandArg, char *result);
int ExecuteSensorCommandTag(char commandTag, char *commandArg, char *result);
int GetSensorCommandListCount(void);
char GetSensorCommandTagPosition(int position);
char *GetSensorCommandNamePosition(int position);

int SensorHandlerClose(void);

#endif//__SENSOR_HANDLER_H__

