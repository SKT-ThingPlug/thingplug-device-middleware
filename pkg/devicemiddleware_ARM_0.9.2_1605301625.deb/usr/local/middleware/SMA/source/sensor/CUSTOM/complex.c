/**
 * @file complex.c
 *
 * @brief COMPLEX Sensor Device Handler
 *
 * Copyright (C) 2015. SPTek,All Rights Reserved.
 * Written 2015,by SPTek
 */
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <string.h>
#include "complex.h"

/*
 ****************************************
 * Definition & Global Variable
 ****************************************
 */
#define BUFF_SIZE  128
#define FILE_NAME  "/sys/bus/w1/devices/28-0315030fecff/w1_slave"

static int gCOMPLEXNFd;

static char gDummyData[10][20] = 
	{"keyval0","keyval45","keyval67.5","keyval90","keyval11.5","keyval23.64","keyval57.5","keyval80","keyval20.5","keyval22.5"};
static int gIndex = 0;

/*
 ****************************************
 * COMPLEX device Main Handle Functions
 ****************************************
 */

/**
 * @brief COMPLEX device init function
 * @param[in] No parameter
 * @return	 0 => Success init
 * 		-1 => Error file open
 */
int COMPLEXInit(void)
{
	//gCOMPLEXNFd = open(FILE_NAME, O_RDONLY, S_IREAD);
	gIndex = 0;
	return 0;
}

/**
 * @brief COMPLEX device COMPLEX value read funciton
 * @param[in] SPTekSENSOR_INFO_T structure member mLastValue pointer
 * @return	 0 => Success read data
 * 		-3 => Error read operation
 * 		-4 => Error lseek operation
 */
int COMPLEXRead(char *data, int *len)
{
	strcpy(data,gDummyData[gIndex]);
	*len = strlen(data);
	gIndex++;
	gIndex %= 10;
	return 0;
}

/**
 * @brief COMPLEX device close funciton
 * @param[in] No parameter
 * @return 0 = default
 */
int COMPLEXClose(void)
{
	close(gCOMPLEXNFd);
	return 0;
}

/**
 * @brief COMPLEX Extract COMPLEX value
 * @param[in] Raw Data
 * @return 0 = COMPLEX Value
 */
int getCOMPLEXValue(char *data)
{
	return 0;
}

