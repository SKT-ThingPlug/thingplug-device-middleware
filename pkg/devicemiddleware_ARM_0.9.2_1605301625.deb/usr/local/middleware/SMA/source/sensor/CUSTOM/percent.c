/**
 * @file percent.c
 *
 * @brief PERCENT Sensor Device Handler
 *
 * Copyright (C) 2015. SPTek,All Rights Reserved.
 * Written 2015,by SPTek
 */
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <string.h>
#include "percent.h"

/*
 ****************************************
 * Definition & Global Variable
 ****************************************
 */
#define BUFF_SIZE  128
#define FILE_NAME  "/sys/bus/w1/devices/28-0315030fecff/w1_slave"

static int gPERCENTNFd;

static char gDummyData[10][20] = 
	{"22.5","45","67.5","90","11.5","23.64","57.5","80","20.5","22.5"};
static int gIndex = 0;

/*
 ****************************************
 * PERCENT device Main Handle Functions
 ****************************************
 */

/**
 * @brief PERCENT device init function
 * @param[in] No parameter
 * @return	 0 => Success init
 * 		-1 => Error file open
 */
int PERCENTInit(void)
{
	//gPERCENTNFd = open(FILE_NAME, O_RDONLY, S_IREAD);
	gIndex = 0;
	return 0;
}

/**
 * @brief PERCENT device PERCENT value read funciton
 * @param[in] SPTekSENSOR_INFO_T structure member mLastValue pointer
 * @return	 0 => Success read data
 * 		-3 => Error read operation
 * 		-4 => Error lseek operation
 */
int PERCENTRead(char *data, int *len)
{
	strcpy(data,gDummyData[gIndex]);
	*len = strlen(data);
	gIndex++;
	gIndex %= 10;
	return 0;
}

/**
 * @brief PERCENT device close funciton
 * @param[in] No parameter
 * @return 0 = default
 */
int PERCENTClose(void)
{
	close(gPERCENTNFd);
	return 0;
}

/**
 * @brief PERCENT Extract PERCENT value
 * @param[in] Raw Data
 * @return 0 = PERCENT Value
 */
int getPERCENTValue(char *data)
{
	return 0;
}

