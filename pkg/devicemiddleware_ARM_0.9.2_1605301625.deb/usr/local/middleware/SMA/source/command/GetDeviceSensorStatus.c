/**
 * @file GetDeviceSensorStatus.c
 *
 * @brief Get device sensor status command
 *
 * Copyright (C) 2015. SPTek,All Rights Reserved.
 * Written 2015,by SPTek
 */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <stdbool.h>

#include "Foundation.h"
#include "SensorHandler.h"
#include "SensorConfiguration.h"
#include "GetDeviceSensorStatus.h"
#include "UpdateLogCommand.h"

/*
 ****************************************
 * Private Functions
 ****************************************
 */

/**
 * @brief Return message type
 * @return Message type string
 */
static char* GetMessageType(void)
{
	return "1102";
}

/**
 * @brief Composite contents TLV list
 * @param[out] Sptek tlv list container pointer
 * @return  ERROR_TYPE_SUCCESS
 *          ERROR_TYPE_INVALID_PARAM
 *          ERROR_TYPE_MEMORY_LACK
 */
static int CompositionData(SPTekLIST_T *list)
{
	int              ret           = 0;
	unsigned short   errorValue    = 0x0001;
	SENSOR_ID_E      sensorID      = SENSOR_ID_FIRST;
	SENSOR_STATE_E   deviceStatus  = 0;
	SPTekNODE_T      *nodeSensorID = NULL;
	SPTekNODE_T      *nodeDeviceID = NULL;

	// 2.ADD SensorData
	nodeSensorID = SPTekDataCompositionGetTagNode(list,DM_SENSOR_NAME);
	if(nodeSensorID == NULL) {
		//go : Make Error Result Packet
		sensorID = SENSOR_ID_MAX;
	}

	nodeDeviceID = SPTekDataCompositionGetTagNode(list,DM_DEVICE_ID);
	if(nodeDeviceID == NULL) {
		//go : Make Error Result Packet
		sensorID = SENSOR_ID_MAX;
	}

	for(sensorID = SENSOR_ID_FIRST; sensorID < SENSOR_ID_MAX; sensorID++) {

		if(!GetSensorRegisterFlag(sensorID)){
			continue;
		}
		if(strncmp(nodeDeviceID->mValue,GetDeviceID(),strlen(GetDeviceID())) != 0) {
			continue;
		}

		if(strncmp(nodeSensorID->mValue,GetSensorSensorName(sensorID),strlen(GetSensorSensorName(sensorID))) == 0){
			SENSOR_STATE_E preState;
			preState = GetSensorState(sensorID);
			ret = SensorHandlerGetStatus(sensorID, &deviceStatus);
			if(ret != ERROR_TYPE_SUCCESS) {
				//go : Make Error Result Packet
				sensorID = SENSOR_ID_MAX;
			}
			if(deviceStatus == SENSOR_STATE_ENABLE) {
				SPTekDebugLog(LOG_LEVEL_DEBUG,"Now SensorStatus: <%s>","SENSOR_STATE_ENABLE");
				ret = SPTekDataCompositionAddNode(list, DM_SENSOR_STATUS, strlen("on"), "on", NULL, false);
			} else {
				SPTekDebugLog(LOG_LEVEL_DEBUG,"Now SensorStatus: <%s>","SENSOR_STATE_DISABLE");
				if( preState != deviceStatus ) {
					char buffer[128] = "NOTICE : Get Sensor State is [DISABLE] <<";
					strcat(buffer,GetSensorSensorName(sensorID));
					strcat(buffer,">>");
					MakeUpdateLogMessage(ERROR_TYPE_DEVICE_DISABLED, buffer, GetSensorSensorId(sensorID));
				}
				ret = SPTekDataCompositionAddNode(list, DM_SENSOR_STATUS, strlen("off"), "off", NULL, false);
			}
			if(ret != ERROR_TYPE_SUCCESS) {
				//go : Make Error Result Packet
				sensorID = SENSOR_ID_MAX;
			}

			SPTekDebugLog(LOG_LEVEL_DEBUG,"Now SensorValue: <%s>", GetLastValue(sensorID));
			ret = SPTekDataCompositionAddNode(list, DM_SENSOR_DATA, strlen(GetLastValue(sensorID)), GetLastValue(sensorID), NULL, false);
			if(ret != ERROR_TYPE_SUCCESS) {
				//go : Make Error Result Packet
				sensorID = SENSOR_ID_MAX;
			}
			break;
		}
	}
	//Make Error Result Packet
	if(sensorID == SENSOR_ID_MAX) {
		SPTekCompositionDeleteAllNode(list);
		errorValue = COMMAND_RESULT_FAIL;
		ret = SPTekDataCompositionAddNode(list, DM_RESULT, sizeof(unsigned short), (char*)&errorValue, NULL, false);
		return ret;
	}

	if(ret != ERROR_TYPE_SUCCESS) {
		return ret;
	}
	// 1. Insert DM Result
	ret = SPTekDataCompositionInsertNode(list, DM_RESULT, sizeof(unsigned short), (char*)&errorValue,NULL, 1);
	if(ret != ERROR_TYPE_SUCCESS) {
		return ret;
	}
	ret = SPTekDataCompositionAddNode(list, DM_SENSOR_LINK_TYPE, strlen("NONE"), "NONE", NULL, false);
	return ret;
}

/**
 * @brief Make sendmessage to Service Ready Agent(SRA)
 * @param[in]   receiveMessage Received message container pointer
 * @param[out]  sendMessage    Send message container pointer
 * @return  ERROR_TYPE_SUCCESS
 *          ERROR_TYPE_INVALID_PARAM
 *          ERROR_TYPE_MEMORY_LACK
 */
static int MakeCommandMessageToSRA(SPTekRECEIVE_MESSAGE_T *receiveMessage, SPTekSEND_MESSAGE_T *sendMessage)
{
	int             ret    = ERROR_TYPE_SUCCESS;
	int             length = 0;
	char           *body    = NULL;

	ret = CompositionData(receiveMessage->extractList);
	if(ret != ERROR_TYPE_SUCCESS) {
		SPTekCompositionDeleteAllNode(receiveMessage->extractList);
		return ret;
	}

	if(receiveMessage->extractList == NULL) {
		return ERROR_TYPE_INVALID_PARAM;
	}

	body = (char *)calloc(1, receiveMessage->extractList->mLengths + receiveMessage->extractList->mCount*32);
	if(body == NULL) {
		return ERROR_TYPE_MEMORY_LACK;
	}
	ret = MakeCommandConentsMessage(receiveMessage->extractList, body, &length);
	if(ret != ERROR_TYPE_SUCCESS) {
		free(body);
		return ret;
	}

	sendMessage->message = (char *)calloc(1, sizeof(SPTekMESSAGE_HEADER_T)+length+100);
	if(sendMessage->message == NULL) {
		free(body);
		return ERROR_TYPE_MEMORY_LACK;
	}
	
	ret = MakeCommandHeaderMessage(DESTINATION_SRA, length, GetMessageType(), sendMessage);
	if(ret != ERROR_TYPE_SUCCESS) {
		free(body);
		return ret;
	}
	if(length > 0) {
		(void)memcpy(&sendMessage->message[sendMessage->mLength], body, length);
		sendMessage->mLength = sendMessage->mLength + length;
	}
	free(body);
	return ret;
}

/**
 * @brief Get sensorID from contents
 * @param[in]   list               Received contents container pointer
 * @param[out]  sensorID           Return sensorID string
 * @return  ERROR_TYPE_SUCCESS
 *          ERROR_TYPE_INVLID_PARAM
 */
static int getSensorIDFromContents(SPTekLIST_T *list, char *sensorID)
{
	SPTekNODE_T      *node        = NULL;
	node = SPTekDataCompositionGetTagNode(list,DM_SENSOR_ID);
	if(sensorID == NULL || strlen(sensorID) < 1 || node == NULL || node->mValue == NULL || strlen(node->mValue) < 1) {
		SPTekDebugLog(LOG_LEVEL_DEBUG,"Node is empty");
		return ERROR_TYPE_INVALID_PARAM;
	}
	(void)memcpy(sensorID,node->mValue,strlen(node->mValue));
	return ERROR_TYPE_SUCCESS;
}

/**
 * @brief Create an error message.
 * @param[in]  index  : Identify the destination
 * @param[out] packet : Error Messages structure
 */
static void MakeErrorMessage(SPTekDESTINATION_E index, SPTekSEND_MESSAGE_T *packet)
{
	int            ret     = ERROR_TYPE_SUCCESS;
	int            tag     = DM_RESULT;
	unsigned short len     = sizeof(unsigned short);
	unsigned short error   = 0x0002;
	int            bodyLen = 1 + sizeof(unsigned short) + sizeof(unsigned short);
	int            pos     = 0;
	char           value[4];

	(void)memset(value, 0, 4);
	(void)memcpy(value, &error, sizeof(unsigned short));

	packet->message = (char *)calloc(sizeof(SPTekMESSAGE_HEADER_T) + 1 + bodyLen, sizeof(char));
	if(packet->message == NULL) {

		SPTekDebugLog(LOG_LEVEL_ERROR, "[SMA] 에러메시지 메모리 활당 실패, 목적지[ %d ]", index);

		return;
	}

	ret = MakeCommandHeaderMessage(index, bodyLen, GetMessageType(), packet);
	if(ret != ERROR_TYPE_SUCCESS) {
		free(packet->message);
		packet->message = NULL;

		SPTekDebugLog(LOG_LEVEL_ERROR, "[SMA] 에러메시지 헤더 구성 실패, 목적지[ %d ], 에러 값 [ %d ]", index, ret);

		return;
	}

	packet->message[packet->mLength + pos] = tag;
	pos = pos + 1;

	(void)memcpy(&packet->message[packet->mLength + pos], &len, sizeof(unsigned short));
	pos = pos + sizeof(unsigned short);

	(void)memcpy(&packet->message[packet->mLength + pos], value, sizeof(unsigned short));
	pos = pos + sizeof(unsigned short);
	packet->mLength = packet->mLength + pos;
	return;
}

/**
 * @brief Main command processing function ( Message Analysis and Make )
 * @param[in]   receiveMessage     Received message container pointer
 * @param[in]   contents           Received packet string
 * @param[out]  sendMessage        Send message container pointer
 * @return  ERROR_TYPE_SUCCESS
 *          ERROR_TYPE_INVALID_PARAM
 *          ERROR_TYPE_MEMORY_LACK
 */
static int CommandProcessSourceSRA(SPTekRECEIVE_MESSAGE_T *receiveMessage, char *contents, SPTekSEND_MESSAGE_T *sendMessage)
{
	int  ret    = ERROR_TYPE_SUCCESS;
	int  length = 0;
	char lengths[CONTENTS_LENGTHS+1];
	char sensorID[MAX_LEN_SENSOR_ID+1]="";

	(void)memset(lengths, 0, CONTENTS_LENGTHS+1);
	(void)memset(sensorID, 0, MAX_LEN_SENSOR_ID+1);

	receiveMessage->extractList = (SPTekLIST_T *)calloc(1, sizeof(SPTekLIST_T));
	if(receiveMessage->extractList == NULL) {
		return ERROR_TYPE_MEMORY_LACK;
	}
	SPTekDataCompositionInitNode(receiveMessage->extractList);
	(void)memcpy(lengths, receiveMessage->mHeader.mContentsLength, CONTENTS_LENGTHS);
	length = atoi(lengths);

	ret = ExtractContents(contents, length, receiveMessage->extractList);
	if(ret != ERROR_TYPE_SUCCESS) {
		SPTekCompositionDeleteAllNode(receiveMessage->extractList);
		free(receiveMessage->extractList);
		return ret;
	}

	// To updateLog , store sensorID 
	getSensorIDFromContents(receiveMessage->extractList,sensorID);

	ret = MakeCommandMessageToSRA(receiveMessage, sendMessage);
	if(ret != ERROR_TYPE_SUCCESS) {
		MakeErrorMessage(DESTINATION_SRA, sendMessage);
		MakeUpdateLogMessage(ret, "Command Fail    [GetDeviceSensorStatus]", sensorID);
		SPTekDebugLog(LOG_LEVEL_ERROR, "[SMA] getDeviceSensorStatus Command Make Packet Fail From SRA : errorno = %d", ret);
	} else {
		SPTekNODE_T *name;
		SPTekNODE_T *data;
		char logMSG[126]; 
		char *nameDump;
		char *dataDump;
		name = SPTekDataCompositionGetTagNode(receiveMessage->extractList,DM_SENSOR_NAME);
		data = SPTekDataCompositionGetTagNode(receiveMessage->extractList,DM_SENSOR_DATA);
        if(name == NULL || data == NULL || name->mValue == NULL || data->mValue == NULL || strlen(name->mValue) < 1|| strlen(data->mValue) < 1) {
            SPTekDebugLog(LOG_LEVEL_ERROR, "[SMA] getDeviceSensorStatus MakeUpdateLogMessage Fail");
        } else {
            SPTekDebugLog(LOG_LEVEL_ERROR, "[SMA] getDeviceSensorStatus MakeUpdateLogMessage %s, %s", name->mValue, data->mValue);

    		nameDump = strdup(name->mValue);
    		dataDump = strdup(data->mValue);
    		sprintf(logMSG, "Command Success [GetDeviceSensorStatus] <<%s>> <<%s>>", nameDump, dataDump ); 
    		MakeUpdateLogMessage(ret, logMSG, sensorID);
    		free(nameDump);
    		free(dataDump);
        }
	}

	SPTekCompositionDeleteAllNode(receiveMessage->extractList);
	free(receiveMessage->extractList);
	receiveMessage->extractList = NULL;

	return ret;
}

/*
 ****************************************
 * Public Functions
 ****************************************
 */

/**
 * @brief <getDeviceSensorStatus> command processing external interface
 * @param[in]   receiveMessage     Received message container pointer
 * @param[in]   contents           Received packet string
 * @param[out]  sendMessage        Send message container pointer
 * @return  ERROR_TYPE_SUCCESS
 *          ERROR_TYPE_INVALID_PARAM
 *          ERROR_TYPE_MEMORY_LACK
 *          ERROR_TYPE_INVALID_COMMAND
 */
int GetDeviceSensorStatusCommandProcess(SPTekRECEIVE_MESSAGE_T *receiveMessage, char *contents, int length, SPTekSEND_MESSAGE_T *sendMessage)
{
	int           ret    = ERROR_TYPE_SUCCESS;
	SPTekSOURCE_E source = SOURCE_NONE;
	source = GetSourceType(receiveMessage->mHeader.mSource);
	switch(source) {
		case SOURCE_SRA: {
			ret = CommandProcessSourceSRA(receiveMessage, contents, sendMessage);
		}
		break;

		default: {
			ret = ERROR_TYPE_INVALID_COMMAND;
		}
		break;
	}
	return ret;
}

