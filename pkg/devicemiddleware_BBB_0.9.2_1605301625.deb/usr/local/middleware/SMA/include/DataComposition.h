/**
 * @file DataComposition.h
 *
 * @brief Packet data composition process header
 *
 * Copyright (C) 2015. SPTek,All Rights Reserved.
 * Written 2015,by SPTek
 */

#ifndef __DATA_COMPOSITION_H__
#define __DATA_COMPOSITION_H__

#include <stdbool.h>
/*
 ****************************************
 * Definitions
 ****************************************
 */

/*
 ****************************************
 * Enumerations
 ****************************************
 */


/// Contents Type
typedef enum tagTagType {
	DM_RESULT                     = 0x01,
	DM_ERROR_MESSAGE              = 0x02,

	DM_DEVICE_MODEL               = 0x11,
	DM_CPU                        = 0x12,
	DM_RAM                        = 0x13,
	DM_SERIAL_NUMBER              = 0x14,
	DM_MAC_ADDRESS                = 0x15,

	DM_DEVICE_NAME                = 0x21,
	DM_PASS_CODE                  = 0x22,

	DM_CONNECTION_STAT            = 0x31,
	DM_CONNECTION_TYPE            = 0x32,
	DM_SUBNET_MASK                = 0x33,
	DM_GATEWAY                    = 0x34,

	DM_SENSOR_ARRAY               = 0x41,
	DM_DEVICE_ID                  = 0x42,
	DM_SENSOR_ID                  = 0x43,
	DM_SENSOR_NAME                = 0x44,
	DM_SENSOR_TYPE                = 0x45,
	DM_SENSOR_SERIAL    		  = 0x46,
	DM_SENSOR_OPERATION_TYPE      = 0x47,
	DM_SENSOR_STATUS    		  = 0x48,
	DM_SENSOR_DATA                = 0x49,
	DM_SENSOR_LINK_TYPE           = 0x4A,
	DM_SENSOR_CONTROL_TYPE        = 0x4B,
	DM_SENSOR_CONTROL             = 0x4C,
	DM_SENSOR_CONTROL_RESULT      = 0x4D,

	DM_SENSOR_CMD                 = 0x51,
	DM_SENSOR_EXECREQARGS         = 0x52,
	DM_SENSOR_RESULT_VALUE        = 0x53,

	DM_LOG_TYPE                   = 0x61,
	DM_LOG_LEVEL                  = 0x62,
	DM_LOG_NEXT_KEY               = 0x63,
	DM_LOG_DATA                   = 0x64,
	DM_LOG_COUNT                  = 0x65,
	DM_LOG_DEVICE_ID              = 0x66,
	DM_LOG_SENSOR_ID              = 0x67,

	DM_TRACE_STATUS               = 0x71,

	DM_MAX
}SPTekTAG_TYPE_E;

/*
 ****************************************
 * Structures
 ****************************************
 */

typedef struct tagTLVItem {
	SPTekTAG_TYPE_E   mTag;
    unsigned short    mLengths;
    char              *mValue;
    struct tagTLVItem *mNextItem;
}SPTekTLV_ITEM_T;

typedef struct tagItemList {
	int             mCount;
    int             mLengths;
    SPTekTLV_ITEM_T *mHead;
}SPTekITEM_LIST_T;

typedef struct tagNode {
	SPTekTAG_TYPE_E  mTag;
    unsigned short   mLengths;
    char             *mValue;
    SPTekITEM_LIST_T *mItems;
    struct tagNode   *mNextNode;
}SPTekNODE_T;

typedef struct tagLIST {
	int         mCount;
    int         mLengths;
    SPTekNODE_T *mHead;
}SPTekLIST_T;

/*
 ****************************************
 * Public Functions
 ****************************************
 */

void SPTekDataCompositionInitNode(SPTekLIST_T *list);
int SPTekDataCompositionInsertNode(SPTekLIST_T *list, SPTekTAG_TYPE_E tag, unsigned short length, char* value, SPTekITEM_LIST_T *items, int position);
int SPTekDataCompositionAddNode(SPTekLIST_T *list, SPTekTAG_TYPE_E tag, unsigned short length, char* value, SPTekITEM_LIST_T *items, bool skip);
SPTekNODE_T* SPTekDataCompositionGetPositionNode(SPTekLIST_T* list, int position);
SPTekNODE_T* SPTekDataCompositionGetTagNode(SPTekLIST_T* list, SPTekTAG_TYPE_E tag);
int SPTekDataCompositionDeleteNode(SPTekLIST_T *list, int position);
void SPTekCompositionDeleteAllNode(SPTekLIST_T *list);
void SPTekDataCompositionPrintNode(SPTekLIST_T *list);

void SPTekDataCompositionInitItem(SPTekITEM_LIST_T *list);
int SPTekDataCompositionInsertItem(SPTekITEM_LIST_T *list, SPTekTAG_TYPE_E tag, unsigned short length, char* value, int position);
int SPTekDataCompositionAddItem(SPTekITEM_LIST_T *list, SPTekTAG_TYPE_E tag, unsigned short length, char* value);
SPTekTLV_ITEM_T* SPTekDataCompositionGetPostionItem(SPTekITEM_LIST_T* list, int position);
SPTekTLV_ITEM_T* SPTekDataCompositionGetTagItem(SPTekITEM_LIST_T* list, SPTekTAG_TYPE_E tag);
int SPTekDataCompositionDeleteItem(SPTekITEM_LIST_T *list, int position);
void SPTekCompositionDeleteAllItem(SPTekITEM_LIST_T *list);
void SPTekDataCompositionPrintItem(SPTekITEM_LIST_T *list);

void CreateUniqueID(void);
char* GetDeviceID(void);
char* GetSourceID(void);

#endif /* __DATA_COMPOSITION_H__ */

