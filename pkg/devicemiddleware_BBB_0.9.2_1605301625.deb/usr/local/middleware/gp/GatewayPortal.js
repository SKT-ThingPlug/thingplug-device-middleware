

// GatewayPortal 이름
var GatewayPortal = "GatewayPortal";

// arguments
var argv = [ process.argv[2], process.argv[3], process.argv[4] ];

// server spawn
var dir = __dirname + "/";
var exec = require("child_process").exec;
var fork = require("child_process").fork;
var spawn = require("child_process").spawn;
var server = fork(dir + GatewayPortal + "/server.js", argv, { cwd : dir + GatewayPortal });

// GatewayPortal 종료
server.on("exit", server_exit);

// 서버 프로세스 메시지 수신
server.on("message", server_message);

// 종료 함수

var isInstalling = false;
function server_message(msg) {

	msg = msg.replace(/\n$/, '');

	if (msg == "INSTALL") {		// 설치
		server.send("SIGTERM");		// 종료 요청
		server.kill();				// 종료

		// 인스톨
		var install_process;
		
		if(!isInstalling){
			install_process = exec("sh " + dir + "install.sh ", { cwd : dir, maxBuffer : 1024*1024 });
			isInstalling = true;
		}
		
		install_process.stdout.on("data", function (msg) {
			console.log(msg);
			if(msg == "exit"){
				install_process.kill();
			}
		});
		
//		install_process.stdout.on("data", function (msg) {
//			console.log('install_process.stdout.on("data")');
//			console.log(msg);
//
//			msg = msg.replace(/\n$/, '');
//
//			
//			//server = fork(dir + GatewayPortal + "/server.js", argv, { cwd : dir + GatewayPortal });
//			server.on("exit", server_exit);
//			server.on("message", server_message);
//		});
	}
}

// 종료 함수
function server_exit() {
	console.log(GatewayPortal + " server close.");
}