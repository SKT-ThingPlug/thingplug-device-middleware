
/**
 *
 * 환경설정 > 업그레이드
 *
 */

(function () {

	$(function () {

		onCheckFileStatus();

		// file upload select
		$(".lbRdo .rdoBg").bind("change", onCheckFileStatus);

		// input file check
		function onCheckFileStatus() {
			var inputFile = $(".hidFile");
			var fileLabel = $(inputFile).siblings(".fileName");
			var helpText = fileLabel.attr("title");

			if($(".customUpgrage").is(":checked")) {
				inputFile.prop("disabled", false);
			}
			else if($(".autoUpgrage").is(":checked")) {
				inputFile.prop("disabled", true);
			}

			if($(inputFile).is(":disabled")) {
				fileLabel.addClass("disabled").text("");
			}
			else {
				fileLabel.removeClass("disabled").text(helpText);
			}
		}

		// file event
		$(document).on("change", ".hidFile", function(evt) {
			var file = $(this).val().split(/(\\|\/)/g).pop();
			var ext = file.split(".").pop();
			var fileLabel = $(this).siblings(".fileName");
			var helpText = fileLabel.attr("title");

			if(file.length > 1) fileLabel.text(file);
			else fileLabel.text(helpText);
		}).on("reset", "form", function(evt) {
			var length = $(this).find(".hidFile").length;

			if(length > 0) {
				var helpText = $(this).find(".hidFile").parents("label").eq(0).siblings(".fileName").attr("title");
				$(this).find(".hidFile").parents("label").eq(0).siblings(".fileName").text(helpText);
			}
		});

		// 실행버튼
		$(".bt_upgrade").click(function (e) {
			if($(".customUpgrage").is(":checked")) {
				ipc.start(1);
				e.preventDefault();
				$("#upgrade_form").submit();
			}
		});
	});
})();