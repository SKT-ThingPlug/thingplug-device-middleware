
/**
 *
 * IPC 관련
 *
 */
var IPC = {};
module.exports = IPC;

// 
var zmq = require("zmq");
var ping = require("ping");
var decode = require("./decode");
var encode = require("./encode");
var API = require("./MA_API");
var exec = require("child_process").exec;
var define = require("./define");
var os = require('os');
var ifaces = os.networkInterfaces();

var ip = "127.0.0.1";

// get IP Address
/*
Object.keys(ifaces).forEach(function (ifname) {
	var alias = 0;
	ifaces[ifname].forEach(function (iface) {
    if ('IPv4' !== iface.family || iface.internal !== false) {
    	// skip over internal (i.e. 127.0.0.1) and non-ipv4 addresses
    	return;
    }

    if (alias >= 1) {
    	// this single interface has multiple ipv4 addresses
    } else {
    	if(ifname == "eth0"){
    		ip = iface.address;
    	}
    	return;
    }
    ++alias;
  });
});
*/

var push_port = process.argv[3] == "undefined" ? "tcp://"+ ip +":6001" : "tcp://"+ process.argv[3] +":6001";
var sub_port  = process.argv[3] == "undefined" ? "tcp://"+ ip +":6000" : "tcp://"+ process.argv[3] +":6000";

var push_socket = zmq.socket("push");
var sub_socket = zmq.socket("sub");

var http_socket = {};
var httpRequest;

// IPC 시작
IPC.start = function () {

	//ZMQ Push Socket 등록 
	push_socket.connect(push_port);
	push_socket.identity = "GP";
	API.pushSocketRegister(push_socket);	// 전송

	// ZMQ Subscriber Socket 등록
	sub_socket.connect(sub_port);
	sub_socket.identity = "GP";
	sub_socket.subscribe("GP");

	//subscripber 메시지 응답
	sub_socket.on("message", function(data, message) {
		var res = decode.decode(message);
		if (res.err) console.error(res.err);

		if (res && res.header && http_socket[res.header.messageType]) {
			// 로그인 부분만 세션처리때문에
			if (res.header.messageType == "1001" && res.content.DM_RESULT == 0x01) {
				httpRequest.session.userId = httpRequest.body.data.data.userId;
				httpRequest.session.userPassword = httpRequest.body.data.data.userPassword;
			} else if (res.header.messageType == "1001" && res.content.DM_RESULT == 0x02) {
				//res.content.DM_RESULT_MESSAGE = "계정정보가 일치하지 않습니다.";
			} else if (res.content.DM_RESULT != 0x01) {
				//res.content.DM_RESULT_MESSAGE = "네트워크 오류입니다.";
			}

			// 요청 타입
			res.content.M_TYPE = res.header.messageType;
			http_socket[res.content.M_TYPE].end(JSON.stringify(res.content));
		}
	});
};


// IPC 종료
IPC.end = function () {
	push_socket.close();
	sub_socket.close();
};


//라우터 콜백 설정
IPC.ping = function (req, res) {	// ping

	var obj = {};
	obj.DM_RESULT = 0x0001;

	ping.sys.probe(req.body.host, function (isAlive) {
		obj.isAlive = isAlive;
		res.end(JSON.stringify(obj));
	});
};


IPC.authentication = function (req, res) {	// 로그인 
	
	httpRequest = req;
	http_socket[define.AUTHENTICATION.toString()] = res;

	var obj = {};
	
	API.authentication(req.body.data.data.userId, req.body.data.data.userPassword);
	
};


IPC.changeAuth = function (req, res) {		// 비밀번호 변경

	http_socket[define.CHANGE_AUTH.toString()] = res;

	var obj = {};

	if (req.session.userPassword == req.body.data.data.DM_ADMIN_PASSWD) {
		API.changeAuthentication(req.body.data.data.DM_ADMIN_ID, req.body.data.data.DM_ADMIN_PASSWD, 
							req.body.data.data.DM_ADMIN_NEW_PASSWD, req.body.data.data.DM_ADMIN_NEW_PASSWD2);
	} else {
		obj.DM_RESULT = 0x0005;
		res.end(JSON.stringify(obj));
	}
	
};


IPC.restart = function (req, res) {		// 재구동 요청

	http_socket[define.RESTART.toString()] = res;

	var obj = {};

	API.restart();
	
};


IPC.reset = function (req, res) {		// 초기화 요청
	
	http_socket[define.RESET.toString()] = res;

	var obj = {};
	
	API.reset();

};


IPC.getSystemInfo = function (req, res) {	// 시스템 정보

	http_socket[define.GET_SYSTEM_INFO.toString()] = res;

	var obj = {};

	API.getSystemInfo();
	
};


IPC.getSystemUsage = function (req, res) {	// 시스템 사용량 정보
	
	http_socket[define.GET_SYSTEM_USAGE.toString()] = res;

	var obj = {};
	
	API.getSystemUsage();
		
};


IPC.getNetworkInfo = function (req, res) {	// 네트워크 정보

	http_socket[define.GET_NETWORK_INFO.toString()] = res;

	var obj = {};
	
	API.getNetworkInfo();
	
};


IPC.getProcessStatus = function (req, res) {	// 장치 process 상태정보
	
	http_socket[define.GET_PROCESS_STATUS.toString()] = res;

	var obj = {};
	
	API.getProcessStatus();
};


IPC.getDeviceSensor = function (req, res) {	// 센서 정보

	http_socket[define.GET_DEVICE_SENSOR.toString()] = res;

	var obj = {};

	API.getDeviceSensor();
};


IPC.getDeviceSensorStatus = function (req, res) {	// 센서 상태

	http_socket[define.GET_DEVICE_SENSOR_STATUS.toString()] = res;

	var obj = {};

	API.getDeviceSensorStatus(req.body.data.data.DM_DEVICE_ID, req.body.data.data.DM_SENSOR_ID, 
								req.body.data.data.DM_SENSOR_NAME, req.body.data.data.DM_SENSOR_TYPE);
	
};


IPC.getAllDeviceSensorStatus = function (req, res) {	// 모든 센서 정보 요청
	
	http_socket[define.GET_ALL_DEVICE_SENSOR_STATUS.toString()] = res;

	var obj = {};

	API.getAllDeviceSensorStatus(req.body.data.data.DM_DEVICE_ID);

};


IPC.registerDevice = function (req, res) {	// 장치 thingplug 등록
	
	http_socket[define.REGISTER_DEVICE.toString()] = res;

	var obj = {};

	if ("oneM2M" == req.body.data.data.DM_IOT_PROTOCOL_TYPE) {
		API.registerDevice_oneM2M(req.body.data.data.DM_IOT_DEVICE_NAME, req.body.data.data.DM_IOT_PASS_CODE, 
											req.body.data.data.DM_IOT_SP_USE_FLAG, req.body.data.data.DM_IOT_UKEY);
	} else if ("GMMP" == req.body.data.data.DM_IOT_PROTOCOL_TYPE) {
		API.registerDevice_GMMP(req.body.data.data.DM_IOT_AUTH_ID, req.body.data.data.DM_IOT_SERVICE_ID, 
											req.body.data.data.DM_IOT_SP_USE_FLAG, req.body.data.data.DM_IOT_MANUFACTURE_ID, req.body.data.data.DM_IOT_SERVER_PORT);
	}

};


IPC.getThingStatus = function (req, res) {	// thingplug 연결 정보

	http_socket[define.GET_THING_STATUS.toString()] = res;

	var obj = {};

	API.getThingStatus();

};


IPC.getInterval = function (req, res) {	// 센서정보 주기 정보 요청
	
	http_socket[define.GET_INTERVAL.toString()] = res;

	var obj = {};

	API.getInterval();
};


IPC.setInterval = function (req, res) {	// 센서정보 주기 정보 설정
	
	http_socket[define.SET_INTERVAL.toString()] = res;

	var obj = {};

	API.setInterval(req.body.data.data.DM_SENSOR_GATHER_INTERVAL, req.body.data.data.DM_SENSOR_SERVER_UPDATE_INTERVAL);

};


IPC.setTraceStatus = function (req, res) {	// trace on/off 요청
	
	http_socket[define.SET_TRACE_STATUS.toString()] = res;

	var obj = {};

	API.setTraceStatus(req.body.data.data.DM_TRACE_STATUS);
	
};


IPC.updateLog = function (req, res) {	// 로그정보 업데이트 요청

	http_socket[define.UPDATE_LOG.toString()] = res;

	var obj = {};
		API.updateLog(req.body.data.data.DM_LOG_TYPE, req.body.data.data.DM_LOG_LEVEL, 
						req.body.data.data.DM_LOG_SUB_TYPE, req.body.data.data.DM_LOG_DATA);
		
};


IPC.getSystemLog = function (req, res) {	// 시스템 로그
	
	http_socket[define.GET_SYSTEM_LOG.toString()] = res;

	var obj = {};

	//console.log("req.body : ", req.body);
	API.getSystemLog(req.body.data.data.DM_LOG_TYPE, req.body.data.data.DM_LOG_NEXT_KEY, req.body.data.data.DM_LOG_COUNT);

};


IPC.getErrorLogCount = function (req, res) {	// 에러 카운트 요청
	
	http_socket[define.GET_ERROR_LOG_COUNT.toString()] = res;

	var obj = {};

	API.getErrorLogCount();
	
};


IPC.logReset = function (req, res) {	// 로그정보 초기화
	
	http_socket[define.LOG_RESET.toString()] = res;

	var obj = {};

	API.logReset();
	
};


//디바이스 목록 받아오기
IPC.getDevice = function(req, res){
	
	http_socket[define.GET_DEVICE.toString()] = res;

	var obj = {};

	API.getDevice();
	
}


// Sensor Config file Change API
IPC.changeSensorConfigFile = function(req, res){
	
	var obj = {};
	exec("service middleware set_config " + req.body.data.data.DM_SENSOR_CONFIG_FILENAME );
	obj.DM_RESULT = 0x0001;
	res.end(JSON.stringify(obj));
	
}







