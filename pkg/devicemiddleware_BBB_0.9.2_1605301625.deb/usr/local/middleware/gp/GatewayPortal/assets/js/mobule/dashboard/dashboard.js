
/**
 *
 * 대시보드
 *
 */
window.isPing = false;
(function () {

	$(function () {

		// 동기설정
		ipc.start(1);

		// 초기 정보 셋팅
		setTimeout(function () {
			init();
		}, Config.StartTime.DashboardLoading);

		// 센서
		setTimeout(function () {
			sensor.init(true, true);
		}, Config.StartTime.Sensor);

		// 로그 히스토리 
		setTimeout(function () {
			_history.init();
		}, Config.StartTime.History);

		// 대시보드 타이머
		setTimeout(function () {
			dash_timer.init();
		}, Config.StartTime.Dashboard);

		// ping btn
		$(".bt_ping").click(function (e) {

			e.preventDefault();

			ipc.start();

			window.isPing = true;

			setTimeout(function () {
				ipc.send("ping", false, function (res) {

					ipc.end();

					if (res.DM_RESULT == IPC.DM_RESULT_SUCCESS) {

						var tit = __("연결이 원할하지 않습니다");
						if (res.isAlive) tit = __("연결되었습니다");

						$("#ping_modal h2").text(tit);
						$("#ping_modal").bPopup(popup_option);

						setTimeout(function () {
							$("#ping_modal").bPopup().close();
							isPing = false;
						}, 1300);
					}
				});
			}, 200);
		});

		// 시스템 재실행
		$(".bt_restart").click(function (e) {

			e.preventDefault();

			$("#loading").bPopup(popup_option);
			
			ipc.send("restart", false, function (res) {
				setTimeout(function () {
					$("#loading").bPopup().close();
				}, 500);
			});
		});
	});

	// 페이지 초기화
	var init = function () {

		// 시스템 정보
		ipc.send("getSystemInfo", false, function (res) {

			ipc.end();
			
			if (res.DM_RESULT == IPC.DM_RESULT_SUCCESS) {
				// {"DM_RESULT":1,"DM_DEVICE_MODEL":"Model Name","DM_CPU_TYPE":"CPU 1.5Ghz","DM_RAM_TYPE":"4.0G","DM_BATTERY_TYPE":"1.0","DM_SERIAL_NUMBER":"0xd2dfefea","DM_MAC_ADDRESS":"MA-AA-DC-EF-AE"}
				$("#DM_DEVICE_MODEL").text(res.DM_DEVICE_MODEL);
				$("#DM_MAC_ADDRESS").text(res.DM_MAC_ADDRESS);
				$("#DM_SERIAL_NUMBER").text(res.DM_SERIAL_NUMBER);
			}
		});
	};
})();