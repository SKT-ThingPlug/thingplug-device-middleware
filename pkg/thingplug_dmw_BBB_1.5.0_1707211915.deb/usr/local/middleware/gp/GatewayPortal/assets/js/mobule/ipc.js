
/**
 *
 * IPC 관련
 *
 */

var ipc = IPC = {

	dev : false, 
	async : false,
	isTimeout : false,
	_sockets : [],

	DM_RESULT_SUCCESS					:	0x0001, 
	DM_RESULT_FAIL						:	0x0002, 
	DM_RESULT_NO_SENSOR					:	0x0003, 
	DM_RESULT_NO_CMD					:	0x0004, 
	DM_RESULT_ALEADY_REGISTERED			:	0x0005, 
	DM_RESULT_OTHER_REGISTERED			:	0x0006,
	DM_RESULT_SENSOR_CHANGED			:	0x0007,


	DM_PROCESS_LIVE_STATE	:	0x0001, 
	DM_PROCESS_KILL_STATE	:	0x0002, 

	DM_THING_ONLINE			:	0x0001, 
	DM_THING_OFFLINE		:	0x0002, 

	DM_REGISTERED			:	0x0001, 
	DM_NO_REGISTERED		:	0x0002, 

	DM_IOT_SP_USE			:	0x0001, 
	DM_IOT_SP_NO_USE		:	0x0002, 
	
	// DM_IOT_SP_USE_FLAG type
	DM_IOT_RAW				:	0x0001, 
	DM_IOT_SP				:	0x0002,
	DM_IOT_TLV				:	0x0003,

	DM_DHCP_TYPE			:	0x0001, 
	DM_STATIC_TYPE			:	0x0002, 

	DM_TRACE_ON				:	0x0001, 
	DM_TRACE_OFF			:	0x0002, 
	
	// DM_UNREGI_TYPE
	DM_ACCOUNT				:	0x0001,
	DM_DEVICE				:	0x0002,

	// DM_HAS_ACCOUNT
	DM_STATUS_YES			:	0x0001,
	DM_STATUS_NO			:	0x0002,
	
	// SENSOR_OPERATION_TYPE
	DM_SENSOR_EVENT_TYPE	:	0x0001,
	DM_SENSOR_SERIES_TYPE	:	0x0002,
	
	// SENSOR_CONTROL_TYPE
	DM_SENSOR_HAS_CONTROL_TYPE	:	0x0001,
	DM_SENSOR_NO_CONTROL_TYPE	:	0x0002,

	
	
	// 서버통신 시작 요청
	start : function(c) {
		this._sockets = [];
		var _c = c ? c : 1;
		for (var i = 0; i < _c; i++) this._sockets.push(false);
		$("#loading_start").bPopup(popup_option);
	},

	// 통신 종료
	end : function () {
		var ok_count = 0;
		
		this._sockets.pop();
		
		if (0 == this._sockets.length) {
			$("#loading_start").bPopup().close();
		}
	},
				

	// 메시지 전송
	send : function (method, tlv, sf) {

		var _tlv = {
			data : {},
			dev : this.dev
		};
		_tlv.data.data = tlv ? tlv.serialize() : false;

		// ping 일 경우
		if (method == "ping") _tlv.host = Config.PingHost;

		setTimeout(function () {
			$.ajax({
				type : "POST",
				async : true,
				//async : IPC.async,
				timeout: Config.Timeout,
				data : JSON.stringify(_tlv),
				contentType: "application/json",
				url : "/API/" + method,
				success : function (res) {
					IPC.receive(method, JSON.parse(res), sf);
				},
				error : function (e, res, msg) {
					if (msg == "timeout" && !window.isPing && method != "ping") IPC.timeout(100, 3000);
					if (sf && typeof(sf) != "undefined" && typeof(sf) == "function") sf(false);
				}
			});
		}, Config.Ajax);
	}, 

	// 메시지 읽어서 json 으로 변환
	receive : function (method, res, sf) {

		console.log("--------------[" + method + "]----------------");
		console.log(res);
		console.log("------------------------------");

		//if (res.DM_RESULT == IPC.DM_RESULT_SUCCESS) {
			
			if (sf && typeof(sf) != "undefined" && typeof(sf) == "function") sf(res);

		//} else {
			//console.error(res.DM_RESULT_MESSAGE);
		//}
	},

	// timeout 시간이 되면 경고창
	timeout : function (st, et) {

		if (ipc.isTimeout) return;

		ipc.isTimeout = true;
		
		setTimeout(function () {

			var option = {
				modalClose : false, 
				positionStyle : "fixed", 
				follow : [ true, true ]
			}

			$("#loading_timeout").bPopup(option);

			setTimeout(function () {
				$("#loading_timeout").bPopup().close();
				ipc.isTimeout = false;
			}, et);
		}, st);
	}
};