/**
 * http://usejsdoc.org/
 */
var encode = {};

module.exports = encode;

var define = require('./define');


encode.encodeHeader = function(packet, messageType, totalByteLength) {
	
	var lengthStirng;
	
	if(totalByteLength){
		var contentLength = totalByteLength - define.DEFAULT_HEADER_OFFSET;
		lengthStirng  = Math.floor(contentLength / 1000 % 10).toString();
		lengthStirng += Math.floor(contentLength / 100 % 10).toString();
		lengthStirng += Math.floor(contentLength / 10 % 10).toString();
		lengthStirng += Number(contentLength % 10).toString();
	}
	
	packet.write("MA", define.HEADER_DESTINATION_START_OFFSET, 16, 'binary');
	packet.write("GP", define.HEADER_SOURCE_START_OFFSET, 16, 'binary');
	packet.write(messageType.toString(), define.HEADER_TYPE_START_OFFSET, 4, 'binary');
//	packet.write(null, define.HEADER_RESERVED_START_OFFSET, 8, 'binary');
	packet.write(lengthStirng || "0000", define.HEADER_LENGTH_START_OFFSET, 4, 'binary');
	
	lengthStirng = null;
    
	return packet;
};





encode.encodeContent = function(packet, messageType, content) {
	
	var offset = define.DEFAULT_HEADER_OFFSET; 
	
	switch(messageType){
	
		/*
			1001 - AUTHENTICATION
		 	admin Auth 를 요청
			
			DM_ADMIN_ID		0x81	현재 아이디
			DM_ADMIN_PASSWD	0x82	현재 비밀번호

		*/
		case define.AUTHENTICATION :
			offset = encode.TLV_String(packet, define.DM_ADMIN_ID, content.DM_ADMIN_ID, offset);
			offset = encode.TLV_String(packet, define.DM_ADMIN_PASSWD, content.DM_ADMIN_PASSWD, offset);
			break;
	
		
		
		/*
			1002 - CHANGE_AUTH
		 	admin ID PASSWD 변경요청
		 	
			DM_ADMIN_ID			0x81	현재 아이디
			DM_ADMIN_PASSWD		0x82	현재 비밀번호
			DM_ADMIN_NEW_ID		0x83	변경 할 아이디
			DM_ADMIN_NEW_PASSWD	0x84	변경 할 비밀번호

		*/
		case define.CHANGE_AUTH :
			offset = encode.TLV_String(packet, define.DM_ADMIN_ID, content.DM_ADMIN_ID, offset);
			offset = encode.TLV_String(packet, define.DM_ADMIN_PASSWD, content.DM_ADMIN_PASSWD, offset);
			offset = encode.TLV_String(packet, define.DM_ADMIN_NEW_ID, content.DM_ADMIN_NEW_ID, offset);
			offset = encode.TLV_String(packet, define.DM_ADMIN_NEW_PASSWD, content.DM_ADMIN_NEW_PASSWD, offset);
			break;
	
		

		/*
			1022 - GET_DEVICE_SENSOR
		 	해당 디바이스에 연결된 센서정보를 요청
		 	
		 	1024 - GET_ALL_DEVICE_SENSOR_STATUS
		 	해당 디바이스의 센서의 센서상태 및 데이터를 요청
		 	
			DM_DEVICE_ID	0x42	디바이스 ID

		*/			
		case define.GET_DEVICE_SENSOR:
		case define.GET_ALL_DEVICE_SENSOR_STATUS:
			offset = encode.TLV_String(packet, define.DM_DEVICE_ID, content.DM_DEVICE_ID, offset);
			break;
			
			
			
			
		/*
			1023 - GET_DEVICE_SENSOR_STATUS
		 	자기 장치에 연결된 디바이스 및 센서상태정보를 요청
			
			DM_DEVICE_ID	0x42	디바이스 ID
			DM_SENSOR_ID	0x43	센서 ID
			DM_SENSOR_NAME	0x44	센서이름
			DM_SENSOR_TYPE	0x45	센서타입
	
		*/
		case define.GET_DEVICE_SENSOR_STATUS :
			offset = encode.TLV_String(packet, define.DM_DEVICE_ID, content.DM_DEVICE_ID, offset);
			offset = encode.TLV_String(packet, define.DM_SENSOR_ID, content.DM_SENSOR_ID, offset);
			offset = encode.TLV_String(packet, define.DM_SENSOR_NAME, content.DM_SENSOR_NAME, offset);
			offset = encode.TLV_String(packet, define.DM_SENSOR_TYPE, content.DM_SENSOR_TYPE, offset);
			break;
		
			
			
		/*
			1041 - REGISTER_DEVICE
		 	자기장치를 ThingPlug에 등록한다
		 	
			DM_IOT_PROTOCOL_TYPE	0x21	IOT Protocol 타입(“oneM2M” or “GMMP”
			DM_IOT_DEVICE_NAME		0x22	장치이름
			DM_IOT_PASS_CODE		0x23	디바이스 패스코드
			DM_IOT_SP_USE_FLAG		0x26	SKT 서비스플랫폼 사용여부
			DM_IOT_UKEY				0x27	UKEY
			DM_IOT_SERVICE_ID		0x28	서비스ID
			DM_IOT_AUTH_ID			0x29	인증ID(MAC Address or ISDN)
			DM_IOT_MANUFACTURE_ID	0x2A	제조사ID
			DM_IOT_SERVER_PORT		0x2B	서비스ID 에 할당된 접속 port

		*/
		case define.REGISTER_DEVICE :
			offset = encode.TLV_String(packet, define.DM_IOT_PROTOCOL_TYPE, content.DM_IOT_PROTOCOL_TYPE, offset);
			offset = encode.TLV_Short(packet, define.DM_IOT_SP_USE_FLAG, content.DM_IOT_SP_USE_FLAG, offset);
			
			if(content.DM_IOT_PROTOCOL_TYPE == "oneM2M"){
				
				offset = encode.TLV_String(packet, define.DM_IOT_DEVICE_NAME, content.DM_IOT_DEVICE_NAME, offset);
				offset = encode.TLV_String(packet, define.DM_IOT_PASS_CODE, content.DM_IOT_PASS_CODE, offset);
				offset = encode.TLV_String(packet, define.DM_IOT_UKEY, content.DM_IOT_UKEY, offset);	
				
			}else if(content.DM_IOT_PROTOCOL_TYPE == "GMMP"){

				offset = encode.TLV_String(packet, define.DM_IOT_SERVICE_ID, content.DM_IOT_SERVICE_ID, offset);
				offset = encode.TLV_String(packet, define.DM_IOT_AUTH_ID, content.DM_IOT_AUTH_ID, offset);
				offset = encode.TLV_String(packet, define.DM_IOT_MANUFACTURE_ID, content.DM_IOT_MANUFACTURE_ID, offset);
				offset = encode.TLV_Integer(packet, define.DM_IOT_SERVER_PORT, content.DM_IOT_SERVER_PORT, offset);
				
			}else{
				throw "REGISTER_DEVICE - UNKNOWN PROTOCOL TYPE";
			}
			break;
			
			
			
			
		/*
			1044 - SET_INTERVAL
			Sensor 정보 수집주기 및 Sensor 정보 ThingPlug 서버 등록 주기 정보를 요청
			DM_SENSOR_GATHER_INTERVAL			0x72	센서정보수집주기
			DM_SENSOR_SERVER_UPDATE_INTERVAL	0x73	센서정보서버 UDPATE주기
		*/
		case define.SET_INTERVAL :
			offset = encode.TLV_Integer(packet, define.DM_SENSOR_GATHER_INTERVAL, content.DM_SENSOR_GATHER_INTERVAL, offset);
			offset = encode.TLV_Integer(packet, define.DM_SENSOR_SERVER_UPDATE_INTERVAL, content.DM_SENSOR_SERVER_UPDATE_INTERVAL, offset);
			break;
			
			
			
			
		/*
			1061 - SET_TRACE_STATUS
			Sensor 정보 수집주기 및 Sensor 정보 ThingPlug 서버 등록 주기 정보를 요청
			DM_TRACE_STATUS		0x71	Trace ON/OFF
		*/
		case define.SET_TRACE_STATUS :
			offset = encode.TLV_Short(packet, define.DM_TRACE_STATUS, content.DM_TRACE_STATUS, offset);
			break;
			
			
			
		/*
			1062 - UPDATE_LOG
			로그정보 업데이트시 이를 MA에 전달한다
		 	
			DM_LOG_TYPE			0x61	요청로그타입
			DM_LOG_LEVEL		0x62	로그레벨
			DM_LOG_DEVICE_ID	0x66	로그디바이스ID
			DM_LOG_SENSOR_ID	0x67	로그SENSORID
			DM_LOG_DATA			0x64	로그데이터

		*/	
		case define.UPDATE_LOG :
			offset = encode.TLV_Integer(packet, define.DM_LOG_TYPE, content.DM_LOG_TYPE, offset);
			offset = encode.TLV_Integer(packet, define.DM_LOG_LEVEL, content.DM_LOG_LEVEL, offset);
			offset = encode.TLV_String(packet, define.DM_LOG_DEVICE_ID, content.DM_LOG_DEVICE_ID, offset);
			offset = encode.TLV_String(packet, define.DM_LOG_SENSOR_ID, content.DM_LOG_SENSOR_ID, offset);
			offset = encode.TLV_String(packet, define.DM_LOG_DATA, content.DM_LOG_DATA, offset);
			break;
	
		
		/*
			1063 - GET_SYSTEM_LOG
		 	로그정보를 요청한다. (미들웨어와 ThingPlug연동로그 및 미들웨어와 센서 연동로그 포함)
			
			DM_LOG_TYPE		0x61	요청로그타입
			DM_LOG_NEXT_KEY	0x63	Next Key
			DM_LOG_COUNT	0x65	요청COUNT
	
		*/
		case define.GET_SYSTEM_LOG :
			offset = encode.TLV_Integer(packet, define.DM_LOG_TYPE, content.DM_LOG_TYPE, offset);
			offset = encode.TLV_String(packet, define.DM_LOG_NEXT_KEY, content.DM_LOG_NEXT_KEY, offset);
			offset = encode.TLV_Integer(packet, define.DM_LOG_COUNT, content.DM_LOG_COUNT, offset);
			break;
		

		default : 
			
			break;
	}

	
	return offset;
	
}



encode.TLV_String = function(packet, contentType, description, offset){
	
	// Type 1Byte
	packet.writeUInt8(contentType, offset);
	offset += 1;
	// Length 2Byte
	packet.writeUInt16LE(description.length, offset);
	offset += 2;
	// Value nByte
	packet.write(description, offset, offset + description.length, 'binary');
	offset += description.length;
	return offset;
}

encode.TLV_Integer = function(packet, contentType, description, offset){
	
	// Type 1Byte
	packet.writeUInt8(contentType, offset);
	offset += 1;
	// Length 2Byte
	packet.writeUInt16LE(0X0004, offset);
	offset += 2;
	// Value nByte
	packet.writeUInt32LE(description, offset);
	offset += 4;
	return offset;
}

encode.TLV_Short = function(packet, contentType, description, offset){
	
	// Type 1Byte
	packet.writeUInt8(contentType, offset);
	offset += 1;
	// Length 2Byte
	packet.writeUInt16LE(0X0002, offset);
	offset += 2;
	// Value nByte
	packet.writeUInt16LE(description, offset);
	offset += 2;
	return offset;
}

encode.TLV_Char = function(packet, contentType, description, offset){
	
	// Type 1Byte
	packet.writeUInt8(contentType, offset);
	offset += 1;
	// Length 2Byte
	packet.writeUInt16LE(0X0001, offset);
	offset += 2;
	// Value nByte
	packet.writeUInt8(description, offset);
	offset += 1;
	
	return offset;
}




















