
/**
 *
 * 환경설정 > 관리자 설정
 *
 */

(function () {
	
	var isAuthOneM2M = false;
	var DM_IOT_DEV_REG_STATE;

	$(function () {
		
		//ipc.start();

		init();

		onCheckStatus();

		// radiobox check event
		$("input[name=rdo_protocol]").bind("change", onCheckStatus);

		// 다른 아이디로 로그인
		$(".bt_modify").click(function (e) {

			e.preventDefault();
			$(".modify-field").show();

		});

		// OneM2M 정보확인 (임시)
		$(".bt_onem2m_check").click(function (e) {

			e.preventDefault();

			if ($("input[name='onem2m_id']").Empty("ThingPlug " + __("아이디를 입력하세요"))) return;
			if ($("input[name='onem2m_pw']").Empty("ThingPlug " + __("비밀번호를 입력하세요"))) return ;

			var ID = $("input[name='onem2m_id']").val();
			var PASS = $("input[name='onem2m_pw']").val();

			var params = new Params();
			params.put("ID", ID);
			params.put("PASS", PASS);

			ipc.start();

			setTimeout(function () {
				ipc.send("checkThingplugUserInfo", params, function (res) {

					ipc.end();

					if (!res.ThingPlug) return;

					if (res.ThingPlug.result_code[0] == 200) {
						$("input[name='uKey']").val(res.ThingPlug.user[0].uKey);
						isAuthOneM2M = true;
						alert(__("확인되었습니다"));
					} else {	// 인증실패
						alert(res.ThingPlug.result_msg[0]);
					}
				});
			}, 500);
		});

		//  다음버튼
		$(".bt_submit").click(function (e) {

			e.preventDefault();

			var type = $("input[name=rdo_protocol]:checked").val();

			var isValidation = false;

			var params = new Params();
			params.put("DM_IOT_PROTOCOL_TYPE", type);

			if (type == "oneM2M") { // oneM2M
				isValidation = validationOneM2M();
				if (isValidation) {
					//params.put("onem2m_id", $("input[name='onem2m_id']").val());
					//params.put("onem2m_pw", $("input[name='onem2m_pw']").val());
					params.put("DM_IOT_DEVICE_NAME", $("input[name='onem2m_device_id']").val());
					params.put("DM_IOT_PASS_CODE", $("input[name='onem2m_passcode']").val());
					params.put("DM_IOT_UKEY", $("input[name='uKey']").val());
					//params.put("onem2m_mac", $("input[name='onem2m_mac']").val());
				}
			} else {
				isValidation = validationGMMP();
				if (isValidation) {
					params.put("DM_IOT_SERVICE_ID", $("input[name='gmmp_service_id']").val());
					params.put("DM_IOT_MANUFACTURE_ID", $("input[name='gmmp_create_id']").val());
					params.put("DM_IOT_AUTH_ID", $("input[name='gmmp_macaddress']").val());
					params.put("DM_IOT_SERVER_PORT", $("input[name='gmmp_port']").val());
				}
			}

			//params.put("userId", $("input[name='userId']").val());
			params.put("DM_IOT_SP_USE_FLAG", $("input[name='platform']:checked").val() ? IPC.DM_IOT_SP_USE : IPC.DM_IOT_SP_NO_USE);
			
			if (isValidation) {

				ipc.start();

				// 기존에 있는 정보 리셋
				ipc.send("reset", false, function (res) {
					if (res.DM_RESULT == IPC.DM_RESULT_SUCCESS) {
						// 기기 Thungplug 등록
						ipc.send("registerDevice", params, function (res) {
							
							ipc.end();

							if (res.DM_RESULT == IPC.DM_RESULT_SUCCESS) {
								window.location.reload();
							} else if (res.DM_RESULT == IPC.DM_RESULT_ALEADY_REGISTERED) {
								alert(__("이미 등록 되어있는 디바이스 입니다"));
							} else if (res.DM_RESULT == IPC.DM_RESULT_OTHER_REGISTERED) {
								alert(__("이미 등록 되어있는 디바이스 아이디입니다"));
							}
						});
					}else{
						ipc.end();
						alert(__("적용 실패"));
					}
				});
			}
		});

		// Thingplug 회원가입
		$(".bt_join").click(function (e) {

			e.preventDefault();

			window.open("thjoin", "IoTPortalPopup");
			$("#IoTPortalForm").submit();

		});
	});

	// OneM2M 유효성
	var validationOneM2M = function () {
		if ($("input[name='onem2m_id']").Empty("ThingPlug " + __("비밀번호를 입력하세요"))) return false;
		if ($("input[name='onem2m_pw']").Empty("ThingPlug " + __("비밀번호를 입력하세요"))) return false;
		if ($("input[name='onem2m_device_id']").Empty(__("디바이스 ID를 입력하세요"))) return false;
		if ($("input[name='onem2m_passcode']").Empty(__("디바이스 패스코드를 입력하세요"))) return false;
		//if ($("input[name='onem2m_mac']").Empty("MAC 주소를 입력하세요.")) return false;

		if (!isAuthOneM2M) {
			alert(__("ThingPlug 정보확인 하셔야 됩니다"));
			return false;
		}

		return true;
	};

	// GMMP 유효성
	var validationGMMP = function () {
		if ($("input[name='gmmp_service_id']").Empty(__("서비스 ID를 입력하세요"))) return false;
		if ($("input[name='gmmp_create_id']").Empty(__("제조사 ID를 입력하세요"))) return false;
		if ($("input[name='gmmp_macaddress']").Empty(__("MAC 주소를 입력하세요"))) return false;
		if ($("input[name='gmmp_port']").Empty(__("Port 번호를 입력하세요"))) return false;
		if (isNaN($("input[name='gmmp_port']").val())) {
			$("input[name='gmmp_port']").focus();
			alert(__("숫자만 입력하세요"));
			return false;
		}
		return true;
	};

	// radiobox check
	var onCheckStatus = function () {
		if($(".rdo_onem2m").is(":checked")) {
			$(".onem2m").show();
			$(".gmmp").hide();
			$("[name='platform']").removeAttr("disabled");
		}
		else if($(".rdo_gmmp").is(":checked")) {
			$(".onem2m").hide();
			$(".gmmp").show();
			$("[name='platform']").attr("disabled", "disabled");
		}
	}

	// 페이지 초기화
	var init = function () {

		// 시스템 정보
		ipc.send("getSystemInfo", false, function (res) {

			//ipc.end();

			if (res.DM_RESULT == IPC.DM_RESULT_SUCCESS) {
				// {"DM_RESULT":1,"DM_DEVICE_MODEL":"Model Name","DM_CPU_TYPE":"CPU 1.5Ghz","DM_RAM_TYPE":"4.0G","DM_BATTERY_TYPE":"1.0","DM_SERIAL_NUMBER":"0xd2dfefea","DM_MAC_ADDRESS":"MA-AA-DC-EF-AE"}
				$("#DM_DEVICE_MODEL").text(res.DM_DEVICE_MODEL);
				$("#DM_MAC_ADDRESS").text(res.DM_MAC_ADDRESS);
				$("#DM_SERIAL_NUMBER").text(res.DM_SERIAL_NUMBER);
				$("#DM_CPU_TYPE").text(res.DM_CPU_TYPE);
				$("#DM_RAM_TYPE").text(res.DM_RAM_TYPE);
				$("#DM_BATTERY_TYPE").text(res.DM_BATTERY_TYPE);

				isNext = true;
			}
		});

		// Thingplug 상태
		ipc.send("getThingStatus", false, function (res) {

			$("#change_div").show();
			// {DM_RESULT: 1, DM_IOT_DEV_REG_STATE: 2, DM_IOT_THING_STATUS: 1}
			if (res.DM_IOT_DEV_REG_STATE == IPC.DM_REGISTERED) {	// 기등록
				$(".guideMsg").show();
				$(".modify-field").hide();
			} else {	// 미등록
				$(".guideMsg").hide();
				$(".modify-field").show();
			}
		}, function () {
			$("#change_div").show();
			$(".guideMsg").hide();
			$(".modify-field").show();
		});
	};
})();