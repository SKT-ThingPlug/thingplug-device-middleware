/**
 * @file Foundation.h
 *
 * @brief Foundation include header
 *
 * Copyright (C) 2015. SPTek,All Rights Reserved.
 * Written 2015,by SPTek
 */

#ifndef __FOUNDATION_H_
#define __FOUNDATION_H_

#include "SPTekDebug.h"
#include "ErrorDefinition.h"

#endif//__FOUNDATION_H_

