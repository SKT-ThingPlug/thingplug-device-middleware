/**
 * @file undefine.c
 *
 * @brief UNDEFINE Sensor Device Handler
 *
 * Copyright (C) 2015. SPTek,All Rights Reserved.
 * Written 2015,by SPTek
 */
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <string.h>
#include "undefine.h"



#include "SensorConfiguration.h"
#include "1W/ds18b20.h"
#include "I2C/htu21d.h"
#include "I2C/bh1750.h"


/*
 ****************************************
 * UNDEFINE device Main Handle Functions
 ****************************************
 */

/**
 * @brief UNDEFINE device init function
 * @param[in] No parameter
 * @return	 0 => Success init
 * 		-1 => Error file open
 */
int UNDEFINEInit(void)
{
	return 0;
}


/**
 * @brief UNDEFINE device UNDEFINE value read funciton
 * @param[in] SPTekSENSOR_INFO_T structure member mLastValue pointer
 * @return	 0 => Success read data
 * 		-3 => Error read operation
 * 		-4 => Error lseek operation
 */
int UNDEFINERead(char *data, int *len)
{
	int	 tot_len = 0;
	char sdata[MAX_LEN_LAST_VALUE+1];

	memset(sdata, 0x00, 126);

	// Temp
	DS18B20Read(sdata, len);
	strcat(data, "temperature:");
	strcat(data, sdata);
	strcat(data, ";");

	// Light
	BH1750Read(sdata, len);
	strcat(data, "light:");
	strcat(data, sdata);
	strcat(data, ";");

	// Humi
	HTU21DRead(sdata, len);
	strcat(data, "humidity:");
	strcat(data, sdata);

	*len = strlen(data);

	return 0;
}




/**
 * @brief UNDEFINE device close funciton
 * @param[in] No parameter
 * @return 0 = default
 */
int UNDEFINEClose(void)
{

	HTU21DClose();
	DS18B20Close();
	BH1750Close();

	return 0;
}

/**
 * @brief UNDEFINE Extract UNDEFINE value
 * @param[in] Raw Data
 * @return 0 = UNDEFINE Value
 */
int getUNDEFINEValue(char *data)
{
	return 0;
}
