/**
 * @file HC_SR501.c
 *
 * @brief Motion Detection Sensor Device Handler
 *
 * Copyright (C) 2015. SPTek,All Rights Reserved.
 * Written 2015,by SPTek 
 */
#include <stdio.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <string.h>
#include "HC_SR501.h"

/*
 **************************************** 
 * Definition & Global Variable
 **************************************** 
 */
#define BUFF_SIZE      128
#define READ_SIZE      4
#define FILE_NAME      "/sys/class/gpio/gpio51/value"
#define SYSTEM_COMMAND "echo 51 > /sys/class/gpio/export"

static int gHC_SR501Fd;

/*
 **************************************** 
 * HC_SR501 device Main Handle Functions 
 **************************************** 
 */

/**
 * @brief HC_SR501 device init function
 * @param[in] No parameter
 * @return	 0 => Success init
 * 		-1 => Error file open 
 * @detail	echo 51 > /sys/class/gpio/export => Enable gpio 51
 * 		open file => /sys/class/gpio/gpio51/value
 */
int HC_SR501Init(void)
{
	char cmd[BUFF_SIZE] = "echo 51 > /sys/class/gpio/export";
	system(cmd);
	return 0;
}

/**
 * @brief HC_SR501 device value read funciton
 * @param[in] SPTekSENSOR_INFO_T structure member mLastValue pointer
 * @return	 0 => Success read data
 * 		-3 => Error read operation 
 * 		-4 => Error lseek operation 
 */
int HC_SR501Read(char *data, int *len)
{
	char buf[READ_SIZE];
	int  readByte = 0;
	memset(buf,0,READ_SIZE);

	gHC_SR501Fd = open(FILE_NAME, O_RDONLY, S_IREAD);
	if(gHC_SR501Fd < 0) {
		sprintf(data,"N/A:OPEN");
		*len = strlen(data);
		return 0;
	}

	readByte = read(gHC_SR501Fd, buf, READ_SIZE);
	if(readByte <= 0) {
		sprintf(data,"N/A:READ");
		*len = strlen(data);
		close(gHC_SR501Fd);
		return 0;
	}
	lseek(gHC_SR501Fd, 0, SEEK_SET);

	buf[1] = '\0';
	(void)memcpy(data ,buf, strlen(buf));
	*len = strlen(buf);

	if(gHC_SR501Fd < 0) {
		sprintf(data,"N/A:CLOSE");
		*len = strlen(data);
		return 0;
	}
	close(gHC_SR501Fd);
	return 0;
}

/**
 * @brief HC_SR501 device close funciton
 * @param[in] No parameter
 * @return 0 = default
 */
int HC_SR501Close(void)
{
	return 0;
}
