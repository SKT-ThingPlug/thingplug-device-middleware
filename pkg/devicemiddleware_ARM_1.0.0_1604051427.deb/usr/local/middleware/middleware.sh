#!bin/sh


PORT=8000

if [ -z $BASE_DIR ]; then
        #BASE_DIR=`readlink -f $(dirname "$0")`
        BASE_DIR=/usr/local/middleware
        GP_DIR="$BASE_DIR/gp"
        LOG_DIR="$BASE_DIR/log"
fi

MA=ManagementAgent
SMA=SensorManagementAgent
SRA=ServiceReadyAgent
GP=GatewayPortal
PM=ProcessorManager

GPP="$GP_DIR/$GP"
GPC="$GPP/server.js"
CONF_FILE="$2"

W1="BB-W1"
GPIO="BB-IGOT-GPIO"
UART="BB-UART5"


stop(){

        #for agent in $MA $SMA $SRA $GPC $GPP $PM
        until [ -z "$1" ]
        do
                agent="$1"
                #echo $agent
                process=`ps -ef|grep -w "$agent"|grep -v grep|awk '{print $2}'`
                if [ "$process" ]; then
                        for p in "$process"
                        do
#                               echo "> kill process : [$p]"
                                kill -9 $p
                        done
                fi
        shift
        done
}


start(){

        if [ ! -e "$LOG_DIR" ]; then
                mkdir "$LOG_DIR"
        fi

         until [ -z "$1" ]
        do
                agent="$1"
                #echo $agent
                process=`ps -ef|grep -w "$agent"|grep -v grep|awk '{print $2}'`
                if [ ! "$process" ]; then
                        case "$agent" in
                                "$MA")
                                        nohup "$BASE_DIR/$MA" > "$LOG_DIR/MA.log" 2>&1 &
                                        ;;

                                "$SRA")
                                        nohup "$BASE_DIR/$SRA" > "$LOG_DIR/SRA.log" 2>&1 &
                                        ;;

                                "$SMA")
                                        nohup "$BASE_DIR/$SMA" -l "$CONF_FILE" > "$LOG_DIR/SMA.log" 2>&1 &
                                        sleep 3
                                        ;;

                                "$GP")
                                        exec node "$GP_DIR/$GP" "$PORT" 2>&1 >> "$LOG_DIR/gp.log" &
                                        ;;

                                "$PM")
                                        nohup "$BASE_DIR/$PM" > "$LOG_DIR/PM.log" 2>&1 &
                                        ;;

                                *) echo "* $agent"
                                       ;;
                        esac
                fi
        shift
        done
}


set_config(){

        stop "$PM" "$MA" "$SMA" "$SRA"
        start "$MA" "$SMA" "$SRA"

}

sensor_drive_load(){


	if [ -e "/sys/devices/bone_capemgr.9/slots" ]; then
	
		SENSOR_SLOTS=`cat /sys/devices/bone_capemgr.9/slots`
	
	
		for sensor in $W1 $UART $GPIO
		do
		        flag="$sensor"
		        for line in $SENSOR_SLOTS
		        do
		                if [ `echo "$line" | grep "$sensor"` ]; then
		                        flag="false"
		                        break
		                fi
		        done
		
		        case "$flag" in
		
		                "$W1" | "$GPIO" | "$UART" )
		                        echo $flag > /sys/devices/bone_capemgr.9/slots
		                        ;;
		                *)
		                        #echo " $sensor is already loaded"
		                        ;;
		        esac
		done

	fi

	
}


case "$1" in

        start)
		sensor_drive_load
                start "$MA" "$SMA" "$SRA" "$GP"
                ;;

        stop | remove)
                stop "$PM" "$MA" "$SMA" "$SRA" "$GPC" "$GPP"
                ;;

        restart)
                stop "$PM" "$MA" "$SMA" "$SRA" "$GPC" "$GPP"
                start "$MA" "$SMA" "$SRA" "$GP"
                ;;

        upgrade)
                stop "$GPC"
                ;;

	remote)
	                start "$SMA" "$SRA"
		;;
        pmrun)
                stop "$PM"
                start "$PM" 
                ;;

        pmrecovery)
                stop "$MA" "$SMA" "$SRA"
                start "$MA" "$SMA" "$SRA"
                ;;

        pmstop)
                stop "$PM" "$MA" "$SMA" "$SRA"
                ;;

        set_config)
                set_config
                ;;

        *)
                #echo "Usage {start|stop|remove|restart}"
                exit 1
                ;;
esac

exit 0
