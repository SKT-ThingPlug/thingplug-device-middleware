
/**
 *
 * 환경설정 > 관리자 설정
 *
 */

(function () {

	$(function () {

		// 적용하기
		$(".bt_submit").click(function (e) {

			e.preventDefault();

			if ($("#userId").Empty(__("아이디를 입력하세요"))) return;
			if ($("#userNowPassword").Empty(__("현재 비밀번호를 입력하세요"))) return;
			if ($("#userPassword").Empty(__("비밀번호를 입력하세요"))) return;
			if ($("#userPassword2").Empty(__("비밀번호를 입력하세요"))) return;

			if ($("#userPassword").val() != $("#userPassword2").val()) {
				alert(__("변경할 비밀번호가 일치하지 않습니다"));
				$("#userPassword2").focus();
				return;
			}

			var params = new Params();
			params.put("DM_ADMIN_ID", $("#userOldId").val());
			params.put("DM_ADMIN_PASSWD", $("#userNowPassword").val());
			params.put("DM_ADMIN_NEW_ID", $("#userId").val());
			params.put("DM_ADMIN_NEW_PASSWD", $("#userPassword2").val());

			ipc.send("changeAuth", params, function (res) {
				if (res.DM_RESULT == IPC.DM_RESULT_SUCCESS) {
					alert(__("정상적으로 변경되었습니다"));
					window.location.reload();
				} else if (res.DM_RESULT == IPC.DM_RESULT_ALEADY_REGISTERED) {
					alert(__("비밀번호가 일치하지 않습니다"));
				} else {
					alert(__("변경에 실패하였습니다"));
				}
			});
		});
	});
})();