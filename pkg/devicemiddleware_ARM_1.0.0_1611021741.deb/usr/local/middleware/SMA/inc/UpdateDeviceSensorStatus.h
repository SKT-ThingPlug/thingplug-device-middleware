/**
 * @file UpdateDeviceSensorStatus.h
 *
 * @brief Update device sensor status command header
 *
 * Copyright (C) 2015. SPTek,All Rights Reserved.
 * Written 2015,by SPTek
 */

#ifndef __UPDATE_DEVICE_SENSOR_STATUS_H__
#define __UPDATE_DEVICE_SENSOR_STATUS_H__

#include "BaseCommand.h"

/*
 ****************************************
 * Public Functions
 ****************************************
 */
int UpdateDeviceSensorStatus(void *inputSensor);
int UpdateDeviceSensorStatusCommandProcess(SPTekRECEIVE_MESSAGE_T *receiveMessage);
int UpdateSensorHandlerStatusCommandProcess(SPTekRECEIVE_MESSAGE_T *receiveMessage, char* logMessage);
#endif /* __UPDATE_DEVICE_SENSOR_STATUS_H__*/
