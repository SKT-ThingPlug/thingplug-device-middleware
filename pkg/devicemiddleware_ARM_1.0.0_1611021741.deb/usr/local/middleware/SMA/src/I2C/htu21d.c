/**
 * @file htu21d.c
 *
 * @brief Humidity Sensor Device Handler
 *
 * Copyright (C) 2015. SPTek,All Rights Reserved.
 * Written 2015,by SPTek 
 */
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <string.h>
#include <sys/ioctl.h>
#include <linux/i2c.h>
#include <linux/i2c-dev.h>
#include "htu21d.h"
#include "SensorManager.h"

/*
 **************************************** 
 * Definition & Global Variable
 **************************************** 
 */
#define HUMIDITY_ADDRESS  0x40
#define DEVICE_REG_READ   0xE7
#define DEVICE_REG_HUMD   0xE5
#define BUFF_SIZE         3
#define ADAPTER_NUMBER    1

#define DEV_I2C_NUMBER    "/dev/i2c-%d"

static int gHTU21DFd;


/*
 **************************************** 
 * HTU21D device Main Handle Functions 
 **************************************** 
 */

/**
 * @brief HTU21D device init function
 * @param[in] No parameter
 * @return	 0 => Success init
 * 		-1 => Error file open 
 */
int HTU21DInit(void *ops)
{
	SENSOR_OPERATIONS_T *operations = (SENSOR_OPERATIONS_T *)ops;

	operations->Read = HTU21DRead;
	operations->Close = HTU21DClose;
	operations->Control = NULL;
	return 0;
}

/**
 * @brief HTU21D device humidity value read funciton
 * @param[in] SPTekSENSOR_INFO_T structure member mLastValue pointer
 * @return	 0 => Success read data
 * 		-1 => Error ioctl operation 
 * 		-2 => Error write operation 
 * 		-3 => Error read operation 
 */
int HTU21DRead(char *data, int *len)
{
	char fileName[20];
	char  buf[BUFF_SIZE];
	int   sensorData[3];
	int   readByte  = 0;
	float value     = 0;
	int   writeByte = 0;

	memset(sensorData, 0, 3);
	memset(buf,0,BUFF_SIZE);
	memset(fileName, 0, 20);

	snprintf(fileName, 19, DEV_I2C_NUMBER, ADAPTER_NUMBER);
	gHTU21DFd = open(fileName, O_RDWR);
	if(gHTU21DFd < 0) {
		sprintf(data,"N/A:OPEN");
		*len = strlen(data);
		return 0;
	}

	if(ioctl(gHTU21DFd, I2C_SLAVE, HUMIDITY_ADDRESS) < 0) {
		sprintf(data,"N/A:IOCTL");
		*len = strlen(data);
		close(gHTU21DFd);
       	return 0;
	}

	memset(buf,0,BUFF_SIZE);
	buf[0] = DEVICE_REG_READ;
	writeByte = write(gHTU21DFd,buf,1);
	if(writeByte < 0) {
		sprintf(data,"N/A:WRITE");
		*len = strlen(data);
		close(gHTU21DFd);
		return 0;
	}

	buf[0] = DEVICE_REG_HUMD;
	writeByte = write(gHTU21DFd,buf,1);
	if(writeByte < 0) {
		sprintf(data,"N/A:WRITE");
		*len = strlen(data);
		close(gHTU21DFd);
		return 0;
	}

	readByte = read(gHTU21DFd, buf, BUFF_SIZE);
	if(readByte <= 0) {
		sprintf(data,"N/A:READ");
		*len = strlen(data);
		close(gHTU21DFd);
		return 0;
	}

	lseek(gHTU21DFd,0,SEEK_SET);

	sensorData[0] = (int)buf[0];
	sensorData[1] = (int)buf[1];

	value = (((125.0*(((256*sensorData[0]) + sensorData[1])&0xFFFC))/65536) - 6);	
	sprintf(data,"%.3f",value);
	*len = strlen(data);

	if(gHTU21DFd < 0) {
		sprintf(data,"N/A:CLOSE");
		*len = strlen(data);
		return 0;
	}
	close(gHTU21DFd);
	return 0;
}

/**
 * @brief HTU21D device close funciton
 * @param[in] No parameter
 * @return 0 = default
 */
int HTU21DClose(void)
{
	return 0;
}

