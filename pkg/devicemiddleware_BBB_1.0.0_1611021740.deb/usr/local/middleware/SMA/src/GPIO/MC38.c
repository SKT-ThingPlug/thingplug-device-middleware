/**
 * @file MC38.c
 *
 * @brief MC38 DOOR Sensor Device Handler
 *
 * Copyright (C) 2015. SPTek,All Rights Reserved.
 * Written 2015,by SPTek
 */
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <string.h>
#include "MC38.h"
#include "Foundation.h"
#include "SensorCommandList.h"

/*
 ****************************************
 * Definition & Global Variable
 ****************************************
 */
#define FILE_PATH "/sys/class/gpio/gpio51/value"
#define ENABLE_GPIO_51 "echo 51 > /sys/class/gpio/export"
#define DATA_MAX_SIZE 2

static FILE *gMC38Fp = NULL;

/*
 ****************************************
 * MC38 device Main Handle Functions
 ****************************************
 */

char* MC38_OPEN(char *commandArg)
{
	SPTekDebugLog(LOG_LEVEL_INFO, "[SMA] DOOR OPEN");
	return "{result:1, device:door, state:1}";
}
char* MC38_CLOSE(char *commandArg)
{
	SPTekDebugLog(LOG_LEVEL_INFO, "[SMA] DOOR CLOSE");
	return "{result:1, device:door, state:0}";
}
/**
 * @brief MC38 device init function
 * @param[in] No parameter
 * @return	 0 => Success init
 * 		-1 => Error file open
 */
int MC38Init(void)
{
	system(ENABLE_GPIO_51);
	RegisterSensorCommand(0x90,"MC38_OPEN",&MC38_OPEN);
	RegisterSensorCommand(0x91,"MC38_CLOSE",&MC38_CLOSE);
	return 0;
}

/**
 * @brief MC38 device DOOR value read funciton
 * @param[in] SPTekSENSOR_INFO_T structure member mLastValue pointer
 * @return	 0 => Success read data
 * 		-3 => Error read operation
 * 		-4 => Error lseek operation
 */
int MC38Read(char *data, int *len)
{

	char buf[DATA_MAX_SIZE];

	gMC38Fp = fopen(FILE_PATH,"r");
		
	if(gMC38Fp == NULL) {
		sprintf(data,"N/A");
		*len = strlen(data);
		return 0;
	}

	(void)memset(data,0,DATA_MAX_SIZE);
	fgets( buf, DATA_MAX_SIZE, gMC38Fp);
	
	buf[1] = '\0';
	(void)memcpy(data ,buf, strlen(buf));
	*len = strlen(buf);

	fclose(gMC38Fp);
	gMC38Fp = NULL;


	return 0;
}

/**
 * @brief MC38 device close funciton
 * @param[in] No parameter
 * @return 0 = default
 */
int MC38Close(void)
{
	return 0;
}

/**
 * @brief MC38 Extract DOOR value
 * @param[in] Raw Data
 * @return 0 = DOOR Value
 */
int getMC38Value(char *data)
{
	return 0;
}

