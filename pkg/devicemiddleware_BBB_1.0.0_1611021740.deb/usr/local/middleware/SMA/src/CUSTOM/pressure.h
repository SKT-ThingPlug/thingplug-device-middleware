/*
 * @file pressure.h
 *
 * @brief PRESSURE Sensor handler header
 *
 * Copyright (C) 2015. SPTek,All Rights Reserved.
 * Written 2015,by SPTek
 */

#ifndef _PRESSURE_H_
#define _PRESSURE_H_

/*
 ****************************************
 * Enumerations
 ****************************************
 */


/*
 ****************************************
 * Major Functions
 ****************************************
 */

/**
 * @brief PRESSURE device init function
 * @param[in] No parameter
 * @return	 0 => Success init
 * 		-1 => Error file open
 */
int PRESSUREInit(void);

/**
 * @brief PRESSURE device button value read funciton
 * @param[in] SPTekSENSOR_INFO_T structure member mLastValue pointer
 * @return	 0 => Success read data
 * 		-1 => Error ioctl operation
 * 		-2 => Error write operation
 * 		-3 => Error read operation
 */
int PRESSURERead(char *data, int *len);

/**
 * @brief PRESSURE device close funciton
 * @param[in] No parameter
 * @return 0 = default
 */
int PRESSUREClose(void);


#endif //_PRESSURE_H_
