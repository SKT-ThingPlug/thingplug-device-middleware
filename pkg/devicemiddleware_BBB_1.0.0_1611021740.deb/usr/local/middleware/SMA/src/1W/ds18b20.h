/**
 * @file ds18b20.h
 *
 * @brief Temperature Sensor Device Handler Header
 *
 * Copyright (C) 2015. SPTek,All Rights Reserved.
 * Written 2015,by SPTek 
 */
#ifndef _DS18B20_H_
#define _DS18B20_H_

/*
 **************************************** 
 * Major Functions
 **************************************** 
 */

/**
 * @brief DS18B20 device init function
 * @param[in] No parameter
 * @return	 0 => Success init
 * 		-1 => Error file open 
 */
int DS18B20Init(void* ops);

/**
 * @brief DS18B20 device temperature value read funciton
 * @param[in] SPTekSENSOR_INFO_T structure member mLastValue pointer
 * @return	 0 => Success read data
 * 		-3 => Error read operation 
 * 		-4 => Error lseek operation 
 */
int DS18B20Read(char *data, int *len);

/**
 * @brief DS18B20 device close funciton
 * @param[in] No parameter
 * @return 0 = default
 */
int DS18B20Close(void);

#endif //_DS18B20_H_
