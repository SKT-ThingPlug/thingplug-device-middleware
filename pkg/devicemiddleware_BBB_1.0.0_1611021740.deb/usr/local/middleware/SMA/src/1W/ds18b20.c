/**
 * @file ds18b20.c
 *
 * @brief Temperature Sensor Device Handler
 *
 * Copyright (C) 2015. SPTek,All Rights Reserved.
 * Written 2015,by SPTek 
 */
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <string.h>
#include "ds18b20.h"
#include "Foundation.h"
#include "SensorManager.h"

/*
 **************************************** 
 * Definition & Global Variable
 **************************************** 
 */
#define BUFF_SIZE  128
#define MASTER_FILENAME  "cat /sys/bus/w1/devices/w1_bus_master1/w1_master_slaves"

char slavePath[256];
int getTemperatureValue(char *data);
int DS18B20FileOpen(void);
int DS18B20FileClose(void);

#ifdef PLATFORM_PI
static char gDummyData[10][20] =
{"20.1","20.2","20.3","20.4","20.5","20.1","20.3","20.0","20.1","20.1"};
static int gIndex = 0;
#endif
/*
 **************************************** 
 * DS18B20 device Main Handle Functions 
 **************************************** 
 */

/**
 * @brief DS18B20 device init function
 * @param[in] No parameter
 * @return	 0 => Success init
 * 		-1 => Error file open 
 */
int DS18B20Init(void *ops)
{
#ifdef PLATFORM_PI
	SENSOR_OPERATIONS_T *operations = (SENSOR_OPERATIONS_T *)ops;
	operations->Read = DS18B20Read;
	operations->Close = DS18B20Close;
	operations->Control = NULL;
	return 0;
#else
	FILE *gW1MasterFd;
	char slaveName[256];
	int ret = 0;
	SENSOR_OPERATIONS_T *operations = (SENSOR_OPERATIONS_T *)ops;
	gW1MasterFd = popen(MASTER_FILENAME, "r");
	if(gW1MasterFd == NULL) { 	
		return -1;
	}
	(void)memset(slaveName,0,256);
	fgets(slaveName,255,gW1MasterFd);
	slaveName[strlen(slaveName)-1] = '\0';
	sprintf(slavePath,"/sys/bus/w1/devices/");
	strcat(slavePath,slaveName);
	strcat(slavePath,"/w1_slave");
    pclose(gW1MasterFd);

	operations->Read = DS18B20Read;
	operations->Close = DS18B20Close;
	operations->Control = NULL;

	return ret;
#endif
}

/**
 * @brief DS18B20 device temperature value read funciton
 * @param[in] SPTekSENSOR_INFO_T structure member mLastValue pointer
 * @return	 0 => Success read data
 * 		-3 => Error read operation 
 * 		-4 => Error lseek operation 
 */
int DS18B20Read(char *data, int *len)
{
#ifdef PLATFORM_PI
	strcpy(data,gDummyData[gIndex]);
	*len = strlen(data);
	gIndex++;
	gIndex %= 10;
	return 0;
#else
	float value;
	int  readByte = 0;
	char buf[BUFF_SIZE];
	FILE *fp;

	fp = fopen(slavePath, "r");
	if(fp == NULL) {
		sprintf(data, "N/A:OPEN");
		*len = strlen(data);
		return 0;
	}
	
	while((readByte = fread(buf, 1, sizeof buf, fp)) > 0) {
	//	fwrite(buf, 1, readByte, stdout);
		;;
	}
	
	fclose(fp);

	value = (float)getTemperatureValue(buf);
    if( value > 999990) {
		sprintf(data,"N/A:DATAERROR");
        *len = strlen(data);
        return 0;
    }

	value = value / 1000;

	sprintf(data,"%.3f",value);
	if( data[0] == '0' && data[1] == '.' && data[2] =='0' && data[3] == '0') {
		sprintf(data,"N/A:ERROR");
	}

	*len = strlen(data);

	return 0;
#endif
}

/**
 * @brief DS18B20 device close funciton
 * @param[in] No parameter
 * @return 0 = default
 */
int DS18B20Close(void)
{
	return 0;
}


/**
 * @brief DS18B20 Extract temperature value
 * @param[in] Raw Data 
 * @return 0 = Temperature Value
 */
int getTemperatureValue(char *data)
{
	int value = 0;
	if(data == NULL) {
		return 0;
	}
    char *dump = strdup(data);
	char *ptr;
	//Extract temperature value
    fprintf(stderr, ">>>>>>>>>>>>>> temp raw data : %s\n", dump);
	ptr = strtok(dump,"=");
    if( ptr == NULL ) goto error_ret;
	ptr = strtok(NULL,"=");
    if( ptr == NULL ) goto error_ret;
	ptr = strtok(NULL,"=");
    if( ptr == NULL ) goto error_ret;
   
    free(dump);
    value = atoi(ptr);
	return value;

error_ret:
    free(dump);
    value = 999999;
    return value;
}





