#include<stdio.h>
#include<string.h>    //strlen
#include<stdlib.h>    //strlen
#include<sys/socket.h>
#include<arpa/inet.h> //inet_addr
#include<unistd.h>    //write
#include <sys/types.h>
#include <signal.h>
#include <errno.h>

#include "aes.h"
#include "aes_utils.h"

int main(int argc , char *argv[])
{

	printf("\n========= AES Test Start =========\n");
	int nRet, i;

	unsigned char* original;
	unsigned char* encrypted;
	unsigned char* decrypted;
	//original = "Z234567822345678";
	original = "{Z123456782234567832345678A123456782234567832345678B123456782234567832345678CDEF1234";
	printf("original[%d]: %s \n", strlen(original), original);
	
	
	// * init context and generate key *//
	mbedtls_aes_context ctx;
	mbedtls_aes_init( &ctx );
	unsigned char* key = aes_utils_generateKey(128);
	
	
	// * ECB mode Example * //
	printf("\n============ ECB mode ============\n");
	encrypted = (char*)calloc(strlen(original), sizeof(char*));
	mbedtls_aes_setkey_enc( &ctx, key, 128 );
	aes_utils_ecb( &ctx, MBEDTLS_AES_ENCRYPT, aes_utils_make16Drainage(strlen(original)), original, encrypted );
	printf("encrypted[%d]: %s\n", strlen(encrypted), encrypted);

	decrypted  = (char*)calloc(strlen(original), sizeof(char*));
	mbedtls_aes_setkey_dec( &ctx, key, 128 );
	aes_utils_ecb( &ctx, MBEDTLS_AES_DECRYPT, aes_utils_make16Drainage(strlen(original)), encrypted, decrypted );
	printf("decrypted[%d]: %s\n", strlen(decrypted), decrypted);
	
	
	/*
	// * CBC mode Example * //
	// Copy iv before cbc mode ecryption. 
	// Because the iv will be changed after cbc fuction process.
	printf("\n============ CBC mode ============\n");
	unsigned char* iv = aes_utils_generateKey(128);
	unsigned char iv2[strlen(iv) + 1];
	iv2[strlen(iv)] = '\0';
	strcpy(iv2, iv);

	encrypted = (char*)calloc(strlen(original), sizeof(char*));
	mbedtls_aes_setkey_enc( &ctx, key, 128 );
	aes_utils_cbc( &ctx, MBEDTLS_AES_ENCRYPT, aes_utils_make16Drainage(strlen(original)), iv, original, encrypted );
	printf("encrypted[%d]: %s\n", strlen(encrypted), encrypted);

	decrypted  = (char*)calloc(strlen(original), sizeof(char*));
	mbedtls_aes_setkey_dec( &ctx, key, 128 );
	aes_utils_cbc( &ctx, MBEDTLS_AES_DECRYPT, aes_utils_make16Drainage(strlen(original)), iv2, encrypted, decrypted );
	printf("decrypted[%d]: %s\n", strlen(decrypted), decrypted);
*/

}
