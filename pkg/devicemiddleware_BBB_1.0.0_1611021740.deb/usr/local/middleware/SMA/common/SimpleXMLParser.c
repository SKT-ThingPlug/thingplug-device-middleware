/**
 * @file SimpleXMLParser.c
 *
 * @brief Simple XML parser
 *
 * Copyright (C) 2016. SK Telecom, All Rights Reserved.
 * Written 2016, by SK Telecom
 */
#include <string.h>
#include<stdio.h> 

#include "SPTekDebug.h"

void SimpleXMLParser(char* payload, char* name, char* value, int isPC) {
    char start[10];
    char end[10];
    char* pl = payload;
    memset(start, 0, sizeof(start));
    memset(end, 0, sizeof(end));

    if(isPC) {
        pl = strstr(payload, "<pc>");
        if(!pl) return;
    }

    snprintf(start, sizeof(start), "<%s>", name);
    snprintf(end, sizeof(end), "</%s>", name);
    
    char* s = strstr(pl, start);
    char* e = strstr(pl, end);

	// oneM2M v1.12 rn
	if(!s && strcmp("rn", name) == 0) {
		memset(start, 0, sizeof(start));
		int size = strlen("rn=\"");
	    memcpy(start, "rn=\"", size);
		s = strstr(pl, start) + size;
		e = strstr(s, "\"");
		memcpy(value, s, e-s);				
	} else {
		if(s && e) {
			s += strnlen(start, sizeof(start));
			memcpy(value, s, e-s);
	    }
	}
    SPTekDebugLog(LOG_LEVEL_INFO, "[%s : %s]", name, value);
} 
 
