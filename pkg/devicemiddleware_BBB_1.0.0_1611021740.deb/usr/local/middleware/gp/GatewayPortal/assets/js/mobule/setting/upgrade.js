
/**
 *
 * 환경설정 > 업그레이드
 *
 */

(function () {

	$(function () {

		init();
		
		onCheckFileStatus();

		// file upload select
		$(".lbRdo .rdoBg").bind("change", onCheckFileStatus);

		// input file check
		function onCheckFileStatus() {
			var inputFile = $(".hidFile");
			var fileLabel = $(inputFile).siblings(".fileName");
			var helpText = fileLabel.attr("title");

			if($(".customUpgrage").is(":checked")) {
				inputFile.prop("disabled", false);
			}
			else if($(".autoUpgrage").is(":checked")) {
				inputFile.prop("disabled", true);
			}

			if($(inputFile).is(":disabled")) {
				fileLabel.addClass("disabled").text("");
			}
			else {
				fileLabel.removeClass("disabled").text(helpText);
			}
		}

		// file event
		$(document).on("change", ".hidFile", function(evt) {
			var file = $(this).val().split(/(\\|\/)/g).pop();
			var ext = file.split(".").pop();
			var fileLabel = $(this).siblings(".fileName");
			var helpText = fileLabel.attr("title");

			if(file.length > 1) fileLabel.text(file);
			else fileLabel.text(helpText);
		}).on("reset", "form", function(evt) {
			var length = $(this).find(".hidFile").length;

			if(length > 0) {
				var helpText = $(this).find(".hidFile").parents("label").eq(0).siblings(".fileName").attr("title");
				$(this).find(".hidFile").parents("label").eq(0).siblings(".fileName").text(helpText);
			}
		});

		// 실행버튼
		$(".bt_upgrade").click(function (e) {
			
			if($(".customUpgrage").is(":checked")) {
				ipc.start(1);
				e.preventDefault();
				$("#upgrade_form").submit();
			}
		});
		
		// Auto upgrade
		$(".bt_auto_upgrade").click(function (e) {

			e.preventDefault();
			
			if( !$(this).hasClass("bt_black")) {
				
				alert(__("이미 업그레이드 되었습니다."));
				
			}else{
				
				var newForm = $("<form />", {
					"action" : "/API/middlewareUpgrade",
					"method" : "post",
				});
				newForm.submit();
			
				// ipc.send("middlewareUpgrade", false);
			
			}
		});
		
	});
	
	
	var init = function () {
	
		// Get extraInfo
		ipc.send("extraInfo", false, function (res) {
			
			if (res.DM_RESULT == IPC.DM_RESULT_SUCCESS) {

				var currentVer = res.DM_MW_CURRENT_VER;
				var latestVer = res.DM_MW_LATEST_VER;

				$('#currentVersion').html(currentVer);
				$('#latestVersion').html(latestVer);
				
				if (currentVer != latestVer) {
					$(".bt_auto_upgrade").text(__("업그레이드"));
					$(".bt_auto_upgrade").addClass("bt_black").removeClass("bt_grey");
				}
		
			}
		});				
	}
	
})();