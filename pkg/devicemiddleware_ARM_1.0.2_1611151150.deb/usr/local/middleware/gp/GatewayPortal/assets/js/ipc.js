
/**
 *
 * IPC 관련
 *
 */
var IPC = {};
module.exports = IPC;

// 
var net = require('net');
var ping = require("ping");
var decode = require("./decode");
var encode = require("./encode");
var API = require("./MA_API");
var exec = require("child_process").exec;
var define = require("./define");

var ip = "127.0.0.1", PORT = 8058;

//var isLoginBlocked = false;
var totalLoginError = 1;

ip = process.argv[3] == "undefined" ? ip : process.argv[3];

var http_socket = {};
var httpRequest;

// IPC 시작
IPC.start = function () {

	var clientSocket = new net.Socket();

	clientSocket.connect(PORT, ip, function() {
		
		// console.log('CONNECTED TO: ' + ip + ':' + PORT);
		API.pushSocketRegister(clientSocket);	

		setTimeout(IPC.register, 100);
	});

	//subscripber 메시지 응답
	clientSocket.on('data', function(data) {

	
		// console.log("receiving packet");
		// console.log(Date());
		// console.log(data);
		
		var res = decode.decode(data);
		// console.log(res);
		
		if (res.err) console.error(res.err);

		if (res.header.messageType == '1012') {

			IPC.IV();
			
		} else if (res && res.header && http_socket[res.header.messageType]) {
			// 로그인 부분만 세션처리때문에
			if (res.header.messageType == "1001" && res.content.DM_RESULT == 0x01) {
				
				if (res.content.DM_HAS_ACCOUNT != undefined && res.content.DM_HAS_ACCOUNT == 0x02 ) {
					httpRequest.session.userPassword = "adminthingplug";				
				}else{
					httpRequest.session.userId = httpRequest.body.data.data.userId;
					httpRequest.session.userPassword = httpRequest.body.data.data.userPassword;
					
					totalLoginError = 1;
//					isLoginBlocked = false;
				}
				
			} else if (res.header.messageType == "1001" && res.content.DM_RESULT != 0x01) {
				totalLoginError ++;
				res.content.DM_RESULT = totalLoginError;
			} else if (res.header.messageType == "1002" && res.content.DM_RESULT == 0x01) {
				httpRequest.session.userId = httpRequest.body.data.data.DM_ADMIN_NEW_ID;
				httpRequest.session.userPassword = httpRequest.body.data.data.DM_ADMIN_NEW_PASSWD;
				
			} else if (res.header.messageType == "1001" && res.content.DM_RESULT == 0x02) {
				//res.content.DM_RESULT_MESSAGE = "계정정보가 일치하지 않습니다.";
			} else if (res.content.DM_RESULT != 0x01) {
				//res.content.DM_RESULT_MESSAGE = "네트워크 오류입니다.";
			}

			// 요청 타입
			res.content.M_TYPE = res.header.messageType;
			http_socket[res.content.M_TYPE].end(JSON.stringify(res.content));
		}
	});
	
	clientSocket.on('close', function(data) {
		// console.log("socket closed");

		setTimeout(IPC.start, 3000);
	});
	
	clientSocket.on('error', function(error) {
		clientSocket.end();
	});	
	
};


// IPC end
IPC.end = function () {
	clientSocket.end();
};


//라우터 콜백 설정
IPC.ping = function (req, res) {	// ping

	var obj = {};
	obj.DM_RESULT = 0x0001;

	ping.sys.probe(req.body.host, function (isAlive) {
		obj.isAlive = isAlive;
		res.end(JSON.stringify(obj));
	});
};


// Rgister to MA
IPC.register = function () {

	API.register();
	
};


// IV OK call
IPC.IV = function () {

	API.IV();
	
};


//session check
IPC.session = function (req, res) {	// session check

	var obj = {};
	
	if (!req.session.userId) {
		obj.DM_RESULT = 0x0002;
	}else{
		obj.DM_RESULT = 0x0001;
	}

	res.end(JSON.stringify(obj));
		
};


IPC.authentication = function (req, res) {	// 로그인 

	// if (isLoginBlocked) {
	//
	// 	var obj = {};
	// 	obj.DM_RESULT = totalLoginError;
	// 	res.end(JSON.stringify(obj));
	//
	// }else{
		
		httpRequest = req;
		http_socket[define.AUTHENTICATION.toString()] = res;
		
		API.authentication(req.body.data.data.userId, req.body.data.data.userPassword);		
		
	// }
	
};


IPC.changeAuth = function (req, res) {		// 비밀번호 변경

	httpRequest = req;
	http_socket[define.CHANGE_AUTH.toString()] = res;

	var obj = {};

	if (req.session.userPassword == req.body.data.data.DM_ADMIN_PASSWD) {
		
		API.changeAuthentication(req.body.data.data.DM_ADMIN_ID, req.body.data.data.DM_ADMIN_PASSWD, 
							req.body.data.data.DM_ADMIN_NEW_ID, req.body.data.data.DM_ADMIN_NEW_PASSWD);
								
	} else {
		obj.DM_RESULT = 0x0005;
		res.end(JSON.stringify(obj));
	}
	
};

IPC.extraInfo = function (req, res) {		// set device time, log timezone, etc

	http_socket[define.EXTRA_INFO.toString()] = res;
		
		API.extraInfo(req.body.data.data.DM_SERVER_URL, req.body.data.data.DM_TRACE_STATUS, req.body.data.data.DM_TIMEZONE, req.body.data.data.DM_SET_TIME, req.body.data.data.DM_TIME_SYNC);
								
};


IPC.restart = function (req, res) {		// 재구동 요청

	http_socket[define.RESTART.toString()] = res;

	API.restart();
	
};


IPC.middlewareUpgrade = function (req, res) {		// Auto upgrade

	http_socket[define.MIDDLEWARE_UPGRADE.toString()] = res;

	API.middlewareUpgrade();
	
};


IPC.reset = function (req, res) {		// 초기화 요청
	
	http_socket[define.RESET.toString()] = res;
	
	API.reset();

};


IPC.getSystemInfo = function (req, res) {	// 시스템 정보

	http_socket[define.GET_SYSTEM_INFO.toString()] = res;

	API.getSystemInfo();
	
};


IPC.getSystemUsage = function (req, res) {	// 시스템 사용량 정보
	
	http_socket[define.GET_SYSTEM_USAGE.toString()] = res;
	
	API.getSystemUsage();
		
};


IPC.getNetworkInfo = function (req, res) {	// 네트워크 정보

	http_socket[define.GET_NETWORK_INFO.toString()] = res;
	
	API.getNetworkInfo();
	
};


IPC.getProcessStatus = function (req, res) {	// 장치 process 상태정보
	
	http_socket[define.GET_PROCESS_STATUS.toString()] = res;
	
	API.getProcessStatus();
};


IPC.getDeviceSensor = function (req, res) {	// 센서 정보

	http_socket[define.GET_DEVICE_SENSOR.toString()] = res;

	API.getDeviceSensor();
};


IPC.getDeviceSensorStatus = function (req, res) {	// 센서 상태

	http_socket[define.GET_DEVICE_SENSOR_STATUS.toString()] = res;

	API.getDeviceSensorStatus(req.body.data.data.DM_DEVICE_ID, req.body.data.data.DM_SENSOR_ID, 
								req.body.data.data.DM_SENSOR_NAME, req.body.data.data.DM_SENSOR_TYPE);
	
};


IPC.getAllDeviceSensorStatus = function (req, res) {	// 모든 센서 정보 요청
	
	http_socket[define.GET_ALL_DEVICE_SENSOR_STATUS.toString()] = res;

	API.getAllDeviceSensorStatus(req.body.data.data.DM_DEVICE_ID, req.body.data.data.DM_SENSOR_ARRAY);

};



IPC.account = function (req, res) {	// Device unRegistration from Thingplug
	
	http_socket[define.ACCOUNT.toString()] = res;

	API.account(req.body.data.data.DM_IOT_TP_ID, req.body.data.data.DM_IOT_UKEY);

};


IPC.registerDevice = function (req, res) {	// 장치 thingplug 등록
	
	http_socket[define.REGISTER_DEVICE.toString()] = res;

	if ("GMMP" != req.body.data.data.DM_IOT_PROTOCOL_TYPE) {
		API.registerDevice_oneM2M(req.body.data.data.DM_IOT_DEVICE_NAME, req.body.data.data.DM_IOT_PASS_CODE, 
											req.body.data.data.DM_IOT_SP_USE_FLAG, req.body.data.data.DM_IOT_UKEY, req.body.data.data.DM_IOT_TP_ID, req.body.data.data.DM_IOT_PROTOCOL_TYPE);
	} else if ("GMMP" == req.body.data.data.DM_IOT_PROTOCOL_TYPE) {
		API.registerDevice_GMMP(req.body.data.data.DM_IOT_AUTH_ID, req.body.data.data.DM_IOT_SERVICE_ID, 
											req.body.data.data.DM_IOT_SP_USE_FLAG, req.body.data.data.DM_IOT_MANUFACTURE_ID, req.body.data.data.DM_IOT_SERVER_PORT);
	}

};


IPC.unregisterDevice = function (req, res) {	// Device unRegistration from Thingplug
	
	http_socket[define.UNREGISTER_DEVICE.toString()] = res;

	API.unregisterDevice(req.body.data.data.DM_UNREGI_TYPE);

};


IPC.getThingStatus = function (req, res) {	// thingplug 연결 정보

	http_socket[define.GET_THING_STATUS.toString()] = res;

	API.getThingStatus();

};


IPC.getInterval = function (req, res) {	// 센서정보 주기 정보 요청
	
	http_socket[define.GET_INTERVAL.toString()] = res;

	API.getInterval();
};


IPC.setInterval = function (req, res) {	// 센서정보 주기 정보 설정
	
	http_socket[define.SET_INTERVAL.toString()] = res;

	API.setInterval(req.body.data.data.DM_SENSOR_GATHER_INTERVAL, req.body.data.data.DM_SENSOR_SERVER_UPDATE_INTERVAL);

};


IPC.setTraceStatus = function (req, res) {	// trace on/off 요청
	
	http_socket[define.SET_TRACE_STATUS.toString()] = res;

	API.setTraceStatus(req.body.data.data.DM_TRACE_STATUS);
	
};


IPC.updateLog = function (req, res) {	// 로그정보 업데이트 요청

	http_socket[define.UPDATE_LOG.toString()] = res;
	
	API.updateLog(req.body.data.data.DM_LOG_TYPE, req.body.data.data.DM_LOG_LEVEL, 
					req.body.data.data.DM_LOG_SUB_TYPE, req.body.data.data.DM_LOG_DATA);
		
};


IPC.getSystemLog = function (req, res) {	// 시스템 로그
	
	http_socket[define.GET_SYSTEM_LOG.toString()] = res;

	API.getSystemLog(req.body.data.data.DM_LOG_TYPE, req.body.data.data.DM_LOG_NEXT_KEY, req.body.data.data.DM_LOG_COUNT);

};


IPC.getErrorLogCount = function (req, res) {	// 에러 카운트 요청
	
	http_socket[define.GET_ERROR_LOG_COUNT.toString()] = res;

	API.getErrorLogCount();
	
};


IPC.logReset = function (req, res) {	// 로그정보 초기화
	
	http_socket[define.LOG_RESET.toString()] = res;

	API.logReset();
	
};


//디바이스 목록 받아오기
IPC.getDevice = function(req, res){
	
	http_socket[define.GET_DEVICE.toString()] = res;

	API.getDevice();
	
}


// Sensor Config file Change API
IPC.changeSensorConfigFile = function(req, res){
	
	var obj = {};
	exec("service middleware set_config " + req.body.data.data.DM_SENSOR_CONFIG_FILENAME );
	obj.DM_RESULT = 0x0001;
	res.end(JSON.stringify(obj));
	
}







