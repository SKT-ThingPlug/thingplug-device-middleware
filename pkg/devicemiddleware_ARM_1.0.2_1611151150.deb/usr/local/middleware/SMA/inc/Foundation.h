/**
 * @file Foundation.h
 *
 * @brief Foundation include header
 *
 * Copyright (C) 2016. SK Telecom, All Rights Reserved.
 * Written 2016, by SK Telecom
 */

#ifndef __FOUNDATION_H_
#define __FOUNDATION_H_

#include "SPTekDebug.h"
#include "ErrorDefinition.h"
#include "Definitions.h"

#endif//__FOUNDATION_H_

