/**
 * @file BaseCommand.h
 *
 * @brief Base functions for command processing header
 *
 * Copyright (C) 2016. SK Telecom, All Rights Reserved.
 * Written 2016, by SK Telecom
 */

#ifndef __BASE_COMMAND_H__
#define __BASE_COMMAND_H__

#include "DataComposition.h"

/*
 ****************************************
 * Definitions
 ****************************************
 */

#define SOURCE_LENGTHS      16
#define DESTINATION_LENGTHS 16
#define REQUEST_LENGTHS     4
#define CONTENTS_LENGTHS    4
#define RESERVED_LENGTHS    8

#define SKTMESSAGE_HEADER_SIZE (SOURCE_LENGTHS + DESTINATION_LENGTHS + REQUEST_LENGTHS + CONTENTS_LENGTHS + RESERVED_LENGTHS)

/*
 ****************************************
 * Enumerations
 ****************************************
 */

///
typedef enum tagSource {
	SOURCE_NONE = 0,
	SOURCE_MA,
	SOURCE_MAX
}SKTSOURCE_E;

///
typedef enum tagDestination {
	DESTINATION_NONE = 0,
	DESTINATION_MA,
	DESTINATION_MAX
}SKTDESTINATION_E;

///
typedef enum tagCommand {
	SKTCOMMANDTYPE_NONE                   	     = 0,
	SKTCOMMANDTYPE_REGISTER                	     = 1000,
	SKTCOMMANDTYPE_UPDATE_IV						 = 1012,
	SKTCOMMANDTYPE_GET_DEVICE_SENSOR_INFO 	     = 1101,
	SKTCOMMANDTYPE_GET_DEVICE_SENSOR_STATUS 	     = 1102,
	SKTCOMMANDTYPE_UPDATE_DEVICE_SENSOR_STATUS 	 = 1103,
	SKTCOMMANDTYPE_GET_DEVICE_SENSOR_CMD_LIST      = 1104,
	SKTCOMMANDTYPE_DEVICE_SENSOR_CMD               = 1105,
	SKTCOMMANDTYPE_PROCESS_EXIT                    = 1106,
	SKTCOMMANDTYPE_PING                            = 1107,
	SKTCOMMANDTYPE_DEVICE_SENSOR_CONTROL           = 1108,
	SKTCOMMANDTYPE_GET_DEVICE_SENSOR_BYTE_CMD_LIST = 1121,
	SKTCOMMANDTYPE_DEVICE_SENSOR_BYTE_CMD          = 1122,
	SKTCOMMANDTYPE_GET_DEVICE_ALL_SENSOR_STATUS    = 1024,
	SKTCOMMANDTYPE_SET_TRACE_STATUS                = 1061,
	SKTCOMMANDTYPE_MAX
}SKTCOMMAND_E;

/*
 ****************************************
 * Structures
 ****************************************
 */

typedef struct tagMessageHeader {
	char mDestination[DESTINATION_LENGTHS];
	char mSource[SOURCE_LENGTHS];
	char mRequest[REQUEST_LENGTHS];
	char mReserved[RESERVED_LENGTHS];
	char mContentsLength[CONTENTS_LENGTHS];
}SKTMESSAGE_HEADER_T;

typedef struct tagReceiveMessage {
	SKTMESSAGE_HEADER_T mHeader;
	SKTLIST_T           *extractList;
}SKTRECEIVE_MESSAGE_T;

typedef struct tagSendMessage {
	int  mLength;
	char *message;
}SKTSEND_MESSAGE_T;

/*
 ****************************************
 * Public Functions
 ****************************************
 */

SKTSOURCE_E GetSourceType(char *source);
char* GetSourceString(void);
char* GetDestination(SKTDESTINATION_E index);
int ExtractMessageHeader(char* message, int length, SKTMESSAGE_HEADER_T *header);
int ExtractArray(char* contents, int contentsLength, SKTITEM_LIST_T *itemList);
int ExtractContents(char* contents, int contentsLength, SKTLIST_T *extract);
int MakeCommandHeaderMessage(SKTDESTINATION_E index, int lengths, char *request, SKTSEND_MESSAGE_T *sendMessage);
int MakeCommandConentsArray(SKTITEM_LIST_T *itemList, char* content, unsigned short *length);
int MakeCommandConentsMessage(SKTLIST_T *extractList, char* content, int *length);


#endif // __BASE_COMMAND_H__

