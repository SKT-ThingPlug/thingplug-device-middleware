/*
 * SPT_Debug.h
 *
 *  Created on: 2015. 11. 16.
 *      Author: sidn
 */

#ifndef SKTDEBUG_H_
#define SKTDEBUG_H_

/* SPT_LOG_LEVEL
 * 로그 LEVEL을 설정한다.
 */
typedef enum tagSKTLogLevel {
	LOG_LEVEL_NONE =0,
	LOG_LEVEL_VERBOSE,    // 모든 로그를 보여준다.
	LOG_LEVEL_DEBUG,
	LOG_LEVEL_INFO,
	LOG_LEVEL_WARN,
	LOG_LEVEL_ERROR,
	LOG_LEVEL_FATAL,
	LOG_LEVEL_MAX
} SKTLOG_LEVEL_E;

typedef enum tagSKTBooleanType {
	SKTFalse = 0,
	SKTTrue	
} SKTBOOLEAN_TYPE_E;

#ifdef SPT_DEBUG_ENABLE
	#include <stdio.h>
    extern void DebugInit(SKTBOOLEAN_TYPE_E enable, SKTLOG_LEVEL_E level, FILE *stream, char *filename);
	extern void DebugPrintf(const char *filename, int lineno, SKTLOG_LEVEL_E level, const char *format, ...);
	extern void DebugDump(const char *title, const char* data, unsigned long lengths);

	#define SKTtpDebugInit(enable, level, stream, filename) DebugInit(enable, level, stream, filename)
	#define SKTtpDebugLog(level, ...)             DebugPrintf(__FILE__, __LINE__, level, ## __VA_ARGS__)
    #define SKTtpDebugDump(title, data, lengths)  DebugDump(title, data, lengths)
#else
	#define SKTtpDebugInit(enable, level, stream, filename)  ((void)0)
	#define SKTtpDebugLog(...)                           ((void)0)
    #define SKTtpDebugDump(title, data, lengths)         ((void)0)
#endif

#endif /* SKTDEBUG_H_ */
