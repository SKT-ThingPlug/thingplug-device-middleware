/**
 * @file custom.c
 *
 * @brief Custom Sensor Device Handler
 *
 * Copyright (C) 2016. SK Telecom, All Rights Reserved.
 * Written 2016, by SK Telecom
 */
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <string.h>
#include "custom.h"
#include "SensorManager.h"

/*
 ****************************************
 * Definition & Global Variable
 ****************************************
 */
#define BUFF_SIZE  128
#define FILE_NAME  "/sys/bus/w1/devices/28-0315030fecff/w1_slave"

static int gCUSTOMNFd;

static char gDummyData[10][20] = 
	{"One","Two","Three","Four","Five","Six","Seven","Eight","Nine","Ten"};
static int gIndex = 0;

/*
 ****************************************
 * CUSTOM device Main Handle Functions
 ****************************************
 */

/**
 * @brief CUSTOM device init function
 * @param[in] No parameter
 * @return	 0 => Success init
 * 		-1 => Error file open
 */
int CUSTOMInit(void *ops)
{
	SENSOR_OPERATIONS_T *operations = (SENSOR_OPERATIONS_T *)ops;
	//gCUSTOMNFd = open(FILE_NAME, O_RDONLY, S_IREAD);
	gIndex = 0;

	operations->Read = CUSTOMRead;
	operations->Close = CUSTOMClose;
	operations->Control = CUSTOMControl;
	return 0;
}

/**
 * @brief CUSTOM device control function(sample)
 * @param[in] data Control data
 * @param[in] len  Control data length
 * @return	 result Result string
 */
char* CUSTOMControl(char *data, int len)
{
	char result[256];
	char cmd[8] = "";
	char id[126] = "";
    int ret = 0;

    // TODO data parsing & Control

	if( ret == 0 ) {
		sprintf(result,"{\"id\": \"%s\", \"result\": \"%s\"}",id,cmd);
	} else {
		sprintf(result,"{\"id\": \"%s\", \"error\": {\"code\": -32000, \"message\":\"Device not found\"}}",id);
	}

	return strdup(result);
}

/**
 * @brief CUSTOM device CUSTOM value read funciton
 * @param[in]  structure member mLastValue pointer
 * @return	 0 => Success read data
 * 		-3 => Error read operation
 * 		-4 => Error lseek operation
 */
int CUSTOMRead(char *data, int *len)
{
	strcpy(data,gDummyData[gIndex]);
	*len = strlen(data);
	gIndex++;
	gIndex %= 10;
	return 0;
}

/**
 * @brief CUSTOM device close funciton
 * @param[in] No parameter
 * @return 0 = default
 */
int CUSTOMClose(void)
{
	close(gCUSTOMNFd);
	return 0;
}

/**
 * @brief CUSTOM Extract CUSTOM value
 * @param[in] Raw Data
 * @return 0 = CUSTOM Value
 */
int getCUSTOMValue(char *data)
{
	return 0;
}

