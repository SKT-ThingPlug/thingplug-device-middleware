/*
 * @file percent.h
 *
 * @brief PERCENT Sensor handler header
 *
 * Copyright (C) 2016. SK Telecom, All Rights Reserved.
 * Written 2016, by SK Telecom
 */

#ifndef _PERCENT_H_
#define _PERCENT_H_

/*
 ****************************************
 * Enumerations
 ****************************************
 */


/*
 ****************************************
 * Major Functions
 ****************************************
 */

/**
 * @brief PERCENT device init function
 * @param[in] No parameter
 * @return	 0 => Success init
 * 		-1 => Error file open
 */
int PERCENTInit(void);

/**
 * @brief PERCENT device button value read funciton
 * @param[in]  structure member mLastValue pointer
 * @return	 0 => Success read data
 * 		-1 => Error ioctl operation
 * 		-2 => Error write operation
 * 		-3 => Error read operation
 */
int PERCENTRead(char *data, int *len);

/**
 * @brief PERCENT device close funciton
 * @param[in] No parameter
 * @return 0 = default
 */
int PERCENTClose(void);


#endif //_PERCENT_H_
