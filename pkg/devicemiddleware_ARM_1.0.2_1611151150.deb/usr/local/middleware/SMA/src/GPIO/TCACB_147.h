/*
 * @file TCACB_147.h
 *
 * @brief TCACB_147 Noise Sensor handler header
 *
 * Copyright (C) 2016. SK Telecom, All Rights Reserved.
 * Written 2016, by SK Telecom
 */

#ifndef _TCACB_147_H_
#define _TCACB_147_H_

/*
 ****************************************
 * Enumerations
 ****************************************
 */


/*
 ****************************************
 * Major Functions
 ****************************************
 */

/**
 * @brief TCACB_147 device init function
 * @param[in] No parameter
 * @return	 0 => Success init
 * 		-1 => Error file open
 */
int TCACB_147Init(void);

/**
 * @brief TCACB_147 device Noise value read funciton
 * @param[in]  structure member mLastValue pointer
 * @return	 0 => Success read data
 * 		-1 => Error ioctl operation
 * 		-2 => Error write operation
 * 		-3 => Error read operation
 */
int TCACB_147Read(char *data, int *len);

/**
 * @brief TCACB_147 device close funciton
 * @param[in] No parameter
 * @return 0 = default
 */
int TCACB_147Close(void);


#endif //_TCACB_147_H_
