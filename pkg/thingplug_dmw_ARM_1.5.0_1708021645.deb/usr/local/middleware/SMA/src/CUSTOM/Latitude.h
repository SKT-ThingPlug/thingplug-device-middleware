/*
 * @file Latitude.h
 *
 * @brief Latitude Sensor handler header
 *
 * Copyright (C) 2016. SK Telecom, All Rights Reserved.
 * Written 2016, by SK Telecom
 */

#ifndef _LATITUDE_H_
#define _LATITUDE_H_

/*
 ****************************************
 * Enumerations
 ****************************************
 */


/*
 ****************************************
 * Major Functions
 ****************************************
 */

/**
 * @brief Latitude device init function
 * @param[in] No parameter
 * @return	 0 => Success init
 * 		-1 => Error file open
 */
int LatitudeInit(void *ops);

/**
 * @brief Latitude device button value read funciton
 * @param[in]  structure member mLastValue pointer
 * @return	 0 => Success read data
 * 		-1 => Error ioctl operation
 * 		-2 => Error write operation
 * 		-3 => Error read operation
 */
int LatitudeRead(char *data, int *len);

/**
 * @brief Latitude device close funciton
 * @param[in] No parameter
 * @return 0 = default
 */
int LatitudeClose(void);

/**
 * @brief Latitude device control function(sample)
 * @param[in] data Control data
 * @param[in] len  Control data length
 * @return	 result Result string
 */
char* LatitudeControl(char *data, int len);
#endif //_LATITUDE_H_
