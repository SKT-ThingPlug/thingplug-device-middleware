/*
 * @file Altitude.h
 *
 * @brief Altitude Sensor handler header
 *
 * Copyright (C) 2016. SK Telecom, All Rights Reserved.
 * Written 2016, by SK Telecom
 */

#ifndef _ALTITUDE_H_
#define _ALTITUDE_H_

/*
 ****************************************
 * Enumerations
 ****************************************
 */


/*
 ****************************************
 * Major Functions
 ****************************************
 */

/**
 * @brief Altitude device init function
 * @param[in] No parameter
 * @return	 0 => Success init
 * 		-1 => Error file open
 */
int AltitudeInit(void *ops);

/**
 * @brief Altitude device button value read funciton
 * @param[in]  structure member mLastValue pointer
 * @return	 0 => Success read data
 * 		-1 => Error ioctl operation
 * 		-2 => Error write operation
 * 		-3 => Error read operation
 */
int AltitudeRead(char *data, int *len);

/**
 * @brief Altitude device close funciton
 * @param[in] No parameter
 * @return 0 = default
 */
int AltitudeClose(void);

/**
 * @brief Altitude device control function(sample)
 * @param[in] data Control data
 * @param[in] len  Control data length
 * @return	 result Result string
 */
char* AltitudeControl(char *data, int len);
#endif //_ALTITUDE_H_
