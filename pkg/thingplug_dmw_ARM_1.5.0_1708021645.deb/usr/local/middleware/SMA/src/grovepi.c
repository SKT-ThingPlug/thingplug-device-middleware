#include <stdio.h>
#include <stdlib.h>
#include <linux/i2c-dev.h>
#include <fcntl.h>
#include <string.h>
#include <sys/ioctl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>

#include "grovepi.h"
#include "smbus.h"

#define dRead_cmd   1
#define dWrite_cmd  2
#define aRead_cmd   3
#define aWrite_cmd  4
#define pMode_cmd   5
#define uRead_cmd 40

#define MAX_RETRIES 3

static int fd = -1;
static int lcd_fd = -1;
static char *fileName = "/dev/i2c-1";                              
static int  address = 0x04;                                    
static int  lcd_txt_address = 0x3e;                                    
static int  lcd_rgb_address = 0x62;                                    
static unsigned char w_buf[5],r_buf[32];   

int write_block(char cmd,char v1,char v2,char v3);
char read_byte(void);
void pi_sleep(int); 

int grove_init(void)
{
    if( fd != -1) return 1;
    if ((fd = open(fileName, O_RDWR)) < 0) 
    {                   // Open port for reading and writing
        return -1;
    }

    if (ioctl(fd, I2C_SLAVE, address) < 0) 
    {                   // Set the port options and set the address of the device 
        return -1;
    }
    return 1;
}

int lcd_init(void)
{
    if( lcd_fd != -1) return 1;
    if ((lcd_fd = open(fileName, O_RDWR)) < 0) 
    {                   // Open port for reading and writing
        return -1;
    }

    if (ioctl(lcd_fd, I2C_SLAVE, lcd_txt_address) < 0) 
    {                   // Set the port options and set the address of the device 
        return -1;
    }
    return 1;
}

int lcd_select_slave(unsigned char slave)
{
    if (ioctl(lcd_fd, I2C_SLAVE, slave) < 0) 
    {                   // Set the port options and set the address of the device 
        return -1;
    }
    return 1;
}

int lcd_send_command(unsigned char mode, unsigned char command)
{
    int rc = (int)i2c_smbus_write_byte_data(lcd_fd, mode, command);
    return rc;
}

int lcd_set_RGB(unsigned char red, unsigned char green, unsigned char blue)
{
    lcd_select_slave(lcd_rgb_address);
    lcd_send_command(0x00, 0x00);
    lcd_send_command(0x01, 0x00);
    lcd_send_command(0x08, 0xaa);
    lcd_send_command(0x04, red);
    lcd_send_command(0x03, green);
    lcd_send_command(0x02, blue);
    return 1;
}


void lcd_set_text(const char *str)
{
    unsigned char clear_display = 0x01;
    unsigned char display_on = 0x08;
    unsigned char no_cursor = 0x04;
    unsigned char enable_2rows = 0x28;
    unsigned char program_mode = 0x80;
    unsigned char new_row = 0xc0;
    unsigned char display_char = 0x40;
    unsigned char max_no_chars = 32;

    lcd_select_slave(lcd_txt_address);

    lcd_send_command(program_mode, clear_display);
    usleep(50000);
    lcd_send_command(program_mode, display_on | no_cursor ); 
    lcd_send_command(program_mode, enable_2rows);
    usleep(50000);

    int length = strlen(str);
    char already_had_newline = 0;
    int i;
    for(i = 0; i < length && i < max_no_chars; i++)
    {
        if(i == 16 || str[i] == '\n')
        {
            if(!already_had_newline)
            {
                already_had_newline = 1;
                lcd_send_command(program_mode, new_row);
                if(str[i] == '\n')
                    continue;
            }
            else if(str[i] == '\n')
                break;
        }

        lcd_send_command(display_char, (unsigned char)str[i]);
    }
}

//Write a register
int write_block(char cmd,char v1,char v2,char v3)
{           
    int dg;
    w_buf[0]=cmd;
    w_buf[1]=v1;
    w_buf[2]=v2;
    w_buf[3]=v3;

    dg = (int)i2c_smbus_write_i2c_block_data(fd,1,4,w_buf);
    if( dg < 0 )
        return -1;
    return 1; 
}

//write a byte to the GrovePi
int write_byte(char b)
{
    w_buf[0]=b;                                                 
    if ((write(fd, w_buf, 1)) != 1) 
    {                               
        return -1;
    }
    return 1; 
}

//Read 1 byte of data
char read_byte(void)
{
    r_buf[0]=i2c_smbus_read_byte(fd);
    return r_buf[0];
}

//Read a 32 byte block of data from the GrovePi
char read_block(void)
{

    int current_retry = 0;
    int output_code = 0;
    int max_i2c_retries = 5;

    // repeat until it reads the data
    // or until it fails sending it
    while(output_code == 0 && current_retry < max_i2c_retries)
    {
        output_code = i2c_smbus_read_i2c_block_data(fd, 1, 32, &r_buf[0]);
        current_retry += 1;
    }

    // if the error persisted
    // after retrying for [max_i2c_retries] retries
    // then throw exception
    if(output_code == 0) {
        return -1;
    }

    return output_code;

}

void pi_sleep(int t) 
{
    usleep(t*1000);
}

// Read analog value from Pin
int analogRead(int pin)
{
    short data;
    write_block(aRead_cmd,pin,0,0);
    //read_byte();
    read_block();
    data= (r_buf[1] << 8) + r_buf[2];
    if (data==65535)
        data = -1;
    return data;
}

//Write a digital value to a pin
int digitalWrite(int pin,int value)
{
    return write_block(dWrite_cmd,pin,value,0);
}

//Set the mode of a pin
//mode
//  1:  output
//  0:  input
int pinMode(int pin,int mode)
{
    return write_block(pMode_cmd,pin,mode,0);
}

//Read a digital value from a pin
int digitalRead(int pin)
{
    write_block(dRead_cmd,pin,0,0);
    usleep(10000);
    return read_byte();
}

//Write a PWM value to a pin
int analogWrite(int pin,int value)
{
    return write_block(aWrite_cmd,pin,value,0);
}

int areGoodReadings(float temp, float humidity)
{
        return (temp > -100.0 && temp < 150.0 && humidity >= 0.0 && humidity <= 100.0);
}

float  four_byte_to_float(unsigned char *buf)
{
    float output;
    memcpy(&output, buf, 4);
    return output;
}

static int _isnan(float tmp)
{
    return (1.0/0.0 == tmp);
}

void getUnsafeData(int pin, unsigned char module_type, float *temp, float *humi)
{
    write_block(uRead_cmd,pin, module_type, 0);
    read_byte();

    read_block();

    (*temp) = four_byte_to_float(&r_buf[1]);
    (*humi) = four_byte_to_float(&r_buf[5]);
}

int dhtRead(int pin, unsigned char module_type, float *temp, float *humidity)
{
    int current_retry  = 0;
    getUnsafeData(pin, module_type, temp, humidity); // read data from GrovePi once

    // while values got are not okay / accepteed
    while((_isnan(*temp) || _isnan(*humidity) || !areGoodReadings(*temp, *humidity))
            && current_retry < MAX_RETRIES)
    {
        // reread them again
        current_retry += 1;
        getUnsafeData(pin, module_type, temp, humidity);
    }

    // if even after [MAX_RETRIES] attempts at getting good values
    // nothing good came, then throw one of the bottom exceptions

    if(_isnan(*temp) || _isnan(*humidity))
        return -1;

    if(!areGoodReadings(*temp, *humidity))
        return -2;

    return 1;
}

