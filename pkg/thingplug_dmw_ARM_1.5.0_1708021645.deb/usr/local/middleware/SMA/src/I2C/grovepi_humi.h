/*
 * @file grovepi_humi.h
 *
 * @brief GROVEPI_HUMI Sensor handler header
 *
 * Copyright (C) 2017. SK Telecom, All Rights Reserved.
 * Written 2017, by SK Telecom 
 */

#ifndef _GROVEPI_HUMI_H_
#define _GROVEPI_HUMI_H_

/*
 **************************************** 
 * Major Functions
 **************************************** 
 */


/**
 * @brief GROVEPI_HUMI device init function
 * @param[in] No parameter
 * @return	 0 => Success init
 * 		-1 => Error file open 
 */
int GROVEPI_HUMIInit(void *ops);

/**
 * @brief GROVEPI_HUMI device value read funciton
 * @param[in]  structure member mLastValue pointer
 * @return	 0 => Success read data
 * 		-1 => Error ioctl operation 
 * 		-3 => Error read operation 
 */
int GROVEPI_HUMIRead(char *data, int *len);

/**
 * @brief GROVEPI_HUMI device close funciton
 * @param[in] No parameter
 * @return 0 = default
 */
int GROVEPI_HUMIClose(void);

/**
 * @brief GROVEPI_HUMI device Control funciton
 * @param[in] data Control data
 * @param[in] len  Control data length
 * @return	 result Result string
 */
char* GROVEPI_HUMIControl(char *data, int len);

#endif//_GROVEPI_HUMI_H_
