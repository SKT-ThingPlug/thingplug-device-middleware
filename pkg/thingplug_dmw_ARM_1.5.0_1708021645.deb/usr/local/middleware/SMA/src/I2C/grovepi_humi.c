/**
 * @file grovepi_humi.c
 *
 * @brief grovepi humi Sensor Device Handler
 *
 * Copyright (C) 2017. SK Telecom, All Rights Reserved.
 * Written 2017, by SK Telecom 
 */
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/stat.h>
#include <sys/ioctl.h>
#include <fcntl.h>
#include <string.h>
#include <linux/i2c.h>
#include <linux/i2c-dev.h>
#include "grovepi_humi.h"
#include "Foundation.h"
#include "SensorManager.h"
#include "grovepi.h"

/*
 **************************************** 
 * Definition & Global Variable
 **************************************** 
 */
#define HUMI_PIN 7

/*
 **************************************** 
 * GROVEPI_HUMI device Main Handle Functions 
 **************************************** 
 */

//static char stored_str[32] = "";

/**
 * @brief GROVEPI_HUMI device init function
 * @param[in] No parameter
 * @return	 0 => Success init
 * 		-1 => Error file open 
 */
int GROVEPI_HUMIInit(void *ops)
{
	SENSOR_OPERATIONS_T *operations = (SENSOR_OPERATIONS_T *)ops;

	operations->Read = GROVEPI_HUMIRead;
	operations->Close = GROVEPI_HUMIClose;
	operations->Control = NULL;

    grove_init();
	return 0;
}

/**
 * @brief GROVEPI_HUMI device value read funciton
 * @param[in]  structure member mLastValue pointer
 * @return	 0 => Success read data
 * 		-1 => Error ioctl operation 
 * 		-3 => Error read operation 
 */
int GROVEPI_HUMIRead(char *data,int *len)
{
    float temp,humi;
    dhtRead(7, 0 , &temp, &humi );
    sprintf(data,"%.3f",humi);
    *len = strlen(data);
	return 0;
}

/**
 * @brief GROVEPI_HUMI device close funciton
 * @param[in] No parameter
 * @return 0 = default
 */
int GROVEPI_HUMIClose(void)
{
	return 0;
}


/**
 * @brief GROVEPI_HUMI device Control funciton
 * @param[in] data Control data
 * @param[in] len  Control data length
 * @return	 result Result string
 */
char* GROVEPI_HUMIControl(char *data, int len)
{
    return NULL;
}

