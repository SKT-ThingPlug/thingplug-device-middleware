/**
 * @file grovepi_lcd.c
 *
 * @brief grovepi lcd Sensor Device Handler
 *
 * Copyright (C) 2017. SK Telecom, All Rights Reserved.
 * Written 2017, by SK Telecom 
 */
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/stat.h>
#include <sys/ioctl.h>
#include <fcntl.h>
#include <string.h>
#include <linux/i2c.h>
#include <linux/i2c-dev.h>
#include "grovepi_lcd.h"
#include "Foundation.h"
#include "SensorManager.h"
#include "grovepi.h"

/*
 **************************************** 
 * Definition & Global Variable
 **************************************** 
 */


/*
 **************************************** 
 * GROVEPI_LCD device Main Handle Functions 
 **************************************** 
 */

static char stored_str[32] = "EmptyLCD";

/**
 * @brief GROVEPI_LCD device init function
 * @param[in] No parameter
 * @return	 0 => Success init
 * 		-1 => Error file open 
 */
int GROVEPI_LCDInit(void *ops)
{
	SENSOR_OPERATIONS_T *operations = (SENSOR_OPERATIONS_T *)ops;

	operations->Read = GROVEPI_LCDRead;
	operations->Close = GROVEPI_LCDClose;
	operations->Control = GROVEPI_LCDControl;

    int ret;
    ret = lcd_init();
    if( ret != 1 ) {
        return -1;
    }
	return 0;
}

/**
 * @brief GROVEPI_LCD device value read funciton
 * @param[in]  structure member mLastValue pointer
 * @return	 0 => Success read data
 * 		-1 => Error ioctl operation 
 * 		-3 => Error read operation 
 */
int GROVEPI_LCDRead(char *data,int *len)
{
    sprintf(data,"%s",stored_str);
    *len = strlen(data);
	return 0;
}

/**
 * @brief GROVEPI_LCD device close funciton
 * @param[in] No parameter
 * @return 0 = default
 */
int GROVEPI_LCDClose(void)
{
	return 0;
}


/**
 * @brief GROVEPI_LCD device Control funciton
 * @param[in] data Control data
 * @param[in] len  Control data length
 * @return	 result Result string
 */
char* GROVEPI_LCDControl(char *data, int len)
{
    memset(stored_str, 0, sizeof(stored_str));
    memcpy(stored_str, data, len);

    lcd_set_text(stored_str);
    lcd_set_RGB(0, 128, 64);
    return strdup("success");
}

