/*
 * @file grovepi_light.h
 *
 * @brief GROVEPI_LIGHT Sensor handler header
 *
 * Copyright (C) 2017. SK Telecom, All Rights Reserved.
 * Written 2017, by SK Telecom 
 */

#ifndef _GROVEPI_LIGHT_H_
#define _GROVEPI_LIGHT_H_

/*
 **************************************** 
 * Major Functions
 **************************************** 
 */


/**
 * @brief GROVEPI_LIGHT device init function
 * @param[in] No parameter
 * @return	 0 => Success init
 * 		-1 => Error file open 
 */
int GROVEPI_LIGHTInit(void *ops);

/**
 * @brief GROVEPI_LIGHT device value read funciton
 * @param[in]  structure member mLastValue pointer
 * @return	 0 => Success read data
 * 		-1 => Error ioctl operation 
 * 		-3 => Error read operation 
 */
int GROVEPI_LIGHTRead(char *data, int *len);

/**
 * @brief GROVEPI_LIGHT device close funciton
 * @param[in] No parameter
 * @return 0 = default
 */
int GROVEPI_LIGHTClose(void);

/**
 * @brief GROVEPI_LIGHT device Control funciton
 * @param[in] data Control data
 * @param[in] len  Control data length
 * @return	 result Result string
 */
char* GROVEPI_LIGHTControl(char *data, int len);

#endif//_GROVEPI_LIGHT_H_
