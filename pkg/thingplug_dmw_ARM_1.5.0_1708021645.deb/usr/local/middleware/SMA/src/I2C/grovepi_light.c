/**
 * @file grovepi_light.c
 *
 * @brief grovepi light Sensor Device Handler
 *
 * Copyright (C) 2017. SK Telecom, All Rights Reserved.
 * Written 2017, by SK Telecom 
 */
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/stat.h>
#include <sys/ioctl.h>
#include <fcntl.h>
#include <string.h>
#include <linux/i2c.h>
#include <linux/i2c-dev.h>
#include "grovepi_light.h"
#include "Foundation.h"
#include "SensorManager.h"
#include "grovepi.h"

/*
 **************************************** 
 * Definition & Global Variable
 **************************************** 
 */
#define LIGHT_PIN 0
#define PIN_MODE 0

/*
 **************************************** 
 * GROVEPI_LIGHT device Main Handle Functions 
 **************************************** 
 */

//static char stored_str[32] = "";

/**
 * @brief GROVEPI_LIGHT device init function
 * @param[in] No parameter
 * @return	 0 => Success init
 * 		-1 => Error file open 
 */
int GROVEPI_LIGHTInit(void *ops)
{
	SENSOR_OPERATIONS_T *operations = (SENSOR_OPERATIONS_T *)ops;

	operations->Read = GROVEPI_LIGHTRead;
	operations->Close = GROVEPI_LIGHTClose;
	operations->Control = NULL;

    grove_init();
    pinMode(LIGHT_PIN, PIN_MODE);
	return 0;
}

/**
 * @brief GROVEPI_LIGHT device value read funciton
 * @param[in]  structure member mLastValue pointer
 * @return	 0 => Success read data
 * 		-1 => Error ioctl operation 
 * 		-3 => Error read operation 
 */
int GROVEPI_LIGHTRead(char *data,int *len)
{
    short read_data;    
    read_data = analogRead(0);
    sprintf(data,"%hd",read_data);
    *len = strlen(data);
	return 0;
}

/**
 * @brief GROVEPI_LIGHT device close funciton
 * @param[in] No parameter
 * @return 0 = default
 */
int GROVEPI_LIGHTClose(void)
{
	return 0;
}


/**
 * @brief GROVEPI_LIGHT device Control funciton
 * @param[in] data Control data
 * @param[in] len  Control data length
 * @return	 result Result string
 */
char* GROVEPI_LIGHTControl(char *data, int len)
{
    return NULL;
}

