/**
 * @file HC_SR501.h
 *
 * @brief Motion Detection Sensor Device Handler
 *
 * Copyright (C) 2016. SK Telecom, All Rights Reserved.
 * Written 2016, by SK Telecom 
 */
#ifndef _HC_SR501_H_
#define _HC_SR501_H_

/*
 **************************************** 
 * Major Functions
 **************************************** 
 */


/**
 * @brief HC_SR501 device init function
 * @param[in] No parameter
 * @return	 0 => Success init
 * 		-1 => Error file open 
 * @detail	echo 51 > /sys/class/gpio/export => Enable gpio 51
 * 		open file => /sys/class/gpio/gpio51/value
 */
int HC_SR501Init(void *ops);

/**
 * @brief HC_SR501 device value read funciton
 * @param[in]  structure member mLastValue pointer
 * @return	 0 => Success read data
 * 		-3 => Error read operation 
 * 		-4 => Error lseek operation 
 */
int HC_SR501Read(char *data, int *len);

/**
 * @brief HC_SR501 device close funciton
 * @param[in] No parameter
 * @return 0 = default
 */
int HC_SR501Close(void);

#endif//_HC_SR501_H_
