﻿

var temp; 

$(document).ready(function(e) {

	// browser download link
	if($(document).find(".oldBrowserAlert").length > 0) {
		$(".oldBrowserAlert").delay(100).stop(true, true).animate({"top": 0}, 600);

		$(".oldBrowserAlert").on("click", ".btClose", function(evt) {
			$(".oldBrowserAlert").delay(100).stop(true, true).animate({"top": -500}, 600);
		});
	}


	var selectList = (function() {
		function init() {
			// select
			$(document).on("change", ".selectbox select", function(evt) {
				var text = $(this).find("option:selected").text();
				$(this).siblings(".txt").text(text);
			}).on("keyup", ".selectbox > .txt", function(evt) {
				var keyCode = evt.keyCode;
				var labelText = $(this).text();
				var selectObj = $(this).siblings("select");
				var idx = ($(this).text() == $(selectObj).children("option:selected").text()) ? $(selectObj).children("option:selected").index() : 0;

				if(keyCode == 38 || keyCode == 37) {
					if(idx == 0) $(selectObj).children().eq($(selectObj).children().length - 1).attr("selected", "selected").trigger("change");
					else $(selectObj).children().eq(idx - 1).attr("selected", "selected").trigger("change");
				} 
				else if(keyCode == 40 || keyCode == 39) {
					if(idx == ($(selectObj).children().length - 1)) $(selectObj).children().eq(0).attr("selected", "selected").trigger("change");
					else $(selectObj).children().eq(idx + 1).attr("selected", "selected").trigger("change");
				}
			}).on("click", ".selectbox > .txt", function(evt) {
				return false;
			}).on("focus", ".selectbox select", function(evt) {
				$(this).siblings(".txt").addClass("focus");
			}).on("blur", ".selectbox select", function(evt) {
				$(this).siblings(".txt").removeClass("focus");
			}).on("reset", "form", function(evt) {
				var selects = $(this).find("select");
				
				setTimeout(function() {
					$(selects).each(function(i) {
						var text = $(this).find("option:selected").text();				
						$(this).siblings(".txt").text(text);
					});
				}, 30);
			});

			// init select box value
			$(".selectbox select").each(function(i) {
				var text = $(this).children("option:selected").text();
				$(this).siblings(".txt").text(text);
			});

		}

		return {
			init : init
		};
	}());


	var dropList = (function() {
		function init() {
			// dropdown list
			$(document).on("change", ".dropLst .hidradio", function(evt) {
				var groupName = $(this).attr("name");
				var radios = $(".hidradio[name=" + groupName + "]");
				var checked = radios.filter(function() { return $(this).prop("checked") === true; });
				var text = $(checked).siblings("span").text();
				var list = $(checked).parents(".dlst").eq(0);

				$(list).find("label").removeClass("on");
				$(checked).parents("label").eq(0).addClass("on");

				$(list).siblings(".txt").text(text).removeClass("on");
				$(checked).parents(".dlst").slideUp(100);
			}).on("click", ".dropLst > a", function(evt) {
				evt.preventDefault();
				
				var label = $(this);
				var target = $(this).parents(".dropLst").eq(0);
				var list = $(this).siblings(".dlst");
				var openList = $(".dropLst").filter(function() { return $(this).find(".dlst").css("display") != "none" && $(this) != target });

				$(openList).find(".dlst").slideUp(100);
					$(".dropLst > a").removeClass("on");

				$(list).dequeue().slideToggle(100, function() {
					if($(this).css("display") != "none") $(label).addClass("on");
					else $(label).removeClass("on");
				});
			}).on("click", ".dropLst li a", function(evt) {
				$(this).parents(".dlst").eq(0).dequeue().slideUp(100);
				$(".dropLst > a").removeClass("on");
			}).on("keyup", ".dropLst > a", function(evt) {
				var keyCode = evt.keyCode;

				var target = $(this).parents(".dropLst").eq(0);
				var list = $(this).siblings(".dlst");
				var chkRadio = $(this).siblings(".dlst").find(".hidradio:checked");
				var hoverRadio = $(list).find(".hover");
				var idx = -1;

				if(hoverRadio.length < 1) idx = (chkRadio.parents("li").eq(0).index() > -1) ? chkRadio.parents("li").eq(0).index() : 0;
				else idx = hoverRadio.parents("li").eq(0).index();

				var openList = $(list).filter(function() { return $(this).css("display") != "none" });
				if(openList.length < 1) return false;

				if(keyCode == 13) {
					$(list).find("li").find(".hover").find(".hidradio").prop("checked", true).trigger("change");
					$(list).find("label").removeClass("hover");
				} 
				else if(keyCode == 38 || keyCode == 37) {
					$(list).find("label").removeClass("hover");

					if(idx == 0) $(list).find("li").eq($(list).find("li").length - 1).find("label").addClass("hover");
					else $(list).find("li").eq(idx - 1).find("label").addClass("hover");
				}
				else if(keyCode == 40 || keyCode == 39) {
					$(list).find("label").removeClass("hover");
					
					if(idx == ($(list).find("li").length - 1)) $(list).find("li").eq(0).find("label").addClass("hover");
					else $(list).find("li").eq(idx + 1).find("label").addClass("hover");
				}
			}).on("click", function(evt) {
				var evt = evt ? evt : event;
				var target = null;

				if (evt.srcElement) target = evt.srcElement;
				else if (evt.target) target = evt.target;

				var openList = $(".dropLst").filter(function() { return $(this).find(".dlst").css("display") != "none" });
				if($(target).parents(".dropLst").eq(0).length < 1) {
					$(openList).find(".dlst").slideUp(100);
					$(".dropLst > a").removeClass("on");
				}
			}).on("click touchstart", function(evt) {
				var evt = evt ? evt : event;
				var target = null;

				if (evt.srcElement) target = evt.srcElement;
				else if (evt.target) target = evt.target;

				var openList = $(".dropLst").filter(function() { return $(this).find(".dlst").css("display") != "none" });
				if($(target).parents(".dropLst").eq(0).length < 1) {
					$(openList).find(".dlst").slideUp(100);
					$(".dropLst > a").removeClass("on");
				}
			});

			// init dropdown list value
			$(".dropLst").each(function(i) {
				var groupName = $(this).find(".hidradio").eq(0).attr("name");
				var radios = $(".hidradio[name=" + groupName + "]");
				var checked = $(radios).filter(function() { return $(this).prop("checked") === true; });
				var text = $(checked).siblings("span").text();
				var list = $(checked).parents(".dlst").eq(0);

				$(list).find("label").removeClass("on");
				$(checked).parents("label").eq(0).addClass("on");

				$(list).siblings(".txt").text(text);
			});
		}

		return {
			init : init
		};
	}());

	selectList.init();
	dropList.init();



	// gnb
	var gnb = (function() {
		function init() {

			// mouse event
			$(".navi").on("click", ".ntit", function(evt) {
				var target = $(this);
				var snav = $(this).siblings(".snav");

				if(snav.length < 1) {
					$(".navi .ntit").removeClass("hover");
					onHideSubNav();
					
					target.addClass("hover");
					return;
				}

				evt.preventDefault();

				if(target.hasClass("hover")) {
					$(".navi .ntit").removeClass("hover");
					onHideSubNav();
				}
				else {
					$(".navi .ntit").removeClass("hover");
					target.addClass("hover");

					onHideSubNav();
					$(snav).show();
				}
			});

			$(document).on("click", function(evt) {
				var evt = evt ? evt : event;
				var target = null;

				if (evt.srcElement) target = evt.srcElement;
				else if (evt.target) target = evt.target;

				if($(target).parents(".navi").eq(0).length < 1) {
					$(".navi .ntit").removeClass("hover");
					onHideSubNav();
				}
			});
		}

		function onHideSubNav() {
			var hideNav = $(".navi .ntit").filter(function() { return $(this).hasClass("on") != true; });			
			$(hideNav).siblings(".snav").hide();
		}

		return {
			init : init
		}
	}());

	gnb.init();


	// table
	window.fixTableScroll = (function() {
		function init() {
			if(!Modernizr.boxsizing) return;

			$(window).load(onResizeCheck).resize(onResizeCheck);
			onResizeCheck();

			// scroll event
			$(".scrolls").on("scroll", function(evt) {
				var left = -1 * $(this).scrollLeft();
				var head = $(this).siblings(".fixHead");

				head.css("-ms-transform", "translate(" + left + "px, 0px)"); 
				head.css("-webkit-transform", "translate(" + left + "px, 0px)"); 
				head.css("transform", "translate(" + left + "px, 0px)");
			});
		}

		function onResizeCheck() {
			$(".scrollFix").each(function(i) {
				checkWidth($(this));
			});		
		}

		function refresh(target) {
			if(target) checkWidth(target);
			else onResizeCheck();
		}

		function checkWidth(target) {
			var _tbw = target.find(".scrolls .tbLog").outerWidth();
			var _w = target.find(".scrolls").width();			
			var mr = _w - _tbw;

			if(mr > -1) target.find(".fixHead").css("margin-right", mr);
			else {
				if (/Edge\/12./i.test(navigator.userAgent)) target.find(".fixHead").css("margin-right", 12);
			}
		}

		return {
			init : init,
			refresh : refresh
		}
	}());

	fixTableScroll.init();


	// checkbox
	window.chkBox = (function() {
		function init() {
			$(document).on("focus", ".chkBg", onFocus).on("blur", ".chkBg", onBlur).on("change", ".chkBg", onChange);

			$(document).on("reset", "form", function(evt) {
				var chkBg = $(this).find(".chkBg");
				
				setTimeout(function() {
					$(chkBg).each(function() {
						onCheckChkbox($(this));
					});
				}, 30);
			});

			var chkBg = $(".chkBg");
			$(chkBg).each(function() {
				onCheckChkbox($(this));
			});
		}

		function onCheckChkbox(chkBg) {
			if($(chkBg).is(":checked")) {
				$(chkBg).parent("label").addClass("on");
				$(chkBg).prop("checked", true);
			}
		}

		function onFocus(evt) {
			if($(this).is(":disabled")) return;

			var lbObj = $(this).parent("label");
			lbObj.addClass("focus");
		}

		function onBlur(evt) {
			var lbObj = $(this).parent("label");
			lbObj.removeClass("focus");
		}

		function onChange(evt) {
			var lbObj = $(this).parent("label");
			if($(this).is(":checked")) lbObj.addClass("on");
			else lbObj.removeClass("on");
		}

		function bindEvent(target) {
			$(target).bind({
				focus : onFocus,
				blur : onBlur,
				change : onChange
			});

			if($(target).is(":checked")) {
				$(target).parent("label").addClass("on");
				$(target).prop("checked", true);
			}
		}

		return {
			init : init,
			bindEvent : bindEvent
		}	
	}());


	// radio box
	window.rdoBox = (function() {
		function init() {
			$(document).on("focus", ".rdoBg", onFocus).on("blur", ".rdoBg", onBlur).on("change", ".rdoBg", onChange);

			$(document).on("reset", "form", function(evt) {
				var rdoBg = $(this).find(".rdoBg");
				
				setTimeout(function() {
					$(rdoBg).each(function() {
						onCheckRdobox($(this));
					});
				}, 30);
			});

			var rdoBg = $(".rdoBg");
			$(rdoBg).each(function() {
				onCheckRdobox($(this));
			});
		}

		function onCheckRdobox(target) {
			var groupName = $(target).attr("name");
			var rdoObj = $("input.rdoBg[name=" + groupName + "]:checked");

			if(rdoObj.length > 0) {
				$("input.rdoBg[name=" + groupName + "]").parent("label").removeClass("on");
				$(rdoObj).parent("label").addClass("on");
			}
		}

		function onFocus(evt) {
			if($(this).is(":disabled")) return;

			var groupName = $(this).attr("name");
			$("input.rdoBg[name=" + groupName + "]").parent("label").removeClass("focus");
			$(this).parent("label").addClass("focus");
		}

		function onBlur(evt) {
			var groupName = $(this).attr("name");
			$("input.rdoBg[name=" + groupName + "]").parent("label").removeClass("focus");
		}

		function onChange(evt) {
			var groupName = $(this).attr("name");
			$("input.rdoBg[name=" + groupName + "]").parent("label").removeClass("on");
			$(this).parent("label").addClass("on");
		}

		function bindEvent(target) {
			$(target).bind({
				focus : onFocus,
				blur : onBlur,
				change : onChange
			});

			onCheckRdobox(target);
		}

		return {
			init : init,
			bindEvent : bindEvent
		}	
	}());


	chkBox.init();
	rdoBox.init();
});

