﻿
/**
 * 
 * 서버
 * 
 *  - 추후 Util 성 함수는 별도로 분리 시켜야함
 */

// 
var bodyParser = require("body-parser");
var express = require("express");
var session = require("express-session");
var fs = require("fs");
var url2 = require("url");
var http = require("http");
var xml2js = require("xml2js");
var request = require("request");
var IPC = require("./assets/js/ipc");
var multipart = require("connect-multiparty");
var app = express();
var Version;
var AppRegdate;

//console.log("Server Start.");

// 버전 추출
getVersionAppRegdate();

// IPC 시작
IPC.start();

// 서버 생성
var server = http.createServer(app);

// 서버 대기
//console.log("port : ", process.argv[2]);
server.listen(process.argv[2] == "undefined" ?  8000 : process.argv[2]);

// ejs 설정
app.set("views", __dirname + "/html");
app.set("view engine", "ejs");

// static 파일 처리
app.use(express.static(__dirname + "/"));
app.use(bodyParser.json());
app.use(session({
	secret : "GatewayPortal",
	resave : false,
	saveUninitialized : true
}));

// 언어 설정
var i18n = require("i18n");
i18n.configure({
	locales : [ "ko", "en" ],
	defaultLocale : "ko",
	cookie : "locale",
	updateFiles : true,
	directory : __dirname + "/locales"
});

// 엑셀 다운로드 라우터 설정
app.post("/Download", multipart(), function (req, res) {

	var download_list =  JSON.parse(req.body.download_list);

	var config = {};
	config.cols = [
	{
		caption : "Time",
		type : "string"
	},
	{
		caption : "Device",
		type : "string"
	},
	{
		caption : "Log Level",
		type : "string"
	},
	{
		caption : "Log Info",
		type : "string"
	}
	];
	config.rows = [];

	if (download_list.download_list) {
		for (var p in download_list.download_list) {
			var item = download_list.download_list[p];
			
			config.rows.push([
				item.logTime,
				item.logType,
				item.logLevel,
				item.logMsg
			]);
		}
	}
	
	// 파일명
	var today = new Date();
	var dd = today.getDate();
	var mm = today.getMonth() + 1;
	var yyyy = today.getFullYear();
	var hh = today.getHours();
	var MM = today.getMinutes();
	if (dd < 10) dd = "0" + dd;
	if (mm < 10) mm = "0" + mm;
	if (hh < 10) hh = "0" + hh;
	if (MM < 10) MM = "0" + MM;

	today = yyyy + mm + dd + hh + MM;

	// 엑셀 다운로드
	var excel = require("excel-export");
	var result = excel.execute(config);
	res.setHeader("Content-Type", "application/vnd.openxmlformats");
	res.setHeader("Content-Disposition", "attachment; filename=" + today + "_Logs.xlsx");
	res.end(result, "binary");
});

// 로그아웃 라우터 설정
app.get("/Logout", function (req, res) {
	req.session.destroy(function () {
		//res.writeHead(302, { "Location" : "/" });
		var locale = get_cookies(req)["locale"];
//		var msg = "로그아웃 되었습니다.";
		var msg = "%uB85C%uADF8%uC544%uC6C3%20%uB418%uC5C8%uC2B5%uB2C8%uB2E4." // escape("로그아웃 되었습니다");
		if (locale == "en") msg = "Logout.";
		res.end("<script>alert(unescape('" + msg + "')); window.location.href = '/';</script>");
	});
});


// page timeout
app.get("/PageTimeout", function (req, res) {
	req.session.destroy(function () {
		res.end("<script>window.location.href = '/';</script>");
	});
});


// 기본 라우터 설정
app.get("*", function (req, res) {

	var params = url2.parse(req.url, true).query;

	// URL 기반 ejs 파일 맵핑
	var file_name = "";
	var url = req.url;

	// url 에 .이 들어간것은 제외
	if (url.indexOf(".") == -1) {

		file_name = req.url;

		// 첫번째 / 처리
		if (file_name.substring(0, 1) == "/") file_name = file_name.substring(1);

		// ? 파라미터 처리
		var pos = file_name.indexOf("?");
		if (pos != -1) file_name = file_name.substring(0, pos);

		// / 같은 경우는 index 로 
		if (!file_name) file_name = "Intro/Intro";

		// 첫번째 url 
		pos = file_name.indexOf("/");
		var first_url = file_name.substring(0, pos);

		// 두번째 url
		var last_url = file_name.substring(pos + 1);

		file_name = ucfirst(first_url) + "/" + ucfirst(last_url);

		if (!req.session.userId) {	// 로그인 처리
			if (file_name.indexOf("Intro") == -1 && file_name != "") {

				var locale = get_cookies(req)["locale"];
				var msg = "%uB85C%uADF8%uC778%20%uD6C4%20%uC774%uC6A9%20%uAC00%uB2A5%uD569%uB2C8%uB2E4." // escape("로그인 후 이용 가능합니다.");
				if (locale == "en") msg = "Please login.";
				res.end("<script>alert(unescape('" + msg + "')); window.location.href = '/';</script>");
				return;
			}
		}

		file_name = file_name.toLowerCase();
		//console.log("request url : " + file_name);

		// 페이지 로드
		fs.exists("./assets/js/" + file_name + ".js", function (exists) {
	
			// 뷰단 전달 데이터
			var view_data = {};

			// 뷰단 파라미터 전달
			view_data.req = req;
			view_data.res = res;
			view_data.params = params;

			// 현재 url 설정
			view_data.first_url = first_url;
			view_data.last_url = last_url;

			// 페이지 js 가 있을경우
			if (exists) {
				var m = require("./assets/js/" + file_name + ".js");
				view_data = m.excute(req, res, params);
			}

			// 사용자 js 존재 유무
			view_data.user_js_exists = fs.existsSync("./assets/js/mobule/" + file_name + ".js");

			// 페이지 파일 체크
			fs.exists("./html/" + file_name + ".ejs", function (_exists) {

				if (_exists) {

					// 버전 전달
					view_data.Version = Version;
					view_data.AppRegdate = AppRegdate;

					// 언어설정
					i18n.init(req, res);
					req.locale = get_cookies(req)["locale"];
					view_data.locale = get_cookies(req)["locale"];

					// trace 설정
					view_data.DM_TRACE_STATUS = get_cookies(req)["DM_TRACE_STATUS"];

					// X-Powered 설정
					res.setHeader("X-Powered-By", "Thingplug GateWay Portal");

					// 페이지 렌더링
					res.render(file_name, view_data);
				} else {	// 파일 미존재
					res.render("common/error404");
				}
			});
		});
	}
});

// 에러 설정
app.use(function (e, req, res, next) {
	res.render("common/error500");
	//console.log(e);
});

// 쿠키 
var get_cookies = function(req) {
	var cookies = {};
	try {
		req.headers && req.headers.cookie.split(";").forEach(function (cookie) {
			var parts = cookie.match(/(.*?)=(.*)$/);
			if (parts[2] && parts[2] != "undefined") cookies[parts[1].trim()] = (parts[2] || "").trim();
		});
	} catch (e) { }

	return cookies;
};

// 현재 버전 추출
function getVersionAppRegdate () {
	var config = require("./package.json");
	Version = config.version;
	AppRegdate = config.appregdate ? config.appregdate.replace(/-/gmi, ".") : "";
};

// 첫번째만 대문자
var ucfirst = function(text) {
	return text.charAt(0).toUpperCase() + text.slice(1);
};

////////////////////////// IPC 라우터 설정 ////////////////////////////////////////////////////
/*app.post("/API/*", function (req, res, next) {
	console.log("request url : " + req.url);
	next();
});*/
app.post("/API/ping", IPC.ping);											// ping
app.post("/API/session", IPC.session);										// session check
//app.post("/API/register", IPC.register);									// GP 서비스 등록
app.post("/API/extraInfo", IPC.extraInfo);									// Device time, log timezone, etc
app.post("/API/getSystemInfo", IPC.getSystemInfo);							// 시스템 정보
app.post("/API/getSystemUsage", IPC.getSystemUsage);						// 시스템 사용량 정보
app.post("/API/getNetworkInfo", IPC.getNetworkInfo);						// 네트워크 정보
app.post("/API/getDeviceSensor", IPC.getDeviceSensor);						// 센서 정보
app.post("/API/getDeviceSensorStatus", IPC.getDeviceSensorStatus);			// 센서 상태
app.post("/API/getSystemLog", IPC.getSystemLog);							// 시스템 로그
app.post("/API/authentication", IPC.authentication);						// 로그인
app.post("/API/changeAuth", IPC.changeAuth);								// 비밀번호 변경
app.post("/API/restart", IPC.restart);										// 재구동 요청
app.post("/API/reset", IPC.reset);											// 초기화 요청
app.post("/API/getProcessStatus", IPC.getProcessStatus);					// 장치 process 상태정보
app.post("/API/account", IPC.account);										// ThingPlug login
app.post("/API/registerDevice", IPC.registerDevice);						// 장치 등록
app.post("/API/unregisterDevice", IPC.unregisterDevice);					// 장치 해지
app.post("/API/getThingStatus", IPC.getThingStatus);						// thingplug 연결 정보
app.post("/API/setTraceStatus", IPC.setTraceStatus);						// trace on/off 요청
app.post("/API/updateLog", IPC.updateLog);									// 로그정보 업데이트 요청
app.post("/API/getErrorLogCount", IPC.getErrorLogCount);					// 에러 카운트 요청
app.post("/API/getAllDeviceSensorStatus", IPC.getAllDeviceSensorStatus);	// 모든 센서 정보 요청
app.post("/API/logReset", IPC.logReset);									// 로그정보 초기화
app.post("/API/getInterval", IPC.getInterval);								// 센서정보 주기 정보 요청
app.post("/API/setInterval", IPC.setInterval);								// 센서정보 주기 정보 설정
app.post("/API/getDevice", IPC.getDevice);									// 센서 디바이스 목록

app.post("/API/changeSensorConfigFile", IPC.changeSensorConfigFile);		// 센서 config 파일 변경

// auto upgrade
app.post("/API/middlewareUpgrade", function (req, res) {

	// prepare view page
	var view_data = {};
	view_data.user_js_exists = false;
	view_data.first_url = "Intro";
	view_data.last_url = false;

	i18n.init(req, res);
	req.locale = get_cookies(req)["locale"];
	view_data.locale = get_cookies(req)["locale"];

	// X-Powered setting
	res.setHeader("X-Powered-By", "Thingplug GateWay Portal");

	res.render("setting/upgrade_final", view_data);

	setTimeout(function () {
		IPC.middlewareUpgrade();
	}, 3000);
});

// 시스템 업그레이드
app.post("/setting/upgrade_exec", multipart(), function (req, res) {
	
	// 업그레이드 폴더
	// var upgrade_folder = "../_gp_upgrade/";
	var upgrade_folder = "/tmp/";

	fs.readFile(req.files.firmware_file.path, function (error, data) {
		// var file_name = upgrade_folder + "package.deb";
		var file_name = upgrade_folder + "dm_upgrade_file";

		// 디렉토리 생성
		if (!fs.existsSync(upgrade_folder)) fs.mkdirSync(upgrade_folder);

		// 파일 저장
		fs.writeFileSync(file_name, data);

		// 설정
		var view_data = {};
		view_data.user_js_exists = false;
		view_data.first_url = "Intro";
		view_data.last_url = false;

		i18n.init(req, res);
		req.locale = get_cookies(req)["locale"];
		view_data.locale = get_cookies(req)["locale"];

		// X-Powered 설정
		res.setHeader("X-Powered-By", "Thingplug GateWay Portal");

		res.render("setting/upgrade_final", view_data);

		setTimeout(function () {
			process.send("INSTALL");
		}, 3000);

		setTimeout(function () {
			IPC.middlewareUpgrade();
		}, 3000);
	});
});

// 실행시간 확인
app.post("/API/checkUptime", function (req, res) {

	var ms = process.uptime();

	(function (time) {

		var sec_num = parseInt(time, 10);

		var days = 0;
		var hours = Math.floor(sec_num / 3600);
		var minutes = Math.floor((sec_num - (hours * 3600)) / 60);
		var seconds = sec_num - (hours * 3600) - (minutes * 60);

		// 날짜 계산
		days = hours / 24;
		if (days > 0) hours = hours % 24;

		var text = "";

		if (days > 0) text += days + "일 ";
		if (hours > 0) text += hours + "시간 ";
		if (minutes > 0) text += minutes + "분 ";
		if (seconds > 0) text += seconds + "초";

		var obj = {};
		obj.DM_RESULT = 0x01;
		obj.UPTIME = text;
		res.end(JSON.stringify(obj));

	})(ms.toString());
	
});

// Thingplug 회원정보 확인
app.post("/API/checkThingplugUserInfo", function (req, res) {

	// 내부 request 로 통신하여 정보 가져오자.
	request.put({
		//url : "http://61.250.21.212:9000/ThingPlug?division=user&function=login", // onem2m server
		url : "http://thingplugtest.sktiot.com:9000/ThingPlug?division=user&function=login",
		headers : {
			"user_id" : req.body.data.data.ID,
			"password" : req.body.data.data.PASS,
			"locale" : "ko"
		}
	}, function (e, r, body) {
		var parser = new xml2js.Parser();
		parser.parseString(body, function(err, result) {
			if (result) {
				result.DM_RESULT = 0x01;
			} else {
				result = {};
				result.DM_RESULT = 0x02;
			}
			res.end(JSON.stringify(result));
		});
	});

});

// 부모 프로세스 메시지 수신
process.on("message", function(msg) {
	if (msg == "SIGTERM") {
		console.log("process.on(message)");
		IPC.end();
	}
});
