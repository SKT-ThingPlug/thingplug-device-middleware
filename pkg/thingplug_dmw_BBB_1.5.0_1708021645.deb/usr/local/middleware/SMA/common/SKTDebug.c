/*
 * SKTDebug.c
 *
 *  Created on: 2015. 11. 16.
 *      Author: sidn
 */


#include "SKTDebug.h"

#include <stdarg.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <time.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/vfs.h>
#include <unistd.h>

#include "base_directory.h"

#define LOGFILE "dm.log"     
#define LOGPATH BASE_DIR "/log/"
#define LOGFILENUM_MAX 3
#define LOGFILESIZE_MAX 10 * 1000000 //10M
#define DISK_THRESHOLD 10

bool gLogCreated = false;
 
void DebugWrite (char *message);    // logs a message to LOGFILE
void CheckFileStat(void);

FILE* gDebugStream = NULL;
char log_filename[64] = "";
SKTBOOLEAN_TYPE_E gDebugEnable = SKTFalse;
SKTLOG_LEVEL_E gDebugLogLevel = (SKTLOG_LEVEL_E)LOG_LEVEL_NONE;

// filter strings 
#define NUM_OF_FILTER 1
static char* mFilterStrings[NUM_OF_FILTER] = {"credentialID"};

void LogLevelString(SKTLOG_LEVEL_E level, char *buffer)
{
	switch(level) {
		case LOG_LEVEL_VERBOSE: {
			memcpy(buffer, "VERBOSE", strlen("VERBOSE"));
		}
		break;

		case LOG_LEVEL_DEBUG: {
			memcpy(buffer, "DEBUG", strlen("DEBUG"));
		}
		break;

		case LOG_LEVEL_INFO: {
			memcpy(buffer, "INFO", strlen("INFO"));
		}
		break;

		case LOG_LEVEL_WARN: {
			memcpy(buffer, "WARN", strlen("WARN"));
		}
		break;

		case LOG_LEVEL_ERROR: {
			memcpy(buffer, "ERROR", strlen("ERROR"));
		}
		break;

		case LOG_LEVEL_FATAL: {
			memcpy(buffer, "FATAL", strlen("FATAL"));
		}
		break;

		default: {
			memcpy(buffer, "NONE", strlen("NONE"));
		}
		break;
	}
}

void DebugInit(SKTBOOLEAN_TYPE_E enable, SKTLOG_LEVEL_E level, FILE *stream, char* filename)
{
	gDebugEnable   = enable;
	gDebugLogLevel = level;
    if( filename != NULL ) {
        strncat(log_filename, filename, strlen(filename));
    } else {
        memset(log_filename,0,sizeof(log_filename));
    }

	if(stream == NULL) {
		gDebugStream = stderr;
	} else {
		gDebugStream = stream;
	}
}

char* timeToString(struct tm *t) {
  static char s[20];

  sprintf(s, "%04d-%02d-%02d %02d:%02d:%02d",
              t->tm_year + 1900, t->tm_mon + 1, t->tm_mday,
              t->tm_hour, t->tm_min, t->tm_sec
          );

  return s;
}

unsigned char DoNotPrint(char* message) {
	int i = 0;
	for(i = 0; i < NUM_OF_FILTER; i++) {
		if(strstr(message, mFilterStrings[i])) {
			return 1;
		}
	}
	return 0;
}

void DebugPrintf(const char *filename, int lineno, SKTLOG_LEVEL_E level, const char *format, ...)
{
    if(format == NULL) {
        return;
    }
    
	if(gDebugEnable == SKTFalse ) {
		return;
	}

	if(gDebugLogLevel == LOG_LEVEL_NONE) {
		return;
	}

	if(gDebugStream == NULL) {
		return;
	}

	if(gDebugLogLevel > level) {
		return;
	}

	char stringBuffer[30];
    char message[1024] = "";
    char print_message[1024] = "";
	char log[1024] = "";
	memset(stringBuffer, 0, 30);
	LogLevelString(level, stringBuffer);

    
    struct tm *t;
    time_t timer;
    
    timer = time(NULL);    
    t = localtime(&timer);

    sprintf(message, "[%s] [%s] [%d] [%s]: ", timeToString(t), filename, lineno, stringBuffer);
    switch(level) 
    {
        case LOG_LEVEL_VERBOSE:
            sprintf(print_message, "[%s] [%s] [%d] [%s]: ", timeToString(t), filename, lineno, stringBuffer);
            break;
        case LOG_LEVEL_DEBUG:
            sprintf(print_message, "\x1b[92m[%s] [%s] [%d] [%s]\x1b[0m: ", timeToString(t), filename, lineno, stringBuffer);
            break;
        case LOG_LEVEL_INFO:
            sprintf(print_message, "\x1b[94m[%s] [%s] [%d] [%s]\x1b[0m: ", timeToString(t), filename, lineno, stringBuffer);
            break;
        case LOG_LEVEL_WARN:
            sprintf(print_message, "\x1b[93m[%s] [%s] [%d] [%s]\x1b[0m: ", timeToString(t), filename, lineno, stringBuffer);
            break;
        case LOG_LEVEL_ERROR:
            sprintf(print_message, "\x1b[91m[%s] [%s] [%d] [%s]\x1b[0m: ", timeToString(t), filename, lineno, stringBuffer);
            break;
        case LOG_LEVEL_FATAL:
            sprintf(print_message, "\x1b[41m\x1b[30m[%s] [%s] [%d] [%s]\x1b[0m: ", timeToString(t), filename, lineno, stringBuffer);
            break;
        default:
            sprintf(print_message, "[%s] [%s] [%d] [%s]: ", timeToString(t), filename, lineno, stringBuffer);
            break;
    }

	

	fprintf(gDebugStream, "%s", print_message);
    DebugWrite(message);

//    memset(message,0,sizeof(message));
	va_list argp;
	va_start(argp, format);
//    vsnprintf(message, 1024, format, argp);
//	fprintf(gDebugStream, "%s",message);
//    DebugWrite(message);
    vsnprintf(log, sizeof(log), format, argp);
	if(!DoNotPrint(log)) {
		fprintf(gDebugStream, "%s", log);
		DebugWrite(log);
		DebugWrite("\n");
		fputc('\n', gDebugStream);
	}
	va_end(argp);
	fflush(gDebugStream);
}

void DebugDump(const char *title, const char* data, unsigned long lengths)
{
	if(data == NULL || lengths == 9) {
		printf("\n\n==========================================================\n");
		printf("Dump Name %s\n", title);
		printf("----------------------------------------------------------\n");
		printf(">>>>>>>>>>>>>>>>>>>>DATA is Empty!!<<<<<<<<<<<<<<<<<<<<<<<\n");
		return;
	}

	printf("\n\n==========================================================\n");
	printf("Dump Name %s\n", title);
	printf("----------------------------------------------------------\n");

	int i     = 0;
	int j     = 0;
	int width = 16;

	for(i=0; i<lengths; ) {
		printf("%04d", i);

		for(j=i; j<(i+width); j++) {
			if(!(j%(width/2))) {
				printf(" ");
			}

			if(j >= lengths) {
				printf("   ");
			} else {
				printf("%02x", (unsigned char)(data[j]));
			}
		}
		printf(": ");

		for(j=i; j<(i+width) && j<lengths; j++) {
			if(data[j] < 0x20 || data[j] > 0x70) {
				printf(".");
			} else {
				printf("%c", data[j]);
			}
		}

		i += width;
		if(i>lengths) {
			i = (int)lengths;
		}
		printf("\n");
	}
	printf("===========================================================\n\n");
}

 
void DebugWrite (char *message)
{
    FILE *file;
    struct statfs vfs;
    float available_rate;
    char filename[64] = "";

    if( log_filename[0] == '\0') {
        return;
    }


    statfs(LOGPATH, &vfs);
    available_rate = ((float)vfs.f_bfree/(float)vfs.f_blocks)*100; 

    if( available_rate < DISK_THRESHOLD) {
        int i;
        int ret_flag = 0;
        for( i = LOGFILENUM_MAX; i != 0; i--) {
            sprintf(filename, "%s%s_%d", LOGPATH,log_filename, i);
            remove(filename);
    
            statfs(LOGPATH, &vfs);
            available_rate = ((float)vfs.f_bfree/(float)vfs.f_blocks)*100; 
            if(available_rate >= DISK_THRESHOLD) {
                ret_flag = 1;
                break;
            }
        }
        if( ret_flag == 0) { 
            fprintf(stderr,"\n[WARNNING] Fail!! file write, available disk space[%2.2f%%]\n",available_rate);
            return;
        }
    }   
   
    sprintf(filename, "%s%s", LOGPATH,log_filename);
    if (!gLogCreated) {
        file = fopen(filename, "w");
        gLogCreated = true;
    }
    else        
        file = fopen(filename, "a");

    if (file == NULL) {
        if (gLogCreated)
            gLogCreated = false;
        return;
    }
    else
    {
        fputs(message, file);
        fclose(file);
        file = NULL;
    }

    if (file)
        fclose(file);

    CheckFileStat();
}

void CheckFileStat(void)
{
    char filename[64];
    struct stat fileStat; 
    sprintf(filename, "%s%s", LOGPATH,log_filename);

    stat(filename, &fileStat);
    if( fileStat.st_size > LOGFILESIZE_MAX ) {
        char curr[64];
        char next[64];
        int i;
        sprintf(filename, "%s%s_%d", LOGPATH, log_filename, LOGFILENUM_MAX);
        remove(filename);
        for( i = LOGFILENUM_MAX; i > 0; i--) {
            if( i == 1 ) {
                sprintf(curr,"%s%s", LOGPATH, log_filename);
                sprintf(next,"%s%s_%d", LOGPATH,log_filename, 1);
            } else {
                sprintf(curr, "%s%s_%d", LOGPATH,log_filename, i - 1);
                sprintf(next, "%s%s_%d", LOGPATH,log_filename, i);
            }
            rename(curr, next);
        }
        gLogCreated = false;
    }
}

