/*
 * @file grovepi_temp.h
 *
 * @brief GROVEPI_TEMP Sensor handler header
 *
 * Copyright (C) 2017. SK Telecom, All Rights Reserved.
 * Written 2017, by SK Telecom 
 */

#ifndef _GROVEPI_TEMP_H_
#define _GROVEPI_TEMP_H_

/*
 **************************************** 
 * Major Functions
 **************************************** 
 */


/**
 * @brief GROVEPI_TEMP device init function
 * @param[in] No parameter
 * @return	 0 => Success init
 * 		-1 => Error file open 
 */
int GROVEPI_TEMPInit(void *ops);

/**
 * @brief GROVEPI_TEMP device value read funciton
 * @param[in]  structure member mLastValue pointer
 * @return	 0 => Success read data
 * 		-1 => Error ioctl operation 
 * 		-3 => Error read operation 
 */
int GROVEPI_TEMPRead(char *data, int *len);

/**
 * @brief GROVEPI_TEMP device close funciton
 * @param[in] No parameter
 * @return 0 = default
 */
int GROVEPI_TEMPClose(void);

/**
 * @brief GROVEPI_TEMP device Control funciton
 * @param[in] data Control data
 * @param[in] len  Control data length
 * @return	 result Result string
 */
char* GROVEPI_TEMPControl(char *data, int len);

#endif//_GROVEPI_TEMP_H_
