/*
 * @file grovepi_led.h
 *
 * @brief GROVEPI_LED Sensor handler header
 *
 * Copyright (C) 2017. SK Telecom, All Rights Reserved.
 * Written 2017, by SK Telecom 
 */

#ifndef _GROVEPI_LED_H_
#define _GROVEPI_LED_H_

/*
 **************************************** 
 * Major Functions
 **************************************** 
 */


/**
 * @brief GROVEPI_LED device init function
 * @param[in] No parameter
 * @return	 0 => Success init
 * 		-1 => Error file open 
 */
int GROVEPI_LEDInit(void *ops);

/**
 * @brief GROVEPI_LED device value read funciton
 * @param[in]  structure member mLastValue pointer
 * @return	 0 => Success read data
 * 		-1 => Error ioctl operation 
 * 		-3 => Error read operation 
 */
int GROVEPI_LEDRead(char *data, int *len);

/**
 * @brief GROVEPI_LED device close funciton
 * @param[in] No parameter
 * @return 0 = default
 */
int GROVEPI_LEDClose(void);

/**
 * @brief GROVEPI_LED device Control funciton
 * @param[in] data Control data
 * @param[in] len  Control data length
 * @return	 result Result string
 */
char* GROVEPI_LEDControl(char *data, int len);

#endif//_GROVEPI_LED_H_
