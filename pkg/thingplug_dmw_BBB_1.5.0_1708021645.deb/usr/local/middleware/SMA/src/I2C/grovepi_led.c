/**
 * @file grovepi_led.c
 *
 * @brief grovepi led Sensor Device Handler
 *
 * Copyright (C) 2017. SK Telecom, All Rights Reserved.
 * Written 2017, by SK Telecom 
 */
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/stat.h>
#include <sys/ioctl.h>
#include <fcntl.h>
#include <string.h>
#include <linux/i2c.h>
#include <linux/i2c-dev.h>
#include "grovepi_led.h"
#include "Foundation.h"
#include "SensorManager.h"
#include "grovepi.h"

/*
 **************************************** 
 * Definition & Global Variable
 **************************************** 
 */
#define LED_PIN 4
#define PIN_MODE 1

/*
 **************************************** 
 * GROVEPI_LED device Main Handle Functions 
 **************************************** 
 */

static char stored_str[32] = "off";

/**
 * @brief GROVEPI_LED device init function
 * @param[in] No parameter
 * @return	 0 => Success init
 * 		-1 => Error file open 
 */
int GROVEPI_LEDInit(void *ops)
{
	SENSOR_OPERATIONS_T *operations = (SENSOR_OPERATIONS_T *)ops;

	operations->Read = GROVEPI_LEDRead;
	operations->Close = GROVEPI_LEDClose;
	operations->Control = GROVEPI_LEDControl;

    grove_init();
    pinMode(LED_PIN, PIN_MODE);
	return 0;
}

/**
 * @brief GROVEPI_LED device value read funciton
 * @param[in]  structure member mLastValue pointer
 * @return	 0 => Success read data
 * 		-1 => Error ioctl operation 
 * 		-3 => Error read operation 
 */
int GROVEPI_LEDRead(char *data,int *len)
{
    sprintf(data,"%s",stored_str);
    *len = strlen(data);
	return 0;
}

/**
 * @brief GROVEPI_LED device close funciton
 * @param[in] No parameter
 * @return 0 = default
 */
int GROVEPI_LEDClose(void)
{
	return 0;
}


/**
 * @brief GROVEPI_LED device Control funciton
 * @param[in] data Control data
 * @param[in] len  Control data length
 * @return	 result Result string
 */
char* GROVEPI_LEDControl(char *data, int len)
{
    short led_switch;
    memcpy(&led_switch, data, len);
    memset(stored_str, 0, sizeof(stored_str));
    if( led_switch == 8 ){
        memcpy(stored_str, "off", sizeof("off"));
        digitalWrite(4,0);
    } else {
        memcpy(stored_str, "on", sizeof("on"));
        digitalWrite(4,1);
    }
    return strdup("success");
}

