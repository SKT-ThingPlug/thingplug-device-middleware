/*
 * @file grovepi_lcd.h
 *
 * @brief GROVEPI_LCD Sensor handler header
 *
 * Copyright (C) 2016. SK Telecom, All Rights Reserved.
 * Written 2016, by SK Telecom 
 */

#ifndef _GROVEPI_LCD_H_
#define _GROVEPI_LCD_H_

/*
 **************************************** 
 * Major Functions
 **************************************** 
 */


/**
 * @brief GROVEPI_LCD device init function
 * @param[in] No parameter
 * @return	 0 => Success init
 * 		-1 => Error file open 
 */
int GROVEPI_LCDInit(void *ops);

/**
 * @brief GROVEPI_LCD device value read funciton
 * @param[in]  structure member mLastValue pointer
 * @return	 0 => Success read data
 * 		-1 => Error ioctl operation 
 * 		-3 => Error read operation 
 */
int GROVEPI_LCDRead(char *data, int *len);

/**
 * @brief GROVEPI_LCD device close funciton
 * @param[in] No parameter
 * @return 0 = default
 */
int GROVEPI_LCDClose(void);

/**
 * @brief GROVEPI_LCD device Control funciton
 * @param[in] data Control data
 * @param[in] len  Control data length
 * @return	 result Result string
 */
char* GROVEPI_LCDControl(char *data, int len);

#endif//_GROVEPI_LCD_H_
