/**
 * @file grovepi_temp.c
 *
 * @brief grovepi temp Sensor Device Handler
 *
 * Copyright (C) 2017. SK Telecom, All Rights Reserved.
 * Written 2017, by SK Telecom 
 */
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/stat.h>
#include <sys/ioctl.h>
#include <fcntl.h>
#include <string.h>
#include <linux/i2c.h>
#include <linux/i2c-dev.h>
#include "grovepi_temp.h"
#include "Foundation.h"
#include "SensorManager.h"
#include "grovepi.h"

/*
 **************************************** 
 * Definition & Global Variable
 **************************************** 
 */
#define TEMP_PIN 7

/*
 **************************************** 
 * GROVEPI_TEMP device Main Handle Functions 
 **************************************** 
 */

//static char stored_str[32] = "";

/**
 * @brief GROVEPI_TEMP device init function
 * @param[in] No parameter
 * @return	 0 => Success init
 * 		-1 => Error file open 
 */
int GROVEPI_TEMPInit(void *ops)
{
	SENSOR_OPERATIONS_T *operations = (SENSOR_OPERATIONS_T *)ops;

	operations->Read = GROVEPI_TEMPRead;
	operations->Close = GROVEPI_TEMPClose;
	operations->Control = NULL;

    grove_init();
	return 0;
}

/**
 * @brief GROVEPI_TEMP device value read funciton
 * @param[in]  structure member mLastValue pointer
 * @return	 0 => Success read data
 * 		-1 => Error ioctl operation 
 * 		-3 => Error read operation 
 */
int GROVEPI_TEMPRead(char *data,int *len)
{
    float temp,humi;
    dhtRead(7, 0 , &temp, &humi );
    sprintf(data,"%.3f",temp);
    *len = strlen(data);
	return 0;
}

/**
 * @brief GROVEPI_TEMP device close funciton
 * @param[in] No parameter
 * @return 0 = default
 */
int GROVEPI_TEMPClose(void)
{
	return 0;
}


/**
 * @brief GROVEPI_TEMP device Control funciton
 * @param[in] data Control data
 * @param[in] len  Control data length
 * @return	 result Result string
 */
char* GROVEPI_TEMPControl(char *data, int len)
{
    return NULL;
}

