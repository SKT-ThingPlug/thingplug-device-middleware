
#ifndef GROVEPI_H
#define GROVEPI_H

//Initialize
int grove_init(void);
int pinMode(int pin,int mode);
int analogRead(int pin);
int analogWrite(int pin,int value);
int digitalRead(int pin);
int digitalWrite(int pin,int value);
int dhtRead(int pin, unsigned char module_type, float *temp, float *humidity);
int lcd_init(void);
int lcd_set_RGB(unsigned char red, unsigned char green, unsigned char blue);
void lcd_set_text(const char *str);
#endif /*GROVEPI_H */

