/**
 * @file StepDetector.c
 *
 * @brief StepDetector Sensor Device Handler
 *
 * Copyright (C) 2016. SK Telecom, All Rights Reserved.
 * Written 2016, by SK Telecom
 */
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <string.h>
#include "StepDetector.h"
#include "SensorManager.h"

/*
 ****************************************
 * Definition & Global Variable
 ****************************************
 */
#define BUFF_SIZE  128
#define FILE_NAME  "/sys/bus/w1/devices/28-0315030fecff/w1_slave"

static char gDummyData[1][20] = {"1"};
static int gIndex = 0;

/*
 ****************************************
 * StepDetector device Main Handle Functions
 ****************************************
 */

/**
 * @brief StepDetector device init function
 * @param[in] No parameter
 * @return	 0 => Success init
 * 		-1 => Error file open
 */
int StepDetectorInit(void *ops)
{
	SENSOR_OPERATIONS_T *operations = (SENSOR_OPERATIONS_T *)ops;
	gIndex = 0;

	operations->Read = StepDetectorRead;
	operations->Close = StepDetectorClose;
	operations->Control = StepDetectorControl;
	return 0;
}

/**
 * @brief StepDetector device control function(sample)
 * @param[in] data Control data
 * @param[in] len  Control data length
 * @return	 result Result string
 */
char* StepDetectorControl(char *data, int len)
{
	char result[256];
	char cmd[8] = "";
	char id[126] = "";
    int ret = 0;

    // TODO data parsing & Control

	if( ret == 0 ) {
		sprintf(result,"{\"id\": \"%s\", \"result\": \"%s\"}",id,cmd);
	} else {
		sprintf(result,"{\"id\": \"%s\", \"error\": {\"code\": -32000, \"message\":\"Device not found\"}}",id);
	}

	return strdup(result);
}

/**
 * @brief StepDetector device StepDetector value read funciton
 * @param[in]  structure member mLastValue pointer
 * @return	 0 => Success read data
 * 		-3 => Error read operation
 * 		-4 => Error lseek operation
 */
int StepDetectorRead(char *data, int *len)
{
	strcpy(data,gDummyData[gIndex]);
	*len = strlen(data);
	return 0;
}

/**
 * @brief StepDetector device close funciton
 * @param[in] No parameter
 * @return 0 = default
 */
int StepDetectorClose(void)
{
	return 0;
}

/**
 * @brief StepDetector Extract StepDetector value
 * @param[in] Raw Data
 * @return 0 = StepDetector Value
 */
int getStepDetectorValue(char *data)
{
	return 0;
}

