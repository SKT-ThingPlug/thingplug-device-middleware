/*
 * @file ph.h
 *
 * @brief PH Sensor handler header
 *
 * Copyright (C) 2016. SK Telecom, All Rights Reserved.
 * Written 2016, by SK Telecom
 */

#ifndef _PH_H_
#define _PH_H_

/*
 ****************************************
 * Enumerations
 ****************************************
 */


/*
 ****************************************
 * Major Functions
 ****************************************
 */

/**
 * @brief PH device init function
 * @param[in] No parameter
 * @return	 0 => Success init
 * 		-1 => Error file open
 */
int PHInit(void* ops);

/**
 * @brief PH device button value read funciton
 * @param[in]  structure member mLastValue pointer
 * @return	 0 => Success read data
 * 		-1 => Error ioctl operation
 * 		-2 => Error write operation
 * 		-3 => Error read operation
 */
int PHRead(char *data, int *len);

/**
 * @brief PH device close funciton
 * @param[in] No parameter
 * @return 0 = default
 */
int PHClose(void);


#endif //_PH_H_
