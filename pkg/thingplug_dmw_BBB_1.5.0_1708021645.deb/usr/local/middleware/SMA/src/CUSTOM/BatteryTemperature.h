/*
 * @file BatteryTemperature.h
 *
 * @brief BatteryTemperature Sensor handler header
 *
 * Copyright (C) 2016. SK Telecom, All Rights Reserved.
 * Written 2016, by SK Telecom
 */

#ifndef _BATTERYTEMPERATURE_H_
#define _BATTERYTEMPERATURE_H_

/*
 ****************************************
 * Enumerations
 ****************************************
 */


/*
 ****************************************
 * Major Functions
 ****************************************
 */

/**
 * @brief BatteryTemperature device init function
 * @param[in] No parameter
 * @return	 0 => Success init
 * 		-1 => Error file open
 */
int BatteryTemperatureInit(void *ops);

/**
 * @brief BatteryTemperature device button value read funciton
 * @param[in]  structure member mLastValue pointer
 * @return	 0 => Success read data
 * 		-1 => Error ioctl operation
 * 		-2 => Error write operation
 * 		-3 => Error read operation
 */
int BatteryTemperatureRead(char *data, int *len);

/**
 * @brief BatteryTemperature device close funciton
 * @param[in] No parameter
 * @return 0 = default
 */
int BatteryTemperatureClose(void);

/**
 * @brief BatteryTemperature device control function(sample)
 * @param[in] data Control data
 * @param[in] len  Control data length
 * @return	 result Result string
 */
char* BatteryTemperatureControl(char *data, int len);
#endif //_BATTERYTEMPERATURE_H_
