/**
 * @file Accelerometer.c
 *
 * @brief Accelerometer Sensor Device Handler
 *
 * Copyright (C) 2016. SK Telecom, All Rights Reserved.
 * Written 2016, by SK Telecom
 */
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <string.h>
#include "Accelerometer.h"
#include "SensorManager.h"

/*
 ****************************************
 * Definition & Global Variable
 ****************************************
 */
#define BUFF_SIZE  128
#define FILE_NAME  "/sys/bus/w1/devices/28-0315030fecff/w1_slave"

//static char gDummyData[1][20] = {"31.31,0.1,9.89"};
static char gDummyData[3][20] = {"31.31","0.1","9.89"};
static int gIndex = 0;

int AccelerometerRead_X(char *data, int *len);
int AccelerometerRead_Y(char *data, int *len);
int AccelerometerRead_Z(char *data, int *len);
/*
 ****************************************
 * Accelerometer device Main Handle Functions
 ****************************************
 */

/**
 * @brief Accelerometer device init function
 * @param[in] No parameter
 * @return	 0 => Success init
 * 		-1 => Error file open
 */
int AccelerometerInit(void *ops, char axis)
{
	SENSOR_OPERATIONS_T *operations = (SENSOR_OPERATIONS_T *)ops;

    if( axis ==  'X' ) {
	    operations->Read = AccelerometerRead_X;
    } else if ( axis == 'Y' ) {
	    operations->Read = AccelerometerRead_Y;
    } else if ( axis == 'Z' ) {
	    operations->Read = AccelerometerRead_Z;
    } else {
	    operations->Read = AccelerometerRead;
    }
	operations->Close = AccelerometerClose;
	operations->Control = AccelerometerControl;
	return 0;
}

/**
 * @brief Accelerometer device control function(sample)
 * @param[in] data Control data
 * @param[in] len  Control data length
 * @return	 result Result string
 */
char* AccelerometerControl(char *data, int len)
{
	char result[256];
	char cmd[8] = "";
	char id[126] = "";
    int ret = 0;

    // TODO data parsing & Control
	if( ret == 0 ) {
		sprintf(result,"{\"id\": \"%s\", \"result\": \"%s\"}",id,cmd);
	} else {
		sprintf(result,"{\"id\": \"%s\", \"error\": {\"code\": -32000, \"message\":\"Device not found\"}}",id);
	}

	return strdup(result);
}


int AccelerometerRead_X(char *data, int *len)
{
	strcpy(data,gDummyData[0]);
	*len = strlen(data);
	return 0;
}
int AccelerometerRead_Y(char *data, int *len)
{
	strcpy(data,gDummyData[1]);
	*len = strlen(data);
	return 0;
}
int AccelerometerRead_Z(char *data, int *len)
{
	strcpy(data,gDummyData[2]);
	*len = strlen(data);
	return 0;
}
/**
 * @brief Accelerometer device Accelerometer value read funciton
 * @param[in]  structure member mLastValue pointer
 * @return	 0 => Success read data
 * 		-3 => Error read operation
 * 		-4 => Error lseek operation
 */
int AccelerometerRead(char *data, int *len)
{
	strcpy(data,gDummyData[gIndex]);
	*len = strlen(data);
	return 0;
}

/**
 * @brief Accelerometer device close funciton
 * @param[in] No parameter
 * @return 0 = default
 */
int AccelerometerClose(void)
{
	return 0;
}

/**
 * @brief Accelerometer Extract Accelerometer value
 * @param[in] Raw Data
 * @return 0 = Accelerometer Value
 */
int getAccelerometerValue(char *data)
{
	return 0;
}

