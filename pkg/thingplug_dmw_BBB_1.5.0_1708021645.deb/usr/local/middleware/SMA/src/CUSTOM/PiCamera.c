/**
 * @file PiCamera.c
 *
 * @brief PiCamera Sensor Device Handler
 *
 * Copyright (C) 2017. SK Telecom, All Rights Reserved.
 * Written 2017, by SK Telecom
 */
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <string.h>
#include <time.h>
#include <net/if.h>
#include "PiCamera.h"
#include "SensorManager.h"

/*
 ****************************************
 * Definition & Global Variable
 ****************************************
 */

/*
 ****************************************
 * PiCamera device Main Handle Functions
 ****************************************
 */

/**
 * @brief PiCamera device init function
 * @param[in] No parameter
 * @return	 0 => Success init
 * 		-1 => Error file open
 */
int PiCameraInit(void *ops)
{
	SENSOR_OPERATIONS_T *operations = (SENSOR_OPERATIONS_T *)ops;

	operations->Read = PiCameraRead;
	operations->Close = PiCameraClose;
	operations->Control = PiCameraControl;
	return 0;
}

static char* timeToString(struct tm *t) {
    static char s[20];
    sprintf(s, "%04d%02d%02d%02d%02d%02d",
            t->tm_year + 1900, t->tm_mon + 1, t->tm_mday,
            t->tm_hour, t->tm_min, t->tm_sec );
    return s;
}

/**
 * @brief PiCamera device control function(sample)
 * @param[in] data Control data
 * @param[in] len  Control data length
 * @return	 result Result string
 */
char* PiCameraControl(char *data, int len)
{
    // TODO data parsing & Control
    struct tm *t;
    time_t timer;
    timer = time(NULL);
    t = localtime(&timer); 
    char capture[128] ="";
    char* time = timeToString(t);

    sprintf(capture, "raspistill -w 640 -h 480 -o /usr/local/middleware/log/%s.jpg -n -t 100",time);
    int ret = system(capture);
    if( ret == 0 ) {
	    return strdup("start camera");
    }
    return strdup("error camera");
}

/**
 * @brief PiCamera device PiCamera value read funciton
 * @param[in]  structure member mLastValue pointer
 * @return	 0 => Success read data
 * 		-3 => Error read operation
 * 		-4 => Error lseek operation
 */
int PiCameraRead(char *data, int *len)
{
	return -3;
}

/**
 * @brief PiCamera device close funciton
 * @param[in] No parameter
 * @return 0 = default
 */
int PiCameraClose(void)
{
	return 0;
}

/**
 * @brief PiCamera Extract PiCamera value
 * @param[in] Raw Data
 * @return 0 = PiCamera Value
 */
int getPiCameraValue(char *data)
{
	return 0;
}

