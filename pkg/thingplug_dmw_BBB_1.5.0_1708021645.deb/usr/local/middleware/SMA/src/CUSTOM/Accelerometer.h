/*
 * @file Accelerometer.h
 *
 * @brief Accelerometer Sensor handler header
 *
 * Copyright (C) 2016. SK Telecom, All Rights Reserved.
 * Written 2016, by SK Telecom
 */

#ifndef _ACCELEROMETER_H_
#define _ACCELEROMETER_H_

/*
 ****************************************
 * Enumerations
 ****************************************
 */


/*
 ****************************************
 * Major Functions
 ****************************************
 */

/**
 * @brief Accelerometer device init function
 * @param[in] No parameter
 * @return	 0 => Success init
 * 		-1 => Error file open
 */
int AccelerometerInit(void *ops, char axis);

/**
 * @brief Accelerometer device button value read funciton
 * @param[in]  structure member mLastValue pointer
 * @return	 0 => Success read data
 * 		-1 => Error ioctl operation
 * 		-2 => Error write operation
 * 		-3 => Error read operation
 */
int AccelerometerRead(char *data, int *len);

/**
 * @brief Accelerometer device close funciton
 * @param[in] No parameter
 * @return 0 = default
 */
int AccelerometerClose(void);

/**
 * @brief Accelerometer device control function(sample)
 * @param[in] data Control data
 * @param[in] len  Control data length
 * @return	 result Result string
 */
char* AccelerometerControl(char *data, int len);
#endif //_ACCELEROMETER_H_
