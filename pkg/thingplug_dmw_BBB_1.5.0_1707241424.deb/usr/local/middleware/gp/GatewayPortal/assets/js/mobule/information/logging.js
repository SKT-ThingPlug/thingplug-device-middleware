
/**
 *
 * 연결조회 > 시스템 로그
 *
 */

(function () {

		// 센서 리스트
//		sensor.init(true, false);
		
	$(function () {

		BASE_DOM = $(".sensor_list tr:first").clone();
		$(".sensor_list tr:first").remove();

		connection_sensor.init();
		
		// 로그 히스토리 
		setTimeout(function () {
			_history.init(_history.All, false);
		}, 1000);

	});
	
	
	window.connection_sensor = {
		
		index : 0,
		
		init : function () {
			var that = this;
			// 센서 리스트
			ipc.send("getDevice", false, function (res) {
				if (res.DM_RESULT == IPC.DM_RESULT_SUCCESS) {
					that.getAllDeviceSensorStatus(res.DM_DEVICE_ID);
				}
			});
		},
		
		getAllDeviceSensorStatus : function(DEVICE_LIST){
			
			var that = this;
			if(this.index < DEVICE_LIST.length){
				var params = new Params();
				params.put("DM_DEVICE_ID", DEVICE_LIST[this.index]);
				ipc.send("getAllDeviceSensorStatus", params, function (res) {
					
					if (res.DM_RESULT == IPC.DM_RESULT_SUCCESS) {
						
						for (var q in res.DM_SENSOR_ARRAY) {
							
							var sensor = res.DM_SENSOR_ARRAY[q];
							// 로그쪽 장비 셀렉트박스 
							$("#sel_01").append('<option value="' + sensor.DM_DEVICE_ID + "_" +sensor.DM_SENSOR_ID + '">'  + sensor.DM_DEVICE_ID + " > " +sensor.DM_SENSOR_TYPE + '</option>');
						}
						
						that.getAllDeviceSensorStatus(DEVICE_LIST);
						console.log("that : ",  that);
					}
				});
				
				this.index++;
				
			}
		}
		
	}
	
})();