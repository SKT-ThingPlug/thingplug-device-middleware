
//var isLoginBlocked = false;

/**
 *
 * 로그인
 *
 */

(function () {

	$(function () {

//		if(isLoginBlocked) {
//			$(".bt_cbtnB").attr("disabled","disabled");
//		}

		$("form").submit(function (e) {

			e.preventDefault();

			if ($("#userId").Empty(__("아이디를 입력하세요"))) return;
			if ($("#userPassword").Empty(__("비밀번호를 입력하세요"))) return;

			var params = new Params();
			params.put("userId", $("#userId").val());
			params.put("userPassword", $("#userPassword").val());

			// 로그인 요청
			ipc.start(1);
			ipc.send("authentication", params, function (res) {
				ipc.end();

				if (res.DM_RESULT == IPC.DM_RESULT_SUCCESS) {
					alert(__("로그인 되었습니다"));
					
					if ((res.DM_HAS_ACCOUNT != undefined) && (res.DM_HAS_ACCOUNT == IPC.DM_STATUS_NO)) {
						$("#login_window").css({"display": "none"});
						$("#IDset_window").removeClass("windowOff");			
					
					} else if (window.location.href.indexOf("?") == -1) {
						window.location.href = "/Dashboard/Dashboard";	
						
					} else {
						window.location.href = "/Intro/Step_01";
						
					}

				} else if (res.DM_RESULT >= IPC.DM_RESULT_FAIL  && res.DM_RESULT <= 5) {
					alert(__("로그인에 실패하였습니다"));
				} else if (res.DM_RESULT > 5 && res.DM_RESULT <= 10 ) {
//					isLoginBlocked = true;
					$(".bt_cbtnB").prop('disabled', true);
					alert(__("5회이상 실패. 10초간 로그인이 정지됩니다."));
					setTimeout(function(){
//						isLoginBlocked = false;
						$(".bt_cbtnB").prop('disabled', false);
					}, 10000);
				} else if (res.DM_RESULT > 10 && res.DM_RESULT <= 20 ) {
//					isLoginBlocked = true;
					$(".bt_cbtnB").prop('disabled', true);
					alert(__("10회이상 실패. 1분간 로그인이 정지됩니다."));
					setTimeout(function(){
//						isLoginBlocked = false;
						$(".bt_cbtnB").prop('disabled', false);
					}, 60000);

				} else if (res.DM_RESULT > 20) {
//					isLoginBlocked = true;
					$(".bt_cbtnB").prop('disabled', true);
					alert(__("20회이상 실패. 1시간 로그인이 정지됩니다."));
					setTimeout(function(){
//						isLoginBlocked = false;
						$(".bt_cbtnB").prop('disabled', false);
					}, 3600000);

				}
			});
			
		});
		
		
		$(".bt_submit").click(function (e) {

			e.preventDefault();

			if ($("#userNewId").Empty(__("아이디를 입력하세요"))) return;
			if ($("#userNewPassword").Empty(__("비밀번호를 입력하세요"))) return;
			if ($("#userNewPassword2").Empty(__("비밀번호를 입력하세요"))) return;

			if ($("#userNewPassword").val() != $("#userNewPassword2").val()) {
				alert(__("변경할 비밀번호가 일치하지 않습니다"));
				$("#userPassword2").focus();
				return;
			}
			
			var userNewID = $("#userNewId").val().trim();
			var userNewPassword = $("#userNewPassword2").val().trim();
			
			if(userNewID.length < 5) {
				alert(__("아이디는 5자 이상으로 입력해주세요!"));
				$("#userNewId").focus();
				return false;
			} else if (userNewID.length > 15){
				alert(__("아이디는 15자 이내로 입력해주세요!"));
				$("#userNewId").focus();
				return false;		
			}
			
			if(userNewPassword.length < 9) {
				alert(__("패스워드는 9자 이상으로 입력해주세요!"));
				$("#userNewPassword").focus();
				return false;
			} else if (userNewPassword.length > 20){
				alert(__("패스워드는 20자 이내로 입력해주세요!"));
				$("#userNewPassword").focus();
				return false;		
			}
			
			var re = /[A-Za-z]/;
			if(!re.test(userNewPassword)) {
			  alert(__("패스워드는 영문자를 포함해야합니다."));
			  $("#userNewPassword").focus();
			  return false;
			}
			
			re = /[0-9]/;
			if(!re.test(userNewPassword)) {
			  alert(__("패스워드는 숫자를 포함해야합니다."));
			  $("#userNewPassword").focus();
			  return false;
			}
			
			re = /[^\w]/;
			if(!re.test(userNewPassword)) {
			  alert(__("패스워드는 특수문자를 포함해야합니다."));
			  $("#userNewPassword").focus();
			  return false;
			}
			
			var params = new Params();
			params.put("DM_ADMIN_ID", $("#userOldId").val());
			params.put("DM_ADMIN_PASSWD", $("#userOldPass").val());
			params.put("DM_ADMIN_NEW_ID", userNewID);
			params.put("DM_ADMIN_NEW_PASSWD", userNewPassword);

			console.log(params);
			ipc.start(1);
			ipc.send("changeAuth", params, function (res) {
				ipc.end();
				
				if (res.DM_RESULT == IPC.DM_RESULT_SUCCESS) {
					alert(__("정상적으로 변경되었습니다"));
					
					if (window.location.href.indexOf("?") == -1) {
						window.location.href = "/Dashboard/Dashboard";				
					} else {
						window.location.href = "/Intro/Step_01";	
					}
					
				} else if (res.DM_RESULT == IPC.DM_RESULT_ALEADY_REGISTERED) {
					alert(__("비밀번호가 일치하지 않습니다"));
				} else {
					alert(__("변경에 실패하였습니다"));
				}
			});
		});		
	});
})();