/**
 * @file SensorCommandList.h
 *
 * @brief Sensor command list container manager header
 *
 * Copyright (C) 2016. SK Telecom, All Rights Reserved.
 * Written 2016, by SK Telecom
 */

#ifndef __SENSOR_COMMAND_LIST_H__
#define __SENSOR_COMMAND_LIST_H__

/*
 ****************************************
 * Definitions
 ****************************************
 */

/*
 ****************************************
 * Enumerations
 ****************************************
 */

/*
 ****************************************
 * Structures
 ****************************************
 */

typedef struct tagCommandNode {
	char   	mCommandTag;
    char   *mCommandName;
	int     mNameLength;
    char* (*mCommandFunction)(char *);
    struct tagCommandNode   *mNextNode;
}COMMAND_NODE_T;

typedef struct tagCommandLIST {
	int         mCount;
    int         mLengths;
    COMMAND_NODE_T *mHead;
}COMMAND_LIST_T;

/*
 ****************************************
 * Public Functions
 ****************************************
 */

int RegisterSensorCommand(char commandTag, char *commandName, char* (*commandFunction)(char*));
int CancelSensorCommand(char *commandName);
int ExecuteSensorCommand(char *commandName, char *commandArg, char *result);
int ExecuteSensorCommandTag(char commandTag, char *commandArg, char *result);
int GetSensorCommandListCount(void);
char GetSensorCommandTagPosition(int position);
char *GetSensorCommandNamePosition(int position);

#endif /* __SENSOR_COMMAND_LIST_H__ */

