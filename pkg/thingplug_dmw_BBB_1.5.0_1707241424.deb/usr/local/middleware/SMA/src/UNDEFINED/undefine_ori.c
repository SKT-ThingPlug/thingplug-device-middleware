/**
 * @file undefine.c
 *
 * @brief UNDEFINE Sensor Device Handler
 *
 * Copyright (C) 2016. SK Telecom, All Rights Reserved.
 * Written 2016, by SK Telecom
 */
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <string.h>
#include "undefine.h"

/*
 ****************************************
 * Definition & Global Variable
 ****************************************
 */
#define BUFF_SIZE  128
#define FILE_NAME  "/sys/bus/w1/devices/28-0315030fecff/w1_slave"

static int gUNDEFINEFd;

static char gDummyData[10][20] = 
	{"One","Two","Three","Four","Five","Six","Seven","Eight","Nine","Ten"};
static int gIndex = 0;

/*
 ****************************************
 * UNDEFINE device Main Handle Functions
 ****************************************
 */

/**
 * @brief UNDEFINE device init function
 * @param[in] No parameter
 * @return	 0 => Success init
 * 		-1 => Error file open
 */
int UNDEFINEInit(void)
{
	//gUNDEFINEFd = open(FILE_NAME, O_RDONLY, S_IREAD);
	gIndex = 0;
	return 0;
}

/**
 * @brief UNDEFINE device UNDEFINE value read funciton
 * @param[in]  structure member mLastValue pointer
 * @return	 0 => Success read data
 * 		-3 => Error read operation
 * 		-4 => Error lseek operation
 */
int UNDEFINERead(char *data, int *len)
{
	strcpy(data,gDummyData[gIndex]);
	*len = strlen(data);
	gIndex++;
	gIndex %= 10;
	return 0;
}

/**
 * @brief UNDEFINE device close funciton
 * @param[in] No parameter
 * @return 0 = default
 */
int UNDEFINEClose(void)
{
	close(gUNDEFINEFd);
	return 0;
}

/**
 * @brief UNDEFINE Extract UNDEFINE value
 * @param[in] Raw Data
 * @return 0 = UNDEFINE Value
 */
int getUNDEFINEValue(char *data)
{
	return 0;
}
