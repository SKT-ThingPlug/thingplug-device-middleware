/*
 * @file BatteryState.h
 *
 * @brief BatteryState Sensor handler header
 *
 * Copyright (C) 2016. SK Telecom, All Rights Reserved.
 * Written 2016, by SK Telecom
 */

#ifndef _BATTERYSTATE_H_
#define _BATTERYSTATE_H_

/*
 ****************************************
 * Enumerations
 ****************************************
 */


/*
 ****************************************
 * Major Functions
 ****************************************
 */

/**
 * @brief BatteryState device init function
 * @param[in] No parameter
 * @return	 0 => Success init
 * 		-1 => Error file open
 */
int BatteryStateInit(void *ops);

/**
 * @brief BatteryState device button value read funciton
 * @param[in]  structure member mLastValue pointer
 * @return	 0 => Success read data
 * 		-1 => Error ioctl operation
 * 		-2 => Error write operation
 * 		-3 => Error read operation
 */
int BatteryStateRead(char *data, int *len);

/**
 * @brief BatteryState device close funciton
 * @param[in] No parameter
 * @return 0 = default
 */
int BatteryStateClose(void);

/**
 * @brief BatteryState device control function(sample)
 * @param[in] data Control data
 * @param[in] len  Control data length
 * @return	 result Result string
 */
char* BatteryStateControl(char *data, int len);
#endif //_BATTERYSTATE_H_
