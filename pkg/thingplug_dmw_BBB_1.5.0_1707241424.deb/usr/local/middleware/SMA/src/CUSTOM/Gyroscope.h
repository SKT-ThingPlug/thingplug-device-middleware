/*
 * @file custom.h
 *
 * @brief Gyroscope Sensor handler header
 *
 * Copyright (C) 2016. SK Telecom, All Rights Reserved.
 * Written 2016, by SK Telecom
 */

#ifndef _GYROSCOPE_H_
#define _GYROSCOPE_H_

/*
 ****************************************
 * Enumerations
 ****************************************
 */


/*
 ****************************************
 * Major Functions
 ****************************************
 */

/**
 * @brief Gyroscope device init function
 * @param[in] No parameter
 * @return	 0 => Success init
 * 		-1 => Error file open
 */
int GyroscopeInit(void *ops, char axis);

/**
 * @brief Gyroscope device button value read funciton
 * @param[in]  structure member mLastValue pointer
 * @return	 0 => Success read data
 * 		-1 => Error ioctl operation
 * 		-2 => Error write operation
 * 		-3 => Error read operation
 */
int GyroscopeRead(char *data, int *len);

/**
 * @brief Gyroscope device close funciton
 * @param[in] No parameter
 * @return 0 = default
 */
int GyroscopeClose(void);

/**
 * @brief Gyroscope device control function(sample)
 * @param[in] data Control data
 * @param[in] len  Control data length
 * @return	 result Result string
 */
char* GyroscopeControl(char *data, int len);
#endif //_GYROSCOPE_H_
