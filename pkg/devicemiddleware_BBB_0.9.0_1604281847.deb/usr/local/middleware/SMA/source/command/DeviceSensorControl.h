/**
 * @file DeviceSensorControl.h
 *
 * @brief Device sensor control command header
 *
 * Copyright (C) 2015. SPTek,All Rights Reserved.
 * Written 2015,by SPTek
 */

#ifndef __DEVICE_SENSOR_CONTROL_H__
#define __DEVICE_SENSOR_CONTROL_H__

#include "BaseCommand.h"

/*
 ****************************************
 * Public Functions
 ****************************************
 */
int DeviceSensorControlCommandProcess(SPTekRECEIVE_MESSAGE_T *receiveMessage, char *contents, int length, SPTekSEND_MESSAGE_T *sendMessage);

#endif /* __DEVICE_SENSOR_CONTROL_H__ */

