/**
 * @file SensorConfiguration.c
 *
 * @brief Sensor configuration & operation functions
 *
 * Copyright (C) 2015. SPTek,All Rights Reserved.
 * Written 2015,by SPTek
 */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <search.h>
#include "ErrorDefinition.h"
#include "DataComposition.h"
#include "SensorConfiguration.h"

/*
 ****************************************
 * Global Value Declaration
3. ****************************************
 */

// Sensor information
//DeviceID,SensorID,SensorName,SensorType,EnableFlag,ReadInterval,ReadMode,LastValue,StartTime,EndTime,SerialNumber,OperationType,MaxInterval,ControlType,RegisterFlag
SENSOR_CONFIGURATION_T mSensorConfiguration[SENSOR_ID_MAX] = {
	{"DEV-0",  "0000000001", "HC_SR501",        "motion",       1, 2, 0, "0", 0, 0, "N/A", 1, -1 ,2,0},  
	{"DEV-0",  "0000000002", "DS18B20",         "temperature",  1, 4, 0, "0", 0, 0, "N/A", 2, 3600, 2,0},  
	{"DEV-0",  "0000000003", "BH1750",          "light",        1, 4, 0, "0", 0, 0, "N/A", 2, 3600, 2,0},  
	{"DEV-0",  "0000000004", "HTU21D",          "humidity",     1, 4, 0, "0", 0, 0, "N/A", 2, 3600, 2,0},  
	{"DEV-0",  "0000000005", "BUT001",          "onoff",        1, 4, 0, "0", 0, 0, "N/A", 2, -1, 2,0},  
	{"DEV-0",  "0000000006", "TCACB_147",       "noise",        1, 4, 0, "0", 0, 0, "N/A", 2, 3600, 2,0},  
	{"DEV-0",  "0000000007", "PM1001",          "dust",         1, 4, 0, "0", 0, 0, "N/A", 2, 3600, 2,0},  
	{"DEV-0",  "0000000008", "CM1101",          "co2",          1, 4, 0, "0", 0, 0, "N/A", 2, 3600, 2,0}, 
	{"DEV-0",  "0000000009", "MC38",            "door",         1, 4, 0, "0", 0, 0, "N/A", 1, -1, 2,0},  
	{"DEV-0",  "0000000010", "RGB_LED",         "7colorRGBLed", 1, 4, 0, "0", 0, 0, "N/A", 2, -1, 1,0}, 
	{"DEV-0",  "0000000011", "BUZZER",          "buzzer",       1, 4, 0, "0", 0, 0, "N/A", 2, -1, 2,0}, 
	{"DEV-0",  "0000000012", "PRESSURE",        "pressure",     1, 4, 0, "0", 0, 0, "N/A", 2, -1, 2,0}, 
	{"DEV-0",  "0000000013", "WINDVANE",        "windvane",     1, 4, 0, "0", 0, 0, "N/A", 2, -1, 2,0}, 
	{"DEV-0",  "0000000014", "PH",              "ph",           1, 4, 0, "0", 0, 0, "N/A", 2, -1, 2,0}, 
	{"DEV-0",  "0000000015", "PERCENT",         "percent",      1, 4, 0, "0", 0, 0, "N/A", 2, -1, 2,0}, 
	{"DEV-0",  "0000000016", "COMPLEX",         "complex",      1, 4, 0, "0", 0, 0, "N/A", 2, -1, 2,0}, 
	{"DEV-0",  "0000000017", "STRING",          "string",       1, 4, 0, "0", 0, 0, "N/A", 2, -1, 2,0}, 
	{"DEV-0",  "0000000018", "NUMBER",          "number",       1, 4, 0, "0", 0, 0, "N/A", 2, -1, 2,0}, 
	{"DEV-0",  "0000000019", "CUSTOM",          "custom",       1, 4, 0, "0", 0, 0, "N/A", 2, 3600, 2,1},  
	{"DEV-0",  "0000000020", "UNDEFINED",       "undefined",    1, 4, 0, "0", 0, 0, "N/A", 2, 3600, 2,1}, 
};

/*
 ****************************************
 * Public Functions
 ****************************************
 */



/**
 * @brief Make sensor information to string
 * @param[in]   id    Sensor id enum value
 * @param[out]  buf   String pointer
 * @return Void
 */
void GetBackupSensorInformation(SENSOR_ID_E id, char *buf)
{
	if(id >= SENSOR_ID_MAX) {
		return;
	}
	sprintf(buf,"%s,%s,%s,%s,%d,%d,%d,%s,%d,%d,%s,%d,%d,%d,%d\n",
				mSensorConfiguration[id].mDeviceID,
				mSensorConfiguration[id].mSensorID,
				mSensorConfiguration[id].mSensorName,
				mSensorConfiguration[id].mSensorType,
				mSensorConfiguration[id].mState,
				mSensorConfiguration[id].mReadInterval,
				mSensorConfiguration[id].mReadMode,
				mSensorConfiguration[id].mLastValue,
				mSensorConfiguration[id].mStartTime,
				mSensorConfiguration[id].mEndTime,
				mSensorConfiguration[id].mSerialNumber,
				mSensorConfiguration[id].mOperationType,
				mSensorConfiguration[id].mMaxInterval,
				mSensorConfiguration[id].mControlType,
				mSensorConfiguration[id].mRegisterFlag);
}

/**
 * @brief Get sensor configuration information of sensor configuration
 * @param[in]   id             Target sendor id 
 * @param[out]  configuration  Sensor configuration structure pointer
 * @return  ERROR_TYPE_SUCCESS
 *          ERROR_TYPE_FAIL
 */
int GetSensorConfiguration(SENSOR_ID_E id, SENSOR_CONFIGURATION_T **configuration)
{
	int ret = ERROR_TYPE_SUCCESS;
	if(id >= SENSOR_ID_MAX) {
		return ERROR_TYPE_FAIL;
	}
	*configuration = &mSensorConfiguration[id];
	return ret;
}

/**
 * @brief Set device ID string of sensor configuration
 * @param[in]   id             Target sendor id 
 * @param[in]   deviceID       Input device ID string
 * @param[in]   length         Input device ID length
 * @return  ERROR_TYPE_SUCCESS
 *          ERROR_TYPE_FAIL
 */
int SetSensorDeviceId(SENSOR_ID_E id, char* deviceId, int length)
{
	if(id >= SENSOR_ID_MAX || length > MAX_LEN_DEVICE_ID) {
		return ERROR_TYPE_FAIL;
	}
	(void)memset(mSensorConfiguration[id].mDeviceID, 0,        MAX_LEN_DEVICE_ID+1);
	(void)memcpy(mSensorConfiguration[id].mDeviceID, deviceId, length);

	return ERROR_TYPE_SUCCESS;
}

/**
 * @brief Get sensor device ID string of sensor configuration
 * @param[in]   id             Target sendor id 
 * @return  String pointer
 *          NULL
 */
char* GetSensorDeviceId(SENSOR_ID_E id)
{
	if(id >= SENSOR_ID_MAX) {
		return NULL;
	}
	return GetDeviceID();
}

/**
 * @brief Set sensor ID string of sensor configuration
 * @param[in]   id             Target sendor id 
 * @param[in]   sensorID       Input sensor ID string
 * @param[in]   length         Input sensor ID length
 * @return  ERROR_TYPE_SUCCESS
 *          ERROR_TYPE_FAIL
 */
int SetSensorSensorId(SENSOR_ID_E id, char* sensorId, int length)
{
	if(id >= SENSOR_ID_MAX || length > MAX_LEN_SENSOR_ID) {
		return ERROR_TYPE_FAIL;
	}
	(void)memset(mSensorConfiguration[id].mSensorID, 0,        MAX_LEN_SENSOR_ID+1);
	(void)memcpy(mSensorConfiguration[id].mSensorID, sensorId, length);

	return ERROR_TYPE_SUCCESS;
}

/**
 * @brief Get sensor sensorID string of sensor configuration
 * @param[in]   id             Target sendor id 
 * @return  String pointer
 *          NULL
 */
char* GetSensorSensorId(SENSOR_ID_E id)
{
	if(id >= SENSOR_ID_MAX) {
		return NULL;
	}
	return mSensorConfiguration[id].mSensorID;
}

/**
 * @brief Set sensor name string of sensor configuration
 * @param[in]   id             Target sendor id 
 * @param[in]   sensorName     Input sensor name string
 * @param[in]   length         Input sensor name length
 * @return  ERROR_TYPE_SUCCESS
 *          ERROR_TYPE_FAIL
 */
int SetSensorSensorName(SENSOR_ID_E id, char* sensorName, int length)
{
	if(id >= SENSOR_ID_MAX || length > MAX_LEN_SENSOR_NAME) {
		return ERROR_TYPE_FAIL;
	}
	(void)memset(mSensorConfiguration[id].mSensorName, 0,          MAX_LEN_SENSOR_NAME+1);
	(void)memcpy(mSensorConfiguration[id].mSensorName, sensorName, length);

	return ERROR_TYPE_SUCCESS;
}

/**
 * @brief Get sensor sensor name string of sensor configuration                 
 * @param[in]   id             Target sendor id 
 * @return  String pointer
 *          NULL
 */
char* GetSensorSensorName(SENSOR_ID_E id)
{
	if(id >= SENSOR_ID_MAX) {
		return NULL;
	}
	return mSensorConfiguration[id].mSensorName;
}

/**
 * @brief Set sensor type string of sensor configuration
 * @param[in]   id             Target sendor id 
 * @param[in]   sensorType     Input sensor type string
 * @param[in]   length         Input sensor type length
 * @return  ERROR_TYPE_SUCCESS
 *          ERROR_TYPE_FAIL
 */
int SetSensorSensorType(SENSOR_ID_E id, char* sensorType, int length)
{
	if(id >= SENSOR_ID_MAX || length > MAX_LEN_SENSOR_TYPE) {
		return ERROR_TYPE_FAIL;
	}
	(void)memset(mSensorConfiguration[id].mSensorType, 0,          MAX_LEN_SENSOR_TYPE+1);
	(void)memcpy(mSensorConfiguration[id].mSensorType, sensorType, length);

	return ERROR_TYPE_SUCCESS;
}

/**
 * @brief Get sensor sensor type string of sensor configuration              
 * @param[in]   id             Target sendor id 
 * @return  String pointer
 *          NULL
 */
char* GetSensorSensorType(SENSOR_ID_E id)
{
	if(id >= SENSOR_ID_MAX) {
		return NULL;
	}
	return mSensorConfiguration[id].mSensorType;
}

/**
 * @brief Set sensor state string of sensor configuration
 * @param[in]   id             Target sendor id 
 * @param[in]   state          Input sensor state enum value
 * @return  ERROR_TYPE_SUCCESS
 *          ERROR_TYPE_FAIL
 */
int SetSensorState(SENSOR_ID_E id, SENSOR_STATE_E state)
{
	if(id >= SENSOR_ID_MAX) {
		return ERROR_TYPE_FAIL;
	}
	mSensorConfiguration[id].mState = state;

	return ERROR_TYPE_SUCCESS;
}

/**
 * @brief Get sensor sensor state of sensor configuration
 * @param[in]   id             Target sendor id 
 * @return  SENSOR_STATE_ENABLE
 *          SENSOR_STATE_DISABLE
 */
SENSOR_STATE_E GetSensorState(SENSOR_ID_E id)
{
	if(id >= SENSOR_ID_MAX) {
		return SENSOR_STATE_DISABLE;
	}
	return mSensorConfiguration[id].mState;
}

/**
 * @brief Set sensor read interval of sensor configuration
 * @param[in]   id             Target sendor id 
 * @param[in]   interval       Input sensor read interval
 * @return  ERROR_TYPE_SUCCESS
 *          ERROR_TYPE_FAIL
 */
int SetSensorReadInterval(SENSOR_ID_E id, unsigned int interval)
{
	if(id >= SENSOR_ID_MAX) {
		return ERROR_TYPE_FAIL;
	}
    mSensorConfiguration[id].mReadInterval = interval;

    return ERROR_TYPE_SUCCESS;
}

/**
 * @brief Get sensor read interval of sensor configuration
 * @param[in]   id             Target sendor id 
 * @return Read interval(sec)
 *         4294967294U == 0
 */
unsigned int GetSensorReadInterval(SENSOR_ID_E id)
{
	if(id >= SENSOR_ID_MAX) {
		return 4294967294U;
	}
	return mSensorConfiguration[id].mReadInterval;
}

/**
 * @brief Set sensor read mode of sensor configuration
 * @param[in]   id             Target sendor id 
 * @param[in]   readMode       Input sensor read mode enum value
 * @return  ERROR_TYPE_SUCCESS
 *          ERROR_TYPE_FAIL
 */
int SetSensorReadMode(SENSOR_ID_E id, SENSOR_MODE_E readMode)
{
	if(id >= SENSOR_ID_MAX) {
		return ERROR_TYPE_FAIL;
	}
    mSensorConfiguration[id].mReadMode = readMode;

    return ERROR_TYPE_SUCCESS;
}

/**
 * @brief Get sensor read mode of sensor configuration
 * @param[in]   id             Target sendor id 
 * @return  SENSOR_STATE_ENABLE
 *          SENSOR_STATE_DISABLE
 */
SENSOR_MODE_E GetSensorReadMode(SENSOR_ID_E id)
{
	if(id >= SENSOR_ID_MAX) {
		return SENSOR_MODE_MAX;
	}
	return mSensorConfiguration[id].mReadMode;
}

/**
 * @brief Set sensor last value of sensor configuration
 * @param[in]   id             Target sendor id 
 * @param[in]   lastValue      Input sensor last value
 * @return  ERROR_TYPE_SUCCESS
 *          ERROR_TYPE_FAIL
 */
int SetLastValue(SENSOR_ID_E id, char *lastValue, int length)
{
	if(id >= SENSOR_ID_MAX) {
		return ERROR_TYPE_FAIL;
	}
	(void)memset(mSensorConfiguration[id].mLastValue, 0, MAX_LEN_LAST_VALUE+1);
	(void)memcpy(mSensorConfiguration[id].mLastValue, lastValue, length);

    return ERROR_TYPE_SUCCESS;
}

/**
 * @brief Get sensor last value of sensor configuration
 * @param[in]   id             Target sendor id 
 * @return  Last value of target sensor
 */
char* GetLastValue(SENSOR_ID_E id)
{
	if(id >= SENSOR_ID_MAX) {
		return NULL;
	}
	return mSensorConfiguration[id].mLastValue;
}

/**
 * @brief Set sensor serial number string of sensor configuration
 * @param[in]   id             Target sendor id 
 * @param[in]   serialNumber   Input sensor serial number string pointer
 * @param[in]   length         Input sensor serial number string length
 * @return  ERROR_TYPE_SUCCESS
 *          ERROR_TYPE_FAIL
 */
int SetSensorSerialNumber(SENSOR_ID_E id, char* serialNumber, int length)
{
	if(id >= SENSOR_ID_MAX || length > MAX_LEN_SERIAL_NUMBER) {
		return ERROR_TYPE_FAIL;
	}
	(void)memset(mSensorConfiguration[id].mSerialNumber, 0,          MAX_LEN_SENSOR_NAME+1);
	(void)memcpy(mSensorConfiguration[id].mSerialNumber, serialNumber, length);

	return ERROR_TYPE_SUCCESS;
}

/**
 * @brief Get sensor serial number of sensor configuration
 * @param[in]   id             Target sendor id 
 * @return  Serial number string
 *          NULL 
 */
char* GetSensorSerialNumber(SENSOR_ID_E id)
{
	if(id >= SENSOR_ID_MAX) {
		return NULL;
	}
	return mSensorConfiguration[id].mSerialNumber;
}

/**
 * @brief Set sensor operation type of sensor configuration
 * @param[in]   id             Target sendor id 
 * @param[in]   operationType  Input sensor operation type enum value
 * @return  ERROR_TYPE_SUCCESS
 *          ERROR_TYPE_FAIL
 */
int SetSensorOperationType(SENSOR_ID_E id, SENSOR_OPERATION_TYPE_E operationType)
{
	if(id >= SENSOR_ID_MAX) {
		return ERROR_TYPE_FAIL;
	}
    mSensorConfiguration[id].mOperationType = operationType;

    return ERROR_TYPE_SUCCESS;
}

/**
 * @brief Get sensor operation type of sensor configuration
 * @param[in]   id             Target sendor id 
 * @return  SENSOR_TYPE_ACTIVE
 *          SENSOR_TYPE_PASSIVE
 *	        SENSOR_TYPE_MAX
 */
SENSOR_OPERATION_TYPE_E GetSensorOperationType(SENSOR_ID_E id)
{
	if(id >= SENSOR_ID_MAX) {
		return SENSOR_TYPE_MAX;
	}
	return mSensorConfiguration[id].mOperationType;
}

/**
 * @brief Set sensor start time of sensor configuration
 * @param[in]   id             Target sendor id 
 * @param[in]   startTime      Input sensor start time
 * @return  ERROR_TYPE_SUCCESS
 *          ERROR_TYPE_FAIL
 */
int SetSensorChangeStartTime(SENSOR_ID_E id, int startTime)
{
	if(id >= SENSOR_ID_MAX) {
		return ERROR_TYPE_FAIL;
	}
    mSensorConfiguration[id].mStartTime = startTime;

    return ERROR_TYPE_SUCCESS;
}

/**
 * @brief Get sensor start time of sensor configuration
 * @param[in]   id             Target sendor id 
 * @return  Start time
 *          0 (SENSOR ID ERROR)
 */
int GetSensorChangeStartTime(SENSOR_ID_E id)
{
	if(id >= SENSOR_ID_MAX) {
		return 0;
	}
	return mSensorConfiguration[id].mStartTime;
}

/**
 * @brief Set sensor end time of sensor configuration
 * @param[in]   id             Target sendor id 
 * @param[in]   endTime        Input sensor end time
 * @return  ERROR_TYPE_SUCCESS
 *          ERROR_TYPE_FAIL
 */
int SetSensorChangeEndTime(SENSOR_ID_E id, int endTime)
{
	if(id >= SENSOR_ID_MAX) {
		return ERROR_TYPE_FAIL;
	}
    mSensorConfiguration[id].mEndTime = endTime;

    return ERROR_TYPE_SUCCESS;
}

/**
 * @brief Get sensor end time of sensor configuration
 * @param[in]   id             Target sendor id 
 * @return  end time
 *          0 (SENSOR ID ERROR)
 */
int GetSensorChangeEndTime(SENSOR_ID_E id)
{
	if(id >= SENSOR_ID_MAX) {
		return 0;
	}
	return mSensorConfiguration[id].mEndTime;
}

/**
 * @brief Set sensor max interval of sensor configuration
 * @param[in]   id             Target sendor id 
 * @param[in]   maxInterval    Input sensor max interval
 * @return  ERROR_TYPE_SUCCESS
 *          ERROR_TYPE_FAIL
 */
int SetSensorMaxInterval(SENSOR_ID_E id, int maxInterval)
{
	if(id >= SENSOR_ID_MAX) {
		return ERROR_TYPE_FAIL;
	}
    mSensorConfiguration[id].mMaxInterval = maxInterval;

    return ERROR_TYPE_SUCCESS;
}

/**
 * @brief Get sensor max interval of sensor configuration
 * @param[in]   id             Target sendor id 
 * @return  end time
 *          0 (SENSOR ID ERROR)
 */
int GetSensorMaxInterval(SENSOR_ID_E id)
{
	if(id >= SENSOR_ID_MAX) {
		return 0;
	}
	return mSensorConfiguration[id].mMaxInterval;
}

/**
 * @brief Set sensor register flag of sensor configuration
 * @param[in]   id             Target sendor id 
 * @param[in]   register flag  Input sensor register flag
 * @return  ERROR_TYPE_SUCCESS
 *          ERROR_TYPE_FAIL
 */
int SetSensorRegisterFlag(SENSOR_ID_E id, bool registerFlag)
{
	if(id >= SENSOR_ID_MAX) {
		return ERROR_TYPE_FAIL;
	}
    mSensorConfiguration[id].mRegisterFlag = registerFlag;
    return ERROR_TYPE_SUCCESS;
}

/**
 * @brief Get sensor register flag of sensor configuration
 * @param[in]   id             Target sendor id 
 * @return  mRegisterFlag
 *          0 (SENSOR ID ERROR)
 */
bool GetSensorRegisterFlag(SENSOR_ID_E id)
{
	if(id >= SENSOR_ID_MAX) {
		return 0;
	}
	return mSensorConfiguration[id].mRegisterFlag;
}

/**
 * @brief Set sensor control type of sensor configuration
 * @param[in]   id             Target sendor id 
 * @param[in]   controlType    Input sensor control type enum value
 * @return  ERROR_TYPE_SUCCESS
 *          ERROR_TYPE_FAIL
 */
int SetSensorControlType(SENSOR_ID_E id, SENSOR_CONTROL_TYPE_E controlType)
{
	if(id >= SENSOR_ID_MAX) {
		return ERROR_TYPE_FAIL;
	}
    mSensorConfiguration[id].mControlType = controlType;

    return ERROR_TYPE_SUCCESS;
}

/**
 * @brief Get sensor control type of sensor configuration
 * @param[in]   id             Target sendor id 
 * @return  SENSOR_TYPE_ACTIVE
 *          SENSOR_TYPE_PASSIVE
 *	        SENSOR_TYPE_MAX
 */
SENSOR_CONTROL_TYPE_E GetSensorControlType(SENSOR_ID_E id)
{
	if(id >= SENSOR_ID_MAX) {
		return SENSOR_TYPE_MAX;
	}
	return mSensorConfiguration[id].mControlType;
}
