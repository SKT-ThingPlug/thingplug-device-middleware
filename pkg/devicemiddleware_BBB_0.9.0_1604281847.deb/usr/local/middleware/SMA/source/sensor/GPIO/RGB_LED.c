/**
 * @file RGB_LED.c
 *
 * @brief RGB_LED Sensor Device Handler
 *
 * Copyright (C) 2015. SPTek,All Rights Reserved.
 * Written 2015,by SPTek
 */
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <string.h>
#include "RGB_LED.h"
#include "Foundation.h"
#include "SensorHandler.h"

/*
 ****************************************
 * Definition & Global Variable
 ****************************************
 */
#define GPIO5_FILE_PATH      "/sys/class/gpio/gpio5/value"
#define GPIO49_FILE_PATH     "/sys/class/gpio/gpio49/value"
#define GPIO115_FILE_PATH    "/sys/class/gpio/gpio115/value"

#define ENABLE_GPIO_5        "echo 5 > /sys/class/gpio/export"
#define ENABLE_GPIO_49       "echo 49 > /sys/class/gpio/export"
#define ENABLE_GPIO_115      "echo 115 > /sys/class/gpio/export"

#define REDIRECTION_GPIO_5   "echo out > /sys/class/gpio/gpio5/direction"
#define REDIRECTION_GPIO_49  "echo out > /sys/class/gpio/gpio49/direction"
#define REDIRECTION_GPIO_115 "echo out > /sys/class/gpio/gpio115/direction"

FILE *gpio5_fp = NULL;
FILE *gpio49_fp = NULL;
FILE *gpio115_fp = NULL;

int gLedStatus = 0;

static char gDummyData[10][20] =
{"red","green","blue","magenta","cyan","yellow","white","off","blue","red"};

static int gIndex = 0;

/*
 ****************************************
 * RGB_LED device Main Handle Functions
 ****************************************
 */

char* RGB_LED_ON(char *commandArg)
{
	SPTekDebugLog(LOG_LEVEL_INFO, "[SMA] LED ON");
	gpio5_fp   = fopen(GPIO5_FILE_PATH  ,"w");
	if(gpio5_fp == NULL) {
		return "[FAIL]LED ON";
	}
	gpio49_fp  = fopen(GPIO49_FILE_PATH ,"w");
	if(gpio49_fp == NULL) {
		fclose(gpio5_fp);
		gpio5_fp  = NULL;
		return "[FAIL]LED ON";
	}
	gpio115_fp = fopen(GPIO115_FILE_PATH,"w");
	if(gpio115_fp == NULL) {
		fclose(gpio5_fp);
		fclose(gpio49_fp);
		gpio5_fp   = NULL;
		gpio49_fp  = NULL;
		return "[FAIL]LED ON";
	}
	
	fwrite("1", sizeof(char), 1, gpio5_fp);
	fwrite("1", sizeof(char), 1, gpio49_fp);
	fwrite("1", sizeof(char), 1, gpio115_fp);
	
	gLedStatus = 7;

	fclose(gpio5_fp);
	fclose(gpio49_fp);
	fclose(gpio115_fp);
	gpio5_fp   = NULL;
	gpio49_fp  = NULL;
	gpio115_fp = NULL;
	return "[SUCCESS]LED ON";
}
char* RGB_LED_OFF(char *commandArg)
{
	SPTekDebugLog(LOG_LEVEL_INFO, "[SMA] LED OFF");
	gpio5_fp   = fopen(GPIO5_FILE_PATH  ,"w");
	if(gpio5_fp == NULL) {
		return "[FAIL]LED ON";
	}
	gpio49_fp  = fopen(GPIO49_FILE_PATH ,"w");
	if(gpio49_fp == NULL) {
		fclose(gpio5_fp);
		gpio5_fp  = NULL;
		return "[FAIL]LED ON";
	}
	gpio115_fp = fopen(GPIO115_FILE_PATH,"w");
	if(gpio115_fp == NULL) {
		fclose(gpio5_fp);
		fclose(gpio49_fp);
		gpio5_fp   = NULL;
		gpio49_fp  = NULL;
		return "[FAIL]LED ON";
	}
	
	fwrite("0", sizeof(char), 1, gpio5_fp);
	fwrite("0", sizeof(char), 1, gpio49_fp);
	fwrite("0", sizeof(char), 1, gpio115_fp);
	
	gLedStatus = 0;

	fclose(gpio5_fp);
	fclose(gpio49_fp);
	fclose(gpio115_fp);
	gpio5_fp   = NULL;
	gpio49_fp  = NULL;
	gpio115_fp = NULL;
	return "[SUCCESS]LED OFF";
}
int RGB_Control(char *r, char *g, char *b, int status)
{
	SPTekDebugLog(LOG_LEVEL_INFO, "[SMA] LED SP1 CONTROL");
	gpio5_fp   = fopen(GPIO5_FILE_PATH  ,"w");
	if(gpio5_fp == NULL) {
		return -1;
	}
	gpio49_fp  = fopen(GPIO49_FILE_PATH ,"w");
	if(gpio49_fp == NULL) {
		fclose(gpio5_fp);
		gpio5_fp  = NULL;
		return -1;
	}
	gpio115_fp = fopen(GPIO115_FILE_PATH,"w");
	if(gpio115_fp == NULL) {
		fclose(gpio5_fp);
		fclose(gpio49_fp);
		gpio5_fp   = NULL;
		gpio49_fp  = NULL;
		return -1;
	}
	
	fwrite(r, sizeof(char), 1, gpio5_fp);
	fwrite(g, sizeof(char), 1, gpio49_fp);
	fwrite(b, sizeof(char), 1, gpio115_fp);
	
	gLedStatus = status;

	fclose(gpio5_fp);
	fclose(gpio49_fp);
	fclose(gpio115_fp);
	gpio5_fp   = NULL;
	gpio49_fp  = NULL;
	gpio115_fp = NULL;
	return 0;
}
/**
 * @brief RGB_LED device init function
 * @param[in] No parameter
 * @return	 0 => Success init
 * 		-1 => Error file open
 */
int RGB_LEDInit(void)
{
	system(ENABLE_GPIO_5);
	system(ENABLE_GPIO_49);
	system(ENABLE_GPIO_115);
	system(REDIRECTION_GPIO_5);
	system(REDIRECTION_GPIO_49);
	system(REDIRECTION_GPIO_115);

	RegisterSensorCommand(0x9f,"RGB_LED_ON",&RGB_LED_ON);
	RegisterSensorCommand(0x9d,"RGB_LED_OFF",&RGB_LED_OFF);
	RGB_LED_OFF(NULL);
	gLedStatus = 8;
	return 0;
}

/**
 * @brief RGB_LED device LED value read funciton
 * @param[in] data Control data
 * @param[in] len  Control data length
 * @return	 result Result string
 */
char* RGB_LEDControl(char *data, int len)
{
	char result[256];
	int  i = 0;
	int sep_cnt = 0;
	int start_id = -1;
	int end_id = -1;
	int start_idx = -1;
	int end_idx = -1;
	char cmd[8] = "";
	char id[126] = "";
	int ret = 0;

	while( i < len ) {
		if(data[i] == '\"') {
			sep_cnt++;
		}
		if(start_id == -1 && sep_cnt == 3) {
			start_id = i + 1;
		}
		if(end_id == -1 && sep_cnt == 4) {
			end_id = i - 1;
		}
		if(start_idx == -1 && sep_cnt == 7) {
			start_idx = i + 1;
		}
		if(end_idx == -1 && sep_cnt == 8) {
			end_idx = i - 1;
		}
		i++;
	}
	if( end_idx < 0 || start_idx < 0 ) {
		printf("parsing error\n");
		sprintf(result,"{\"id\": \"%s\", \"error\": {\"code\": -32000, \"message\":\"Command parsing error\"}}",id);
		return strdup(result);
	}
	if( end_id < 0 || start_id < 0 ) {
		printf("parsing error\n");
		sprintf(result,"{\"id\": \"%s\", \"error\": {\"code\": -32000, \"message\":\"Command parsing error\"}}",id);
		return strdup(result);
	}

	(void)memcpy(cmd,&data[start_idx],(end_idx - start_idx) + 1);
	(void)memcpy(id,&data[start_id],(end_id - start_id) + 1);

	if( strcmp(cmd,"red") == 0 ) {
		ret = RGB_Control("1","0","0",1);
	} else if(strcmp(cmd,"green") == 0) {
		ret = RGB_Control("0","1","0",2);
	} else if(strcmp(cmd,"blue") == 0) {
		ret = RGB_Control("0","0","1",3);
	} else if(strcmp(cmd,"magenta") == 0) {
		ret = RGB_Control("1","0","1",4);
	} else if(strcmp(cmd,"cyan") == 0) {
		ret = RGB_Control("0","1","1",5);
	} else if(strcmp(cmd,"yellow") == 0) {
		ret = RGB_Control("1","1","0",6);
	} else if(strcmp(cmd,"white") == 0) {
		ret = RGB_Control("1","1","1",7);
	} else if(strcmp(cmd,"off") == 0) {
		ret = RGB_Control("0","0","0",8);
	}

	if( ret == 0 ) {
		sprintf(result,"{\"id\": \"%s\", \"result\": \"%s\"}",id,cmd);
	} else {
		sprintf(result,"{\"id\": \"%s\", \"error\": {\"code\": -32000, \"message\":\"Device not found\"}}",id);
	}

	return strdup(result);
}

/**
 * @brief RGB_LED device LED value read funciton
 * @param[in] SPTekSENSOR_INFO_T structure member mLastValue pointer
 * @return	 0 => Success read data
 * 		-3 => Error read operation
 * 		-4 => Error lseek operation
 */
int RGB_LEDRead(char *data, int *len)
{
	//return dummy
	strcpy(data,gDummyData[gIndex]);
	*len = strlen(data);
	gIndex++;
	gIndex %= 10;
	return 0;
/*
	switch(gLedStatus){
		case 1:
			sprintf(data,"%s","red");
			*len = strlen(data);
			break;
		case 2:
			sprintf(data,"%s","green");
			*len = strlen(data);
			break;
		case 3:
			sprintf(data,"%s","blue");
			*len = strlen(data);
			break;
		case 4:
			sprintf(data,"%s","magenta");
			*len = strlen(data);
			break;
		case 5:
			sprintf(data,"%s","cyan");
			*len = strlen(data);
			break;
		case 6:
			sprintf(data,"%s","yellow");
			*len = strlen(data);
			break;
		case 7:
			sprintf(data,"%s","white");
			*len = strlen(data);
			break;
		case 8:
			sprintf(data,"%s","off");
			*len = strlen(data);
			break;
		default:
			sprintf(data,"%s","off");
			*len = strlen(data);
			break;
	}
	return 0;
	*/
}

/**
 * @brief RGB_LED device close funciton
 * @param[in] No parameter
 * @return 0 = default
 */
int RGB_LEDClose(void)
{
	return 0;
}

/**
 * @brief RGB_LED Extract LED value
 * @param[in] Raw Data
 * @return 0 = LED Value
 */
int getRGB_LEDValue(char *data)
{
	return 0;
}
