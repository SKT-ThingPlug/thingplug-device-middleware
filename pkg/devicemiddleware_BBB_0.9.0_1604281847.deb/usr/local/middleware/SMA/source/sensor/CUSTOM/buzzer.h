/*
 * @file buzzer.h
 *
 * @brief BUZZER Sensor handler header
 *
 * Copyright (C) 2015. SPTek,All Rights Reserved.
 * Written 2015,by SPTek
 */

#ifndef _BUZZER_H_
#define _BUZZER_H_

/*
 ****************************************
 * Enumerations
 ****************************************
 */


/*
 ****************************************
 * Major Functions
 ****************************************
 */

/**
 * @brief BUZZER device init function
 * @param[in] No parameter
 * @return	 0 => Success init
 * 		-1 => Error file open
 */
int BUZZERInit(void);

/**
 * @brief BUZZER device button value read funciton
 * @param[in] SPTekSENSOR_INFO_T structure member mLastValue pointer
 * @return	 0 => Success read data
 * 		-1 => Error ioctl operation
 * 		-2 => Error write operation
 * 		-3 => Error read operation
 */
int BUZZERRead(char *data, int *len);

/**
 * @brief BUZZER device close funciton
 * @param[in] No parameter
 * @return 0 = default
 */
int BUZZERClose(void);


#endif //_BUZZER_H_
