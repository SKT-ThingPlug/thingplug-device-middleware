/*
 * @file number.h
 *
 * @brief NUMBER Sensor handler header
 *
 * Copyright (C) 2015. SPTek,All Rights Reserved.
 * Written 2015,by SPTek
 */

#ifndef _NUMBER_H_
#define _NUMBER_H_

/*
 ****************************************
 * Enumerations
 ****************************************
 */


/*
 ****************************************
 * Major Functions
 ****************************************
 */

/**
 * @brief NUMBER device init function
 * @param[in] No parameter
 * @return	 0 => Success init
 * 		-1 => Error file open
 */
int NUMBERInit(void);

/**
 * @brief NUMBER device button value read funciton
 * @param[in] SPTekSENSOR_INFO_T structure member mLastValue pointer
 * @return	 0 => Success read data
 * 		-1 => Error ioctl operation
 * 		-2 => Error write operation
 * 		-3 => Error read operation
 */
int NUMBERRead(char *data, int *len);

/**
 * @brief NUMBER device close funciton
 * @param[in] No parameter
 * @return 0 = default
 */
int NUMBERClose(void);


#endif //_NUMBER_H_
