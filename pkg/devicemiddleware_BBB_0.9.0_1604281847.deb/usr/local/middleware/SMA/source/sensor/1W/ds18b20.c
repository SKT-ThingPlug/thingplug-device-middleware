/**
 * @file ds18b20.c
 *
 * @brief Temperature Sensor Device Handler
 *
 * Copyright (C) 2015. SPTek,All Rights Reserved.
 * Written 2015,by SPTek 
 */
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <string.h>
#include "ds18b20.h"
#include "Foundation.h"

/*
 **************************************** 
 * Definition & Global Variable
 **************************************** 
 */
#define BUFF_SIZE  128
#define MASTER_FILENAME  "cat /sys/bus/w1/devices/w1_bus_master1/w1_master_slaves"

static int gDS18B20Fd = -1;
char slavePath[256];
int getTemperatureValue(char *data);
int DS18B20FileOpen(void);
int DS18B20FileClose(void);


static char gDummyData[10][20] =
{"20.1","20.2","20.3","20.4","20.5","20.1","20.3","20.0","20.1","20.1"};
static int gIndex = 0;

/*
 **************************************** 
 * DS18B20 device Main Handle Functions 
 **************************************** 
 */

/**
 * @brief DS18B20 device init function
 * @param[in] No parameter
 * @return	 0 => Success init
 * 		-1 => Error file open 
 */
int DS18B20Init(void)
{
	return 0;
/*
	FILE *gW1MasterFd;
	char slaveName[256];
	int ret = 0;
	gW1MasterFd = popen(MASTER_FILENAME, "r");
	if(gW1MasterFd == NULL) { 	
		return -1;
	}
	(void)memset(slaveName,0,256);
	fgets(slaveName,255,gW1MasterFd);
	slaveName[strlen(slaveName)-1] = '\0';
	sprintf(slavePath,"/sys/bus/w1/devices/");
	strcat(slavePath,slaveName);
	strcat(slavePath,"/w1_slave");
	fclose(gW1MasterFd);

	return ret;
	*/
}

/**
 * @brief DS18B20 device temperature value read funciton
 * @param[in] SPTekSENSOR_INFO_T structure member mLastValue pointer
 * @return	 0 => Success read data
 * 		-3 => Error read operation 
 * 		-4 => Error lseek operation 
 */
int DS18B20Read(char *data, int *len)
{
	//dummy sensor data
	strcpy(data,gDummyData[gIndex]);
	*len = strlen(data);
	gIndex++;
	gIndex %= 10;
	return 0;
	/*
	float value;
	int  readByte = 0;
	int  ret      = 0;
	char buf[BUFF_SIZE];

	memset(buf, 0, BUFF_SIZE);
	DS18B20Init();

	ret = DS18B20FileOpen();

	if(ret < 0 || gDS18B20Fd < 0) {
		sprintf(data,"N/A:OPEN");
		*len = strlen(data);
		return 0;
	}

	readByte = read(gDS18B20Fd, buf, BUFF_SIZE);
	if(readByte <= 0) {
		sprintf(data,"N/A:READ");
		*len = strlen(data);
		DS18B20FileClose();
		return 0;
	}

	lseek(gDS18B20Fd, 0, SEEK_SET);

	value = (float)getTemperatureValue(buf);
	value = value / 1000;

	sprintf(data,"%.3f",value);
	if( data[0] == '0' && data[1] == '.' && data[2] =='0' && data[3] == '0') {
		sprintf(data,"N/A:ERROR");
	}

	*len = strlen(data);

	DS18B20FileClose();

	return 0;
	*/
}

/**
 * @brief DS18B20 device close funciton
 * @param[in] No parameter
 * @return 0 = default
 */
int DS18B20Close(void)
{
	return 0;
}


/**
 * @brief DS18B20 Extract temperature value
 * @param[in] Raw Data 
 * @return 0 = Temperature Value
 */
int DS18B20FileOpen(void)
{
	gDS18B20Fd = open(slavePath,O_RDONLY, S_IREAD);
	if(gDS18B20Fd < 0 ) { 	
		return -1;
	}
	return 0;
}

int DS18B20FileClose(void)
{
	if(gDS18B20Fd < 0 ) { 	
		return -1;
	}
	close(gDS18B20Fd);
	gDS18B20Fd = -1;
	return 0;
}




/**
 * @brief DS18B20 Extract temperature value
 * @param[in] Raw Data 
 * @return 0 = Temperature Value
 */
int getTemperatureValue(char *data)
{
	int value = 0;
	if(data == NULL) {
		return 0;
	}
	char *ptr;
	//Extract temperature value
	ptr = strtok(data,"=");
	ptr = strtok(NULL,"=");
	ptr = strtok(NULL,"=");
	value = atoi(ptr);
	return value;
}






