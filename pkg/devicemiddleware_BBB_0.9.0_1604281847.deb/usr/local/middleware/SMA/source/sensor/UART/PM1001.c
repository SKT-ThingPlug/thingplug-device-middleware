/**
 * @file PM1001.c
 *
 * @brief PM1001 Dust Sensor Device Handler
 *
 * Copyright (C) 2015. SPTek,All Rights Reserved.
 * Written 2015,by SPTek
 */
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <string.h>
#include <termios.h>
#include "PM1001.h"

/*
 ****************************************
 * Definition & Global Variable
 ****************************************
 */

#define UART5_ENABLE "echo BB-UART5 > /sys/devices/bone_capemgr.9/slots"

static int gPM1001Fd = -1;


/*
 ****************************************
 * PM1001 device Main Handle Functions
 ****************************************
 */

/**
 * @brief PM1001 device init function
 * @param[in] No parameter
 * @return	 0 => Success init
 * 		-1 => Error file open
 */
int PM1001Init(void)
{
	system(UART5_ENABLE);
	return 0;
}

/**
 * @brief PM1001 device Dust value read funciton
 * @param[in] SPTekSENSOR_INFO_T structure member mLastValue pointer
 * @return	 0 => Success read data
 * 		-3 => Error read operation
 * 		-4 => Error lseek operation
 */
int PM1001Read(char *data, int *len)
{
	char Tx_Data;
	char Rx_Data;
	struct termios tio;
	int i = 0;
	int udet = 200;
	int readbytes = 0;
	int writebytes = 0;
	char cs = 0;
	int val = 0;
	int retry_cnt = 0;

	memset(&tio,0,sizeof(tio));
	tio.c_iflag=0;
	tio.c_oflag=0;
	tio.c_cflag=CS8|CREAD|CLOCAL;
	tio.c_lflag=0;
	tio.c_cc[VMIN]=1;
	tio.c_cc[VTIME]=0;

	gPM1001Fd=open("/dev/ttyO5",O_RDWR|O_NONBLOCK);      
	if(gPM1001Fd < 0) {
		sprintf(data,"N/A:OPEN");
		*len = strlen(data);
		return 0;
	}
	cfsetospeed(&tio,B9600);
	tcsetattr(gPM1001Fd,TCSANOW,&tio);

	Tx_Data = 0x11;
	writebytes = 0;
	writebytes = write(gPM1001Fd,&Tx_Data,1);
	while(writebytes <= 0) {
		sprintf(data,"N/A:WRITE");
		*len = strlen(data);
		close(gPM1001Fd);
		gPM1001Fd = -1;
		return 0;
	}
	usleep(udet);
	Tx_Data = 0x01;
	writebytes = 0;
	writebytes = write(gPM1001Fd,&Tx_Data,1);
	while(writebytes <= 0) {
		sprintf(data,"N/A:WRITE");
		*len = strlen(data);
		close(gPM1001Fd);
		gPM1001Fd = -1;
		return 0;
	}
	usleep(udet);
	Tx_Data = 0x01;
	writebytes = 0;
	writebytes = write(gPM1001Fd,&Tx_Data,1);
	while(writebytes <= 0) {
		sprintf(data,"N/A:WRITE");
		*len = strlen(data);
		close(gPM1001Fd);
		gPM1001Fd = -1;
		return 0;
	}
	usleep(udet);
	Tx_Data = 0xED;
	writebytes = 0;
	writebytes = write(gPM1001Fd,&Tx_Data,1);
	while(writebytes <= 0) {
		sprintf(data,"N/A:WRITE");
		*len = strlen(data);
		close(gPM1001Fd);
		gPM1001Fd = -1;
		return 0;
	}
	usleep(udet);

	int loop_cnt = 12;
	int mode = 1; //co2

	for(i = 0;i < loop_cnt; i++) {
		Rx_Data = 0x00;
		readbytes = read(gPM1001Fd,&Rx_Data,1);
		if(readbytes > 0) {
			if( i == 0 && Rx_Data != 0x16 ) {
				sprintf(data,"N/A:ERROR");
				*len = strlen(data);
				close(gPM1001Fd);
				gPM1001Fd = -1;
				return 0;
			}
			if(i == 1 && (Rx_Data != 0x09 && Rx_Data != 0x0D) ) {
				sprintf(data,"N/A:ERROR");
				*len = strlen(data);
				close(gPM1001Fd);
				gPM1001Fd = -1;
				return 0;
			}
			if(i == 1 && Rx_Data == 0x0D){
				loop_cnt = 16;
				mode = 2;//dust
			}
			if(i != 11)cs += Rx_Data;
			if(mode == 1){
				if(i == 3) {
					val = (Rx_Data << 8);
				}
				if(i == 4) {
					val += Rx_Data;
				}
			} else if(mode == 2) {
				if(i == 3) {
					val = (Rx_Data << 24);
				} else if(i == 4) {
					val = (Rx_Data << 16);
				} else if(i == 5) {
					val = (Rx_Data << 8);
				}
				if(i == 6) {
					val += Rx_Data;
				}
			}
		} else {
			if(retry_cnt == 1000) {
				sprintf(data,"N/A:ERROR");
				*len = strlen(data);
				close(gPM1001Fd);
				gPM1001Fd = -1;
				return 0;
			}
			retry_cnt++;
			i--;
			usleep(udet);
		}
	}

	sprintf(data,"%d",val);
	*len = strlen(data);
	close(gPM1001Fd);
	gPM1001Fd = -1;
	return 0;
}

/**
 * @brief PM1001 device close funciton
 * @param[in] No parameter
 * @return 0 = default
 */
int PM1001Close(void)
{
	return 0;
}

