/**
 * @file SensorCommandList.h
 *
 * @brief Sensor command list container manager header
 *
 * Copyright (C) 2015. SPTek,All Rights Reserved.
 * Written 2015,by SPTek
 */

#ifndef __SENSOR_COMMAND_LIST_H__
#define __SENSOR_COMMAND_LIST_H__

/*
 ****************************************
 * Definitions
 ****************************************
 */

/*
 ****************************************
 * Enumerations
 ****************************************
 */

/*
 ****************************************
 * Structures
 ****************************************
 */

typedef struct tagCommandNode {
	char   	mCommandTag;
    char   *mCommandName;
	int     mNameLength;
    char* (*mCommandFunction)(char *);
    struct tagCommandNode   *mNextNode;
}COMMAND_NODE_T;

typedef struct tagCommandLIST {
	int         mCount;
    int         mLengths;
    COMMAND_NODE_T *mHead;
}COMMAND_LIST_T;

/*
 ****************************************
 * Public Functions
 ****************************************
 */

void SensorCommandListInit(COMMAND_LIST_T *list);
int SensorCommandListInsertNode(COMMAND_LIST_T *list, char commandTag, char *commandName, int nameLength, char* (*commandFunction)(char*), int position);
int SensorCommandListAddNode(COMMAND_LIST_T *list, char commandTag, char *commandName, int nameLength, char* (*commandFunction)(char*));
COMMAND_NODE_T* SensorCommandListGetPositionNode(COMMAND_LIST_T* list, int position);
COMMAND_NODE_T* SensorCommandListGetNameNode(COMMAND_LIST_T* list, char *commandName);
COMMAND_NODE_T* SensorCommandListGetTagNode(COMMAND_LIST_T* list, char commandTag);
int SensorCommandListDeleteNode(COMMAND_LIST_T *list, char *commandName);
int SensorCommandListDeleteTagNode(COMMAND_LIST_T *list, char commandTag);
void SensorCommandListDeleteAllNode(COMMAND_LIST_T *list);
void SensorCommandListPrintNode(COMMAND_LIST_T *list);

#endif /* __SENSOR_COMMAND_LIST_H__ */

