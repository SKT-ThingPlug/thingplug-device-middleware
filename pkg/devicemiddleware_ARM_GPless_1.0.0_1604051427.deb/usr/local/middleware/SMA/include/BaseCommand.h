/**
 * @file BaseCommand.h
 *
 * @brief Base functions for command processing header
 *
 * Copyright (C) 2015. SPTek,All Rights Reserved.
 * Written 2015,by SPTek
 */

#ifndef __BASE_COMMAND_H__
#define __BASE_COMMAND_H__

#include "DataComposition.h"

/*
 ****************************************
 * Definitions
 ****************************************
 */

#define SOURCE_LENGTHS      16
#define DESTINATION_LENGTHS 16
#define REQUEST_LENGTHS     4
#define CONTENTS_LENGTHS    4
#define RESERVED_LENGTHS    8

#define SPTekMESSAGE_HEADER_SIZE (SOURCE_LENGTHS + DESTINATION_LENGTHS + REQUEST_LENGTHS + CONTENTS_LENGTHS + RESERVED_LENGTHS)

/*
 ****************************************
 * Enumerations
 ****************************************
 */

///
typedef enum tagSource {
	SOURCE_NONE = 0,
	SOURCE_SRA,
	SOURCE_MAX
}SPTekSOURCE_E;

///
typedef enum tagDestination {
	DESTINATION_NONE = 0,
	DESTINATION_SRA,
	DESTINATION_MAX
}SPTekDESTINATION_E;

///
typedef enum tagCommand {
	SPTekCOMMANDTYPE_NONE                   	     = 0,
	SPTekCOMMANDTYPE_GET_DEVICE_SENSOR_INFO 	     = 1101,
	SPTekCOMMANDTYPE_GET_DEVICE_SENSOR_STATUS 	     = 1102,
	SPTekCOMMANDTYPE_UPDATE_DEVICE_SENSOR_STATUS 	 = 1103,
	SPTekCOMMANDTYPE_GET_DEVICE_SENSOR_CMD_LIST      = 1104,
	SPTekCOMMANDTYPE_DEVICE_SENSOR_CMD               = 1105,
	SPTekCOMMANDTYPE_PROCESS_EXIT                    = 1106,
	SPTekCOMMANDTYPE_DEVICE_SENSOR_CONTROL           = 1108,
	SPTekCOMMANDTYPE_GET_DEVICE_SENSOR_BYTE_CMD_LIST = 1121,
	SPTekCOMMANDTYPE_DEVICE_SENSOR_BYTE_CMD          = 1122,
	SPTekCOMMANDTYPE_SET_TRACE_STATUS                = 1061,
	SPTekCOMMANDTYPE_MAX
}SPTekCOMMAND_E;

/*
 ****************************************
 * Structures
 ****************************************
 */

typedef struct tagMessageHeader {
	char mDestination[DESTINATION_LENGTHS];
	char mSource[SOURCE_LENGTHS];
	char mRequest[REQUEST_LENGTHS];
	char mReserved[RESERVED_LENGTHS];
	char mContentsLength[CONTENTS_LENGTHS];
}SPTekMESSAGE_HEADER_T;

typedef struct tagReceiveMessage {
	SPTekMESSAGE_HEADER_T mHeader;
	SPTekLIST_T           *extractList;
}SPTekRECEIVE_MESSAGE_T;

typedef struct tagSendMessage {
	int  mLength;
	char *message;
}SPTekSEND_MESSAGE_T;

/*
 ****************************************
 * Public Functions
 ****************************************
 */

SPTekSOURCE_E GetSourceType(char *source);
char* GetSourceString(void);
char* GetDestination(SPTekDESTINATION_E index);
int ExtractMessageHeader(char* message, int length, SPTekMESSAGE_HEADER_T *header);
int ExtractArray(char* contents, int contentsLength, SPTekITEM_LIST_T *itemList);
int ExtractContents(char* contents, int contentsLength, SPTekLIST_T *extract);
int MakeCommandHeaderMessage(SPTekDESTINATION_E index, int lengths, char *request, SPTekSEND_MESSAGE_T *sendMessage);
int MakeCommandConentsArray(SPTekITEM_LIST_T *itemList, char* content, unsigned short *length);
int MakeCommandConentsMessage(SPTekLIST_T *extractList, char* content, int *length);


#endif // __BASE_COMMAND_H__

