/**
 * @file SensorConfiguration.h
 *
 * @brief Sensor configuration & operation functions header
 *
 * Copyright (C) 2015. SPTek,All Rights Reserved.
 * Written 2015,by SPTek
 */

#ifndef __SENSOR_CONFIGURATION_H__
#define __SENSOR_CONFIGURATION_H__

#include <stdbool.h>

/*
 ****************************************
 * Definitions
 ****************************************
 */
#define MAX_LEN_DEVICE_ID   32
#define MAX_LEN_SENSOR_ID   32
#define MAX_LEN_SENSOR_NAME 64
#define MAX_LEN_SENSOR_TYPE  32
#define MAX_LEN_SERIAL_NUMBER 64
#define MAX_LEN_LAST_VALUE 128

/*
 ****************************************
 * Enumerations
 ****************************************
 */

/// Possible Device List
typedef enum tagSensorID
{
	SENSOR_ID_FIRST = 0,
	SENSOR_ID_MOTION_DETECT = SENSOR_ID_FIRST,
	SENSOR_ID_TEMPERATURE,
	SENSOR_ID_LIGHT,
	SENSOR_ID_HUMIDITY,
	SENSOR_ID_ONOFF,
	SENSOR_ID_NOISE,
	SENSOR_ID_DUST,
	SENSOR_ID_CO2,
	SENSOR_ID_DOOR,
	SENSOR_ID_LED,
	SENSOR_ID_BUZZER,
	SENSOR_ID_PRESSURE,
	SENSOR_ID_WINDVANE,
	SENSOR_ID_PH,
	SENSOR_ID_PERCENT,
	SENSOR_ID_COMPLEX,
	SENSOR_ID_STRING,
	SENSOR_ID_NUMBER,
	SENSOR_ID_CUSTOM_DEFINE,
	SENSOR_ID_UNDEFINED_SENSOR,
	SENSOR_ID_MAX
}SENSOR_ID_E;

/// Device Enable/Disable Flag
typedef enum tagSensorState
{
	SENSOR_STATE_DISABLE = 0,
	SENSOR_STATE_ENABLE,
	SENSOR_STATE_MAX
}SENSOR_STATE_E;

/// Device Reading Mode List
typedef enum tagSensorMode
{
	SENSOR_MODE_POLLING = 0,
	SENSOR_MODE_REQUEST,
	SENSOR_MODE_EVENT,
	SENSOR_MODE_MAX
}SENSOR_MODE_E;

/// Device Operation Type List
typedef enum tagSensorOperationType
{
	SENSOR_ACTIVE_TYPE  = 0x0001,
	SENSOR_PASSIVE_TYPE = 0x0002,
	SENSOR_TYPE_MAX
}SENSOR_OPERATION_TYPE_E;


/// TraceStatus 
typedef enum tagTraceStatus
{
	SENSOR_TRACE_ON         = 0x0001,
	SENSOR_TRACE_OFF        = 0x0002,
	SENSOR_TRACE_MAX     
}SENSOR_TRACE_STATUS_E;

/// Sensor Control Type
typedef enum tagSensorControlType
{
	SENSOR_CONTROL_TYPE     = 0x0001,
	SENSOR_NO_CONTROL_TYPE  = 0x0002,
}SENSOR_CONTROL_TYPE_E;

/// Result state
typedef enum tagResultState
{
	COMMAND_RESULT_SUCCESS              = 0x0001,
	COMMAND_RESULT_FAIL                 = 0x0002,
	COMMAND_RESULT_NO_SENSOR            = 0x0003,
	COMMAND_RESULT_NO_CMD               = 0x0004,
	COMMAND_RESULT_ALEADY_REGISTERED    = 0x0005,
	COMMAND_RESULT_OTHER_REGISTERED     = 0x0006,
	COMMAND_RESULT_STATE_MAX
}COMMAND_RESULT_STATE_E;

/*
 ****************************************
 * Structures
 ****************************************
 */

// Sensor information Structure
typedef struct tagSensorConfiguration {
	char                         mDeviceID[MAX_LEN_DEVICE_ID+1];
	char                         mSensorID[MAX_LEN_SENSOR_ID+1];
	char                         mSensorName[MAX_LEN_SENSOR_NAME+1];
	char                         mSensorType[MAX_LEN_SENSOR_TYPE+1];
	SENSOR_STATE_E               mState;
	unsigned int                 mReadInterval;
	SENSOR_MODE_E                mReadMode;
	char                         mLastValue[MAX_LEN_LAST_VALUE+1];
	int                          mStartTime;
	int                          mEndTime;
	char                         mSerialNumber[MAX_LEN_SERIAL_NUMBER+1];
	SENSOR_OPERATION_TYPE_E      mOperationType;
	int                          mMaxInterval;
	SENSOR_CONTROL_TYPE_E        mControlType;
	bool                         mRegisterFlag;
}SENSOR_CONFIGURATION_T;

/*
 ****************************************
 * Public Functions
 ****************************************
 */

void GetBackupSensorInformation(SENSOR_ID_E id, char *buf);
int GetSensorConfiguration(SENSOR_ID_E id, SENSOR_CONFIGURATION_T *configuration);
int SetSensorDeviceId(SENSOR_ID_E id, char* deviceId, int length);
char* GetSensorDeviceId(SENSOR_ID_E id);
int SetSensorSensorId(SENSOR_ID_E id, char* sensorId, int length);
char* GetSensorSensorId(SENSOR_ID_E id);
int SetSensorSensorName(SENSOR_ID_E id, char* sensorName, int length);
char* GetSensorSensorName(SENSOR_ID_E id);
int SetSensorSensorType(SENSOR_ID_E id, char* sensorType, int length);
char* GetSensorSensorType(SENSOR_ID_E id);
int SetSensorState(SENSOR_ID_E id, SENSOR_STATE_E state);
SENSOR_STATE_E GetSensorState(SENSOR_ID_E id);
int SetSensorReadInterval(SENSOR_ID_E id, unsigned int interval);
unsigned int GetSensorReadInterval(SENSOR_ID_E id);
int SetSensorReadMode(SENSOR_ID_E id, SENSOR_MODE_E readMode);
SENSOR_MODE_E GetSensorReadMode(SENSOR_ID_E id);
int SetLastValue(SENSOR_ID_E id, char *lastValue, int length);
char* GetLastValue(SENSOR_ID_E id);
int SetSensorSerialNumber(SENSOR_ID_E id, char* serialNumber, int length);
char* GetSensorSerialNumber(SENSOR_ID_E id);
int SetSensorOperationType(SENSOR_ID_E id, SENSOR_OPERATION_TYPE_E operationType);
SENSOR_OPERATION_TYPE_E GetSensorOperationType(SENSOR_ID_E id);
int SetSensorChangeStartTime(SENSOR_ID_E id, int startTime);
int GetSensorChangeStartTime(SENSOR_ID_E id);
int SetSensorChangeEndTime(SENSOR_ID_E id, int endTime);
int GetSensorChangeEndTime(SENSOR_ID_E id);
int SetSensorMaxInterval(SENSOR_ID_E id, int maxInterval);
int GetSensorMaxInterval(SENSOR_ID_E id);
int SetSensorRegisterFlag(SENSOR_ID_E id, bool registerFlag);
bool GetSensorRegisterFlag(SENSOR_ID_E id);
int SetSensorControlType(SENSOR_ID_E id, SENSOR_CONTROL_TYPE_E controlType);
SENSOR_CONTROL_TYPE_E GetSensorControlType(SENSOR_ID_E id);

#endif // __SENSOR_CONFIGURATION_H__

