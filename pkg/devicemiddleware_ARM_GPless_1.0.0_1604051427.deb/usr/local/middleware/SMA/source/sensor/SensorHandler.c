/**
 * @file SensorHandler.c
 *
 * @brief Sensor handler
 *
 * Copyright (C) 2015. SPTek,All Rights Reserved.
 * Written 2015,by SPTek 
 */

#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <stdbool.h>
#include <assert.h>
#include <stddef.h>
#include <pthread.h>

#include "zmq.h"
#include "zmq_utils.h"
#include "Foundation.h"
#include "SensorHandler.h"
#include "UpdateDeviceSensorStatus.h"
#include "SensorCommandList.h"

/**
 **************************************** 
 * Include - Device header , Compile Option : -I$(Sensor Folder) 
 **************************************** 
 */
#include "CUSTOM/buzzer.h"
#include "UART/CM1101.h"
#include "CUSTOM/complex.h"
#include "CUSTOM/custom.h"
#include "GPIO/MC38.h"
#include "UART/PM1001.h"
#include "I2C/htu21d.h"
#include "GPIO/RGB_LED.h"
#include "I2C/bh1750.h"
#include "GPIO/HC_SR501.h"
#include "GPIO/TCACB_147.h"
#include "CUSTOM/number.h"
#include "GPIO/BUT001.h"
#include "CUSTOM/percent.h"
#include "CUSTOM/ph.h"
#include "CUSTOM/pressure.h"
#include "CUSTOM/string.h"
#include "1W/ds18b20.h"
#include "UNDEFINED/undefine.h"
#include "CUSTOM/windvane.h"


/*
 **************************************** 
 * Definitions * Global Valiable
 **************************************** 
 */
#define ALARM_INTERVAL 1 //(sec)
#define PRINT_INTERVAL 5 //(sec)

#define MAX_DEVICE_NUMBER 4096

COMMAND_LIST_T gSensorCommandList;

/*
 **************************************** 
 * Private Functions
 **************************************** 
 */

/**
 * @brief Read handler each device
 * @param[in] signalnum Signal number
 * @return Void
 */
void SensorReadHandler(int signalnum)
{
	static int       timeValue  = 0;
	int              retValue   = 0;
	int              dataLength = 0;
	SENSOR_ID_E      id         = SENSOR_ID_FIRST;
	char             data[MAX_LEN_LAST_VALUE+1] = "";
	
	for(id = SENSOR_ID_FIRST; id<SENSOR_ID_MAX; id++) {
		if(!GetSensorRegisterFlag(id)){
			continue;
		}
		(void)memset(data, 0, MAX_LEN_LAST_VALUE+1);
		if(timeValue % GetSensorReadInterval(id) == 0) {
			switch(id) {
				case SENSOR_ID_MOTION_DETECT: {
					retValue = HC_SR501Read(data, &dataLength);
				}
				break;

				case SENSOR_ID_TEMPERATURE: {
					retValue = DS18B20Read(data, &dataLength);
				}
				break;

				case SENSOR_ID_LIGHT: {
					retValue = BH1750Read (data, &dataLength);
				}
				break;

				case SENSOR_ID_HUMIDITY: {
					retValue = HTU21DRead(data, &dataLength);
				}
				break;

				case SENSOR_ID_ONOFF: {
					retValue = BUT001Read(data, &dataLength);
				}
				break;

				case SENSOR_ID_NOISE: {
					retValue = TCACB_147Read(data, &dataLength);
				}
				break;

				case SENSOR_ID_DUST: {
					retValue = PM1001Read(data, &dataLength);
				}
				break;

				case SENSOR_ID_CO2: {
					retValue = CM1101Read(data, &dataLength);
				}
				break;

				case SENSOR_ID_DOOR: {
					retValue = MC38Read(data, &dataLength);
				}
				break;

				case SENSOR_ID_LED: {
					retValue = RGB_LEDRead(data, &dataLength);
				}
				break;

				case SENSOR_ID_BUZZER : {
					retValue = BUZZERRead(data, &dataLength);
				}
				break;

				case SENSOR_ID_PRESSURE : {
					retValue = PRESSURERead(data, &dataLength);
				}
				break;

				case SENSOR_ID_WINDVANE : {
					retValue = WINDVANERead(data, &dataLength);
				}
				break;

				case SENSOR_ID_PH : {
					retValue = PHRead(data, &dataLength);
				}
				break;

				case SENSOR_ID_PERCENT : {
					retValue = PERCENTRead(data, &dataLength);
				}
				break;

				case SENSOR_ID_COMPLEX : {
					retValue = COMPLEXRead(data, &dataLength);
				}
				break;

				case SENSOR_ID_STRING : {
					retValue = STRINGRead(data, &dataLength);
				}
				break;

				case SENSOR_ID_NUMBER : {
					retValue = NUMBERRead(data, &dataLength);
				}
				break;

				case SENSOR_ID_CUSTOM_DEFINE: {
					retValue = CUSTOMRead(data, &dataLength);
				}
				break;

				case SENSOR_ID_UNDEFINED_SENSOR: {
					retValue = UNDEFINERead(data, &dataLength);
				}
				break;

				default: {
					SPTekDebugLog(LOG_LEVEL_INFO,"Data Read ERROR : Unkown Sensor!!");
				}
				break;
			} 

			UpdateDeviceSensorStatus(id, data, dataLength);

			time_t now;
			time(&now);
			if(retValue >= 0 || strlen(data) != 0) {
				char *lastValue;
				lastValue = GetLastValue(id);
				if(strncmp(data, lastValue, strlen(lastValue)) != 0) {
					SetSensorChangeStartTime(id, now);
					SetSensorChangeEndTime(id, now);
				}
				else{
					SetSensorChangeEndTime(id, now);
				}
				if( strncmp(data,"N/A",strlen("N/A")) == 0 ) {
					SPTekDebugLog(LOG_LEVEL_INFO,"[N/A log] <%s>",data);
					data[strlen("N/A")] = '\0';
					dataLength = strlen("N/A");
					SetLastValue(id , data, dataLength);
				} else {
					SetLastValue(id , data, dataLength);
				}
			}
		} 
	}


	// Debugging Code : Print Sensor Name & Lastest Data
	if(timeValue % PRINT_INTERVAL == 0) {
		char printBuf[2048] = "\t[";
		int pos = 2;
		int nameSize = 20;
		for(id = SENSOR_ID_FIRST; id<SENSOR_ID_MAX; id++) {
			if(!GetSensorRegisterFlag(id)) {
				continue;
			}
			(void)memcpy(&printBuf[pos],GetSensorSensorName(id),strlen(GetSensorSensorName(id)));
			pos += strlen(GetSensorSensorName(id));
			nameSize -= strlen(GetSensorSensorName(id));
			while(nameSize!=0){
				printBuf[pos] = ' ';
				pos++;
				nameSize--;
			}
			nameSize = 20;
			if(GetSensorState(id) == 0) {
				(void)memcpy(&printBuf[pos],"<off>",strlen("<off>"));
				pos = pos + strlen("<off>");
			} else {
				(void)memcpy(&printBuf[pos],"<on> ",strlen("<on> "));
				pos = pos + strlen("<on> ");
			}
			(void)memcpy(&printBuf[pos],":\t",strlen(":\t"));
			pos += strlen(":\t");
			(void)memcpy(&printBuf[pos],GetLastValue(id),strlen(GetLastValue(id)));
			pos += strlen(GetLastValue(id));
			printBuf[pos] = ']';
			pos++;
			printBuf[pos] = '\n';
			pos++;
			printBuf[pos] = '\t';
			pos++;
			printBuf[pos] = '[';
			pos++;
		}
		pos--;
		printBuf[pos] = '\0';
		SPTekDebugLog(LOG_LEVEL_INFO,"[READ SENSOR VALUE]\n%s",printBuf);
	}

	timeValue++;
	if(timeValue == 7200) {
		timeValue = 0;
	}
	alarm(ALARM_INTERVAL);
}

/**
 * @brief Init signal handler
 * @return Void
 */
void SignalConfiguration(void)
{
	struct sigaction sigAction;
	sigAction.sa_handler = SensorReadHandler;
	sigemptyset(&sigAction.sa_mask);	
	sigAction.sa_flags = 0;
	sigaction(SIGALRM, &sigAction, 0);
	alarm(ALARM_INTERVAL);
}

/**
 * @brief Init Enable Device.
 * @return Void
 * @detail Deivce Detect & Device File Open
 */
void InitEnableDevice(void)
{
	time_t now;
	SENSOR_ID_E id = SENSOR_ID_FIRST;
	time(&now);
	for(id = SENSOR_ID_FIRST; id < SENSOR_ID_MAX; id++) {
		SetSensorChangeStartTime(id,(int)now);
		SetSensorChangeEndTime(id,(int)now);
		if(!GetSensorRegisterFlag(id)){
			continue;
		}
		switch(id) {
			case SENSOR_ID_MOTION_DETECT: {
				HC_SR501Init();
			}
			break;

			case SENSOR_ID_TEMPERATURE: {
				DS18B20Init();
			}
			break;

			case SENSOR_ID_LIGHT: {
				BH1750Init();
			}
			break;

			case SENSOR_ID_HUMIDITY: {
				HTU21DInit();
			}
			break;

			case SENSOR_ID_ONOFF: {
				BUT001Init();
			}
			break;

			case SENSOR_ID_NOISE: {
				TCACB_147Init();
			}
			break;

			case SENSOR_ID_DUST: {
				PM1001Init();
			}
			break;

			case SENSOR_ID_CO2: {
				CM1101Init();
			}
			break;

			case SENSOR_ID_DOOR: {
				MC38Init();
			}
			break;

			case SENSOR_ID_LED: {
				RGB_LEDInit();
			}
			break;

			case SENSOR_ID_BUZZER : {
				BUZZERInit();
			}
			break;

			case SENSOR_ID_PRESSURE : {
				PRESSUREInit();
			}
			break;

			case SENSOR_ID_WINDVANE : {
				WINDVANEInit();
			}
			break;

			case SENSOR_ID_PH : {
				PHInit();
			}
			break;

			case SENSOR_ID_PERCENT : {
				PERCENTInit();
			}
			break;

			case SENSOR_ID_COMPLEX : {
				COMPLEXInit();
			}
			break;

			case SENSOR_ID_STRING : {
				STRINGInit();
			}
			break;

			case SENSOR_ID_NUMBER : {
				NUMBERInit();
			}
			break;

			case SENSOR_ID_CUSTOM_DEFINE: {
				CUSTOMInit();
			}
			break;

			case SENSOR_ID_UNDEFINED_SENSOR: {
				UNDEFINEInit();
			}
			break;

			default: {
				;
			}
			break;
		}
	}
}


/**
 * @brief Load configuration to each device. 
 * @return Void
 * @detail Backup file name is SMADevice.back 
 * 	   file contents : Device Type,Device Name,Enable Flag,Read Interval,Read Mode,Last Value
 */
void LoadDeviceConfiguration(char *filenamebuf)
{
	FILE *fp;
	char filename[128] = "/usr/local/middleware/conf/";
	char buf[512] = "";
	char validCheck[16] = "";

	if(filenamebuf == NULL) {
		return;
	}
	strcat(filename,filenamebuf);
	SPTekDebugLog(LOG_LEVEL_INFO,"<%s>",filename);
	SENSOR_ID_E id = SENSOR_ID_FIRST;
	int intTemp;
		
	fp = fopen(filename,"r");
	if(fp == NULL) {
		SPTekDebugLog(LOG_LEVEL_ERROR,"Need File [Configuration file]");
		return;
	}

	fseek(fp, -5, SEEK_END);   
	fgets(buf, 5, fp);
	sprintf(validCheck,"#END");
	SPTekDebugLog(LOG_LEVEL_INFO,"<%s><%s>",validCheck,buf);
	if(strncmp(validCheck,buf,strlen(validCheck)) != 0) {
		SPTekDebugLog(LOG_LEVEL_ERROR,"<#END Not exist> Invalid Configuration File");
		return;
	}

	fseek(fp,0,SEEK_SET);
	fgets(buf,256,fp);//read first line >> comment
	fgets(buf,256,fp);//read second line >> DATA or #END

	while(strncmp(buf,"#END",4)!=0 && id < MAX_DEVICE_NUMBER){
		SPTekDebugLog(LOG_LEVEL_INFO,"\nDevice-%d:%s",(id+1),buf);
		char *ptr;

		ptr = strtok(buf,",");
		if(ptr == NULL) {
			fgets(buf,256,fp);
			id++;
			continue;
		}
		SetSensorDeviceId(id, GetDeviceID(), strlen(GetDeviceID()));

		ptr = strtok(NULL,",");
		if(ptr == NULL) {
			fgets(buf,256,fp);
			id++;
			continue;
		}
		SetSensorSensorId(id, ptr, strlen(ptr));

		ptr = strtok(NULL,",");
		if(ptr == NULL) {
			fgets(buf,256,fp);
			id++;
			continue;
		}
		SetSensorSensorName(id, ptr, strlen(ptr));

		ptr = strtok(NULL,",");
		if(ptr == NULL) {
			fgets(buf,256,fp);
			id++;
			continue;
		}
		SetSensorSensorType(id, ptr, strlen(ptr));

		ptr = strtok(NULL,",");
		if(ptr == NULL) {
			fgets(buf,256,fp);
			id++;
			continue;
		}
		intTemp = atoi(ptr);
		SetSensorState(id, intTemp);

		ptr = strtok(NULL,",");
		if(ptr == NULL) {
			fgets(buf,256,fp);
			id++;
			continue;
		}
		intTemp = atoi(ptr);
		if(intTemp == 0) {
			intTemp = 1;
		}
		SetSensorReadInterval(id, intTemp);

		ptr = strtok(NULL,",");
		if(ptr == NULL) {
			fgets(buf,256,fp);
			id++;
			continue;
		}
		intTemp = atoi(ptr);
		SetSensorReadMode(id, intTemp);

		ptr = strtok(NULL,",");
		if(ptr == NULL) {
			fgets(buf,256,fp);
			id++;
			continue;
		}
		SetLastValue(id, ptr, strlen(ptr));

		ptr = strtok(NULL,",");
		if(ptr == NULL) {
			fgets(buf,256,fp);
			id++;
			continue;
		}
		intTemp = atoi(ptr);
		SetSensorChangeStartTime(id, intTemp);

		ptr = strtok(NULL,",");
		if(ptr == NULL) {
			fgets(buf,256,fp);
			id++;
			continue;
		}
		intTemp = atoi(ptr);
		SetSensorChangeEndTime(id, intTemp);

		ptr = strtok(NULL,",");
		if(ptr == NULL) {
			fgets(buf,256,fp);
			id++;
			continue;
		}
		SetSensorSerialNumber(id, ptr, strlen(ptr));

		ptr = strtok(NULL,",");
		if(ptr == NULL) {
			fgets(buf,256,fp);
			id++;
			continue;
		}
		intTemp = atoi(ptr);
		SetSensorOperationType(id, intTemp);

		ptr = strtok(NULL,",");
		if(ptr == NULL) {
			fgets(buf,256,fp);
			id++;
			continue;
		}
		intTemp = atoi(ptr);
		SetSensorMaxInterval(id, intTemp);

		ptr = strtok(NULL,",");
		if(ptr == NULL) {
			fgets(buf,256,fp);
			id++;
			continue;
		}
		intTemp = atoi(ptr);
		SetSensorControlType(id, intTemp);

		ptr = strtok(NULL,",");
		if(ptr == NULL) {
			fgets(buf,256,fp);
			id++;
			continue;
		}
		intTemp = atoi(ptr);
		SetSensorRegisterFlag(id, intTemp);

		fgets(buf,256,fp);
		id++;
	}
	fclose(fp);
}



/**
 * @brief Store device state 
 * @return 0 Void
 */
int StoreDeviceConfiguration(void)
{
	FILE *fp;
	char backupFileName[64] = "/usr/local/middleware/conf/SMADeviceConf.backup";
	char swpFileName[64] = "/usr/local/middleware/conf/SMADeviceConf.backup.swp";
	char buf[256];
	int status;
	SENSOR_ID_E id;

	fp = fopen(swpFileName,"w");
	if( fp == NULL) {
		return -1;
	}

	memset(buf,0,256);
	strcpy(buf,"#DeviceID,SensorID,SensorName,SensorType,EnableFlag,ReadInterval,ReadMode,LastValue,StartTime,EndTime,SerialNumber,OperationType,MaxInterval,ControlType,RegisterFlag\n");
	fputs(buf,fp);

	for(id = SENSOR_ID_FIRST; id<SENSOR_ID_MAX; id++) {
		(void)memset(buf,0,256);
		GetBackupSensorInformation(id, buf);
		fputs(buf,fp);
		//SPTekDebugLog(LOG_LEVEL_INFO,"%s",buf);
		switch(id) {

			case SENSOR_ID_MOTION_DETECT: {
				HC_SR501Close();
			}
			break;

			case SENSOR_ID_TEMPERATURE: {
				DS18B20Close();
			}
			break;

			case SENSOR_ID_LIGHT: {
				BH1750Close();
			}
			break;

			case SENSOR_ID_HUMIDITY: {
				HTU21DClose();
			}
			break;

			case SENSOR_ID_ONOFF: {
				BUT001Close();
			}
			break;

			case SENSOR_ID_NOISE: {
				TCACB_147Close();
			}
			break;

			case SENSOR_ID_DUST: {
				PM1001Close();
			}
			break;

			case SENSOR_ID_CO2: {
				CM1101Close();
			}
			break;

			case SENSOR_ID_DOOR: {
				MC38Close();
			}
			break;

			case SENSOR_ID_LED: {
				RGB_LEDClose();
			}
			break;

			case SENSOR_ID_BUZZER : {
				BUZZERClose();
			}
			break;

			case SENSOR_ID_PRESSURE : {
				PRESSUREClose();
			}
			break;

			case SENSOR_ID_WINDVANE : {
				WINDVANEClose();
			}
			break;

			case SENSOR_ID_PH : {
				PHClose();
			}
			break;

			case SENSOR_ID_PERCENT : {
				PERCENTClose();
			}
			break;

			case SENSOR_ID_COMPLEX : {
				COMPLEXClose();
			}
			break;

			case SENSOR_ID_STRING : {
				STRINGClose();
			}
			break;

			case SENSOR_ID_NUMBER : {
				NUMBERClose();
			}
			break;

			case SENSOR_ID_CUSTOM_DEFINE: {
				CUSTOMClose();
			}
			break;

			case SENSOR_ID_UNDEFINED_SENSOR: {
				UNDEFINEClose();
			}
			break;

			default: {
				;
			}
			break;
		}
	}
	memset(buf,0,256);
	strcpy(buf,"#END\n");
	fputs(buf,fp);
	fclose(fp);

	
	status = remove(backupFileName);
	if(status != 0){
		SPTekDebugLog(LOG_LEVEL_ERROR,"!!Fail!! rm SMADeviceConf.backup");
	}
	status = rename(swpFileName, backupFileName);
	if(status != 0){
		SPTekDebugLog(LOG_LEVEL_ERROR,"!!Fail!! rename SMADeviceConf.backup.swp SMADeviceConf.backup");
	}

	sync();
	return 0;
}




void InitSensorCommandList(void)
{
	SensorCommandListInit(&gSensorCommandList);
}












/*
 **************************************** 
 * Major Functions
 **************************************** 
 */

/**
 * @brief Initialization sensor handler
 * @return 0 Void
 * @detail Turn on alarm. Open each device. and Load last device state.
 */
int SensorHandlerInit(int loadFlag, int argc, char* argv[])
{
	if(loadFlag == 1) {
		if(argc == 2) {
			LoadDeviceConfiguration("SMADeviceConf.backup");
		} else if(argc > 2) {
			if(strlen(argv[2]) == 0) {
				LoadDeviceConfiguration("SMADeviceConf.backup");
			} else {
				LoadDeviceConfiguration(argv[2]);
			}
		}
	}
	SPTekDebugLog(LOG_LEVEL_INFO, "Device Load Success");
	// Sensor command list initialization
	InitSensorCommandList();
	SPTekDebugLog(LOG_LEVEL_INFO, "Command List Init");
	// Each device init
	InitEnableDevice();
	SPTekDebugLog(LOG_LEVEL_INFO, "Device Init Success");
	// Polling function<SensorReadHandler> start
	SignalConfiguration();
	SPTekDebugLog(LOG_LEVEL_INFO, "Read Handler Start!!");
	return 0;
}

/**
 * @brief Get data target sensor ID
 * @param[in]    target  Target sensor ID
 * @param[out]   data    Return data pointer
 * @return ERROR_TYPE_SUCCESS
 *         ERROR_TYPE_FAIL
 */
int SensorHandlerGetData(SENSOR_ID_E target, char *data, int *dataLength)
{
	int              ret       = 0;
	SENSOR_ID_E      id        = SENSOR_ID_FIRST;

	alarm(0);
	for(id = SENSOR_ID_FIRST; id<SENSOR_ID_MAX; id++) {
		if(!GetSensorRegisterFlag(id)){
			continue;
		}
		if(target == id) {
			switch(id) {
				case SENSOR_ID_MOTION_DETECT: {
					ret = HC_SR501Read(data,dataLength);
				}
				break;

				case SENSOR_ID_TEMPERATURE: {
					ret = DS18B20Read(data,dataLength);
				}
				break;

				case SENSOR_ID_LIGHT: {
					ret = BH1750Read(data,dataLength);
				}
				break;

				case SENSOR_ID_HUMIDITY: {
					ret = HTU21DRead(data,dataLength);
				}
				break;
				
				case SENSOR_ID_ONOFF: {
					ret = BUT001Read(data,dataLength);
				}
				break;

				case SENSOR_ID_NOISE: {
					ret = TCACB_147Read(data,dataLength);
				}
				break;

				case SENSOR_ID_DUST: {
					ret = PM1001Read(data,dataLength);
				}
				break;

				case SENSOR_ID_CO2: {
					ret = CM1101Read(data,dataLength);
				}
				break;

				case SENSOR_ID_DOOR: {
					ret = MC38Read(data,dataLength);
				}
				break;

				case SENSOR_ID_LED: {
					ret = RGB_LEDRead(data,dataLength);
				}
				break;

				case SENSOR_ID_BUZZER : {
					ret = BUZZERRead(data,dataLength);
				}
				break;

				case SENSOR_ID_PRESSURE : {
					ret = PRESSURERead(data,dataLength);
				}
				break;

				case SENSOR_ID_WINDVANE : {
					ret = WINDVANERead(data,dataLength);
				}
				break;

				case SENSOR_ID_PH : {
					ret = PHRead(data,dataLength);
				}
				break;

				case SENSOR_ID_PERCENT : {
					ret = PERCENTRead(data,dataLength);
				}
				break;

				case SENSOR_ID_COMPLEX : {
					ret = COMPLEXRead(data,dataLength);
				}
				break;

				case SENSOR_ID_STRING : {
					ret = STRINGRead(data,dataLength);
				}
				break;

				case SENSOR_ID_NUMBER : {
					ret = NUMBERRead(data,dataLength);
				}
				break;

				case SENSOR_ID_CUSTOM_DEFINE: {
					ret = CUSTOMRead(data,dataLength);
				}
				break;

				case SENSOR_ID_UNDEFINED_SENSOR: {
					ret = UNDEFINERead(data,dataLength);
				}
				break;

				default:{
					SPTekDebugLog(LOG_LEVEL_INFO,"Read Fail!! -  Unkown Device!!");
				}
				break;
			}
			if( strncmp(data,"N/A",strlen("N/A")) == 0 ) {
				//SPTekDebugLog(LOG_LEVEL_INFO,"[N/A log] <%s>",data);
				data[strlen("N/A")] = '\0';
				*dataLength = strlen("N/A");
				SetLastValue(target, data, *dataLength);
			} else {
				SetLastValue(target, data, *dataLength);
			}
		}
		
	}
	

	alarm(1);
	if(ret != ERROR_TYPE_SUCCESS){
		SPTekDebugLog(LOG_LEVEL_ERROR,"Device Value Read Fail!");
	}

	return ret;
}

/**
 * @brief Get Status target sensor ID
 * @param[in]    target  Target sensor ID
 * @param[out]   value   Return value pointer (SENSOR_STATE_E)
 * @return ERROR_TYPE_SUCCESS
 *         ERROR_TYPE_FAIL
 */
int SensorHandlerGetStatus(SENSOR_ID_E target, SENSOR_STATE_E *value)
{
	int              ret       = 0;
	int 			 result    = ERROR_TYPE_SUCCESS;
	int              startTime = 0;
	int              length    = 0;
	time_t           now;
	char            *lastValue = NULL;
	char             nowValue[MAX_LEN_LAST_VALUE+1];

	memset(nowValue, 0x00, MAX_LEN_LAST_VALUE+1);

	startTime = GetSensorChangeStartTime(target);
	lastValue = GetLastValue(target);
	time(&now);

	ret = SensorHandlerGetData(target,nowValue,&length );
	if(ret != ERROR_TYPE_SUCCESS) {
		result = ret;
	}

	ret = SetSensorChangeEndTime(target, now);
	if(ret != ERROR_TYPE_SUCCESS) {
		result = ret;
	}

	*value = SENSOR_STATE_ENABLE;

	if(lastValue == NULL || strcmp(lastValue, nowValue) != 0) {
		ret = SetSensorChangeStartTime(target, now);
		if(ret != ERROR_TYPE_SUCCESS) {
			result = ret;
		}
	} else if(GetSensorMaxInterval(target) > 0  && now - startTime > GetSensorMaxInterval(target)) {
		SPTekDebugLog(LOG_LEVEL_ERROR,"Over Max Interval (%s):Set State disable!!",GetSensorSensorName(target));
		*value = SENSOR_STATE_DISABLE;
	} else if(strncmp(nowValue, "N/A", strlen("N/A")) == 0) {
		SPTekDebugLog(LOG_LEVEL_ERROR,"N/A data: (%s):Set State disable!!",GetSensorSensorName(target));
		*value = SENSOR_STATE_DISABLE;
	}
	
	if(result != ERROR_TYPE_SUCCESS) {
		SPTekDebugLog(LOG_LEVEL_ERROR,"Device Get Status Fail!");
	}
	SetSensorState(target,*value);
	return result;
}

/**
 * @brief Register sensor command 
 * @param[in]    commandName     Command Name
 * @param[in]    commandFunction Command Function Pointer
 * @return ERROR_TYPE_SUCCESS
 *         ERROR_TYPE_FAIL
 */
int RegisterSensorCommand(char commandTag, char *commandName, char* (*commandFunction)(char*))
{
	int ret = ERROR_TYPE_SUCCESS;
	COMMAND_NODE_T *node = NULL;

	node = SensorCommandListGetNameNode(&gSensorCommandList, commandName);

	if(node != NULL) {
		SPTekDebugLog(LOG_LEVEL_INFO,"Fail,Already registered command<%s>",commandName);
		return ERROR_TYPE_FAIL;
	}
	node = SensorCommandListGetTagNode(&gSensorCommandList, commandTag);

	if(node != NULL) {
		SPTekDebugLog(LOG_LEVEL_INFO,"Fail,Already registered command tag <%x>",commandTag);
		return ERROR_TYPE_FAIL;
	}

	if( commandTag < 0x80 || commandTag > 0x9f) {
		SPTekDebugLog(LOG_LEVEL_INFO,"Fail,Tag range over <%x>",commandTag);
		return ERROR_TYPE_FAIL;
	}

	ret = SensorCommandListAddNode(&gSensorCommandList, commandTag, commandName, strlen(commandName), commandFunction);

	if(ret != ERROR_TYPE_SUCCESS){
		SPTekDebugLog(LOG_LEVEL_INFO,"Register Fail!<%x><%s>", commandTag, commandName);
		return ERROR_TYPE_FAIL;
	}
	return ret;
}

/**
 * @brief Cancel registered sensor command 
 * @param[in]    commandName     Command Name
 * @return ERROR_TYPE_SUCCESS
 *         ERROR_TYPE_FAIL
 */
int CancelSensorCommand(char *commandName)
{
	int ret = ERROR_TYPE_SUCCESS;
	COMMAND_NODE_T *node = NULL;

	node = SensorCommandListGetNameNode(&gSensorCommandList, commandName);
	if(node == NULL) {
		SPTekDebugLog(LOG_LEVEL_INFO,"Fail,Not registered command<%s>",commandName);
		return ERROR_TYPE_FAIL;
	}

	ret = SensorCommandListDeleteNode(&gSensorCommandList, commandName);
	if(ret != ERROR_TYPE_SUCCESS){
		SPTekDebugLog(LOG_LEVEL_INFO,"Register Fail!<%s>",commandName);
		return ERROR_TYPE_FAIL;
	}
	return ret;
}


/**
 * @brief Execute registered sensor command 
 * @param[in]    commandName     Command Name
 * @return ERROR_TYPE_SUCCESS
 *         ERROR_TYPE_FAIL
 */
int ExecuteSensorCommand(char *commandName, char *commandArg, char *result)
{
	int ret = ERROR_TYPE_SUCCESS;
	char *retResult;
	COMMAND_NODE_T *node = NULL;

	node = SensorCommandListGetNameNode(&gSensorCommandList, commandName);
	if(node == NULL) {
		SPTekDebugLog(LOG_LEVEL_INFO,"Fail,Not registered command<%s>",commandName);
		return ERROR_TYPE_FAIL;
	}

	retResult = node->mCommandFunction(commandArg);
	strcpy(result,retResult);
	if(ret != ERROR_TYPE_SUCCESS){
		SPTekDebugLog(LOG_LEVEL_INFO,"Execute Fail!<%s>",commandName);
		return ERROR_TYPE_FAIL;
	}
	return ret;
}

/**
 * @brief Execute registered sensor command 
 * @param[in]    commandName     Command Name
 * @return ERROR_TYPE_SUCCESS
 *         ERROR_TYPE_FAIL
 */
int ExecuteSensorCommandTag(char commandTag, char *commandArg, char *result)
{
	int ret = ERROR_TYPE_SUCCESS;
	char *retResult;
	COMMAND_NODE_T *node = NULL;

	node = SensorCommandListGetTagNode(&gSensorCommandList, commandTag);
	if(node == NULL) {
		SPTekDebugLog(LOG_LEVEL_INFO,"Fail,Not registered command tag<%x>",commandTag);
		return ERROR_TYPE_FAIL;
	}

	retResult = node->mCommandFunction(commandArg);
	strcpy(result,retResult);
	if(ret != ERROR_TYPE_SUCCESS){
		SPTekDebugLog(LOG_LEVEL_INFO,"Execute Fail!<%x>",commandTag);
		return ERROR_TYPE_FAIL;
	}
	return ret;
}

/**
 * @brief Get sensor control command Tag by position
 * @param[in]    positon List position
 * @return CommandTag  Get command tag by input position
 */
char GetSensorCommandTagPosition(int position)
{
	COMMAND_NODE_T *node = NULL;
	node = SensorCommandListGetPositionNode(&gSensorCommandList, position);
	if(node == NULL)
		return 0x00;
	return node->mCommandTag;
}

/**
 * @brief Get sensor control command name by position
 * @param[in]    positon List position
 * @return CommandName Get command name by input position
 */
char* GetSensorCommandNamePosition(int position)
{
	COMMAND_NODE_T *node = NULL;
	node = SensorCommandListGetPositionNode(&gSensorCommandList, position);
	if(node == NULL)
		return NULL;
	return node->mCommandName;
}

/**
 * @brief Execute registered sensor command 
 * @return Void
 */
int GetSensorCommandListCount(void)
{
	return gSensorCommandList.mCount;	
}



/**
 * @brief Control sensor target sensor ID
 * @param[in]    target        Target sensor ID
 * @param[out]   data          Return data pointer
 * @param[out]   dataLength    Return dataLength
 * @return ERROR_TYPE_SUCCESS
 *         ERROR_TYPE_FAIL
 */
int ControlSensor(SENSOR_ID_E target, char *control, int controlLength, char *result)
{
	int   ret       = ERROR_TYPE_SUCCESS;
	char *retString = NULL;

	SPTekDebugLog(LOG_LEVEL_DEBUG,"ControlSensor");

	switch(target) {
		case SENSOR_ID_LED: {
			retString = RGB_LEDControl(control,controlLength);
			strcpy(result,retString);
			if(retString != NULL) {
				free(retString);
			}
			SPTekDebugLog(LOG_LEVEL_DEBUG,"ControlSensor%s",result);
		}
		break;

		default:{
			SPTekDebugLog(LOG_LEVEL_DEBUG,"Control Fail!! - Not Support  Device!!");
		}
		break;
	}

		
	return ret;
}







/**
 * @brief Terminate sensor handler
 * @return 0 Void
 * @detail Turn off alarm. Close each device. and Backup last device state.
 */
int SensorHandlerClose(void)
{
	alarm(0);
	StoreDeviceConfiguration();
	sleep(1);
	SensorCommandListDeleteAllNode(&gSensorCommandList);
	return 0;
}

