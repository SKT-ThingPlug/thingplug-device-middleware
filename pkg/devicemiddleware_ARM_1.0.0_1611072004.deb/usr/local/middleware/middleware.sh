#!/bin/sh

PORT=8000

if [ -z $BASE_DIR ]; then
        #BASE_DIR=`readlink -f $(dirname "$0")`
        BASE_DIR=/usr/local/middleware
        GP_DIR="$BASE_DIR/gp"
        LOG_DIR="$BASE_DIR/log"
fi

MA=ManagementAgent
SMA=SensorManagementAgent
GP=GatewayPortal
PM=ProcessorManager

GPP="$GP_DIR/$GP"
GPC="$GPP/server.js"

W1="BB-W1"
GPIO="BB-IGOT-GPIO"
UART="BB-UART5"


stop(){

        #for agent in $MA $SMA $GPC $GPP $PM
        until [ -z "$1" ]
        do
                agent="$1"
                #echo $agent
                process=`ps -ef|grep -w "$agent"|grep -v grep|awk '{print $2}'`
                if [ "$process" ]; then
                        for p in "$process"
                        do
#                               echo "> kill process : [$p]"
                                kill -9 $p
                        done
                fi
        shift
        done
}


start(){

        if [ ! -e "$LOG_DIR" ]; then
                mkdir "$LOG_DIR"
        fi

         until [ -z "$1" ]
        do
                agent="$1"
                #echo $agent
                process=`ps -ef|grep -w "$agent"|grep -v grep|awk '{print $2}'`
                if [ ! "$process" ]; then
                        case "$agent" in
                                "$MA")
                                        nohup "$BASE_DIR/$MA" > /dev/null 2>&1 &
                                        ;;

                                "$SMA")
                                        sleep 2
                                        nohup "$BASE_DIR/$SMA" > /dev/null 2>&1 &
                                        ;;

                                "$GP")
                                        exec node "$GP_DIR/$GP".js "$PORT" 2>&1 &
                                        ;;

                                "$PM")
                                        nohup "$BASE_DIR/$PM" > /dev/null 2>&1 &
                                        ;;

                                *) echo "* $agent"
                                       ;;
                        esac
                fi
        shift
        done
}


set_config(){

        stop "$PM" "$MA" "$SMA" 
        start "$MA" "$SMA" "$PM"

}

sensor_drive_load(){


	if [ -e "/sys/devices/bone_capemgr.9/slots" ]; then
	
		SENSOR_SLOTS=`cat /sys/devices/bone_capemgr.9/slots`
	
	
		for sensor in $W1 $UART $GPIO
		do
		        flag="$sensor"
		        for line in $SENSOR_SLOTS
		        do
		                if [ `echo "$line" | grep "$sensor"` ]; then
		                        flag="false"
		                        break
		                fi
		        done
		
		        case "$flag" in
		
		                "$W1" | "$GPIO" | "$UART" )
		                        echo $flag > /sys/devices/bone_capemgr.9/slots
		                        ;;
		                *)
		                        #echo " $sensor is already loaded"
		                        ;;
		        esac
		done
		echo 51 > /sys/class/gpio/export
		echo 5 > /sys/class/gpio/export
		echo 49 > /sys/class/gpio/export
		echo 115 > /sys/class/gpio/export

	fi

	
}


case "$1" in

        start)
                start "$MA" "$SMA" "$GP" "$PM"
                ;;

        stop | remove)
                stop "$PM" "$MA" "$SMA" "$GPC" "$GPP"
                ;;

        restart)
                stop "$PM" "$MA" "$SMA" "$GPC" "$GPP"
                start "$MA" "$SMA" "$GP" "$PM"
                ;;

        upgrade)
                stop "$GPC"
                ;;

	remote)
	        start "$SMA"
		;;
        pmrun)
                stop "$PM"
                start "$PM" 
                ;;

        pmrecovery)
                stop  "$MA" "$SMA"
                start "$MA" "$SMA"
                ;;

        pmstop)
                stop "$PM" "$MA" "$SMA"
                ;;

        set_config)
                set_config
                ;;

        install_driver)
				sensor_drive_load
                ;;

        *)
                #echo "Usage {start|stop|remove|restart}"
                exit 1
                ;;
esac

exit 0
