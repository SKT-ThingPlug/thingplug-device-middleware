#ifndef _BASE_DIRECTORY_H_
#define _BASE_DIRECTORY_H_

#define DM_STR(x) #x

#ifndef BASE
#define BASE_DIR "/usr/local/middleware"
#else
#define BASE_DIR BASE
#endif

#endif//_BASE_DIRECTORY_H_
