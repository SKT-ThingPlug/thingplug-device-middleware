
/**
 * @file Timer.c
 *
 * @brief DeviceMiddleware Timer API
 *
 * Copyright (C) 2015. SPTek,All Rights Reserved.
 * Written 2015,by SPTek 
 */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <signal.h>
#include <assert.h>

#include "Timer.h"
#include "SPTekDebug.h"

/*
 **************************************** 
 * Definitions & Global Variables
 **************************************** 
 */

static TimerList *timerlist;

/*
 ****************************************
 * Implementations
 ****************************************
 */

void remove_timers();
void remove_timer(Timer** timer);

/**
 * @brief     Intialization for TimerManager
 * @return    !=0 if failed,
 *              0 if success
 */
int DM_TimerInit(void)
{
    timerlist = calloc(1, sizeof(TimerList));
    if(!timerlist){
        return -1;
    }
    return 0;
}

/**
 * @brief     Termination for TimerManager
 * @return    void
 */
void DM_TimerTerm(void)
{
    remove_timers();
}

/**
 * @brief     lock timerlist queue
 * @return    void
 */
void lock_timer_list()
{
    pthread_mutex_lock(&timerlist->lock);
}

/**
 * @brief     unlock timerlist queue
 * @return    void
 */
void unlock_timer_list()
{
    pthread_mutex_unlock(&timerlist->lock);
}

/**
 * @brief     memory free for timerlist
 * @return    void
 */
void remove_timers()
{
    Timer *timer;
    if(!timerlist){
        return;
    }
    lock_timer_list();
    while(timerlist->head){
        timer = timerlist->head;
        if (timer) {
            timerlist->head = timer->next;
            if (!timerlist->head) {
                timerlist->last = 0;
            }
            timer_delete(timer->timerID);
            free(timer);
            timer = 0;
        }
    }
    unlock_timer_list();
    if(timerlist){
        free(timerlist);
        timerlist = 0;
    }
} 

/**
 * @brief     show timer list data in the console window
 * @return    void
 */
void print_timerlist(void)
{
	Timer *timer = timerlist->head;
	while(timer)
	{
		SPTekDebugLog(LOG_LEVEL_DEBUG, "	timer:        %p", timer);
		SPTekDebugLog(LOG_LEVEL_DEBUG, "	sec:	      %d", timer->sec);
		SPTekDebugLog(LOG_LEVEL_DEBUG, "	nsec:		  %d", timer->nsec);
		SPTekDebugLog(LOG_LEVEL_DEBUG, "	periodic:     %d", timer->periodic);
		SPTekDebugLog(LOG_LEVEL_DEBUG, "	parameter:	  %p", timer->parameter);
		SPTekDebugLog(LOG_LEVEL_DEBUG, "	timerID:      %d", (int)timer->timerID);
		SPTekDebugLog(LOG_LEVEL_DEBUG, "	next:         %p", timer->next);
		timer = timer->next;
	}
}

/**
 * @brief     insert Timer to Timer list
 * @param[in] timer : Timer structure 
 * @return    void
 */
void reg_timer(Timer *timer)
{
    if (timer == NULL)
        return;

    timer->next = 0;
    lock_timer_list();
    if (timerlist->head) {
        assert(timerlist->last);
        // The list is not empty
        timer->next = timerlist->head;
        timerlist->head = timer;
    }else{
        // The list is empty
        assert(!timerlist->head);
        timerlist->head = timer;
        timerlist->last = timer;
    }
    unlock_timer_list();
}

/**
 * @brief     delete Timer from Timer list
 * @param[in] timer : Timer structure 
 * @return    void
 */
void unreg_timer(Timer *timer)
{
    Timer *tptr, *pptr;
    if (timer == NULL)
        return;
    
    tptr = timerlist->head;
    while(tptr){
        if (tptr == timer) {
            if(timerlist->head == timer){
                timerlist->head = timer->next;
            }else{
                pptr->next = timer->next;            
            }
            if (!timerlist->head) {
                timerlist->last = 0;
            }
            break;
        }
        pptr = tptr;
        tptr = tptr->next;
    }
}

/**
 * @brief     get Timer from Timer list
 * @param[in] tidp : timer_t pointer
 * @return    NULL   if failed,
 *            Timer  if success
 */
Timer* get_timer(timer_t *tidp)
{
    Timer *tptr;
    if (tidp == NULL)
        return NULL;

    tptr = timerlist->head;
    while(tptr){
        if (tptr->timerID == *tidp) {
            break;
        }
        tptr = tptr->next;
    }
    return tptr;
}

/**
 * @brief     expired timer handling
 * @param[in] timer : Timer structure 
 * @return    void
 */
void expire_timer(Timer** timer)
{
    if (*timer == NULL)	return;
	
    if ( NULL != (*timer)->callback )
    {
        SPTekDebugLog(LOG_LEVEL_DEBUG, "call timer callback function for timer(%p)", *timer);
        (*timer)->callback((*timer)->parameter);
    }
    if ( 0 == (*timer)->periodic )
    {
        remove_timer(timer);
    }
}

/**
 * @brief     callback funtion to be called when the time expires
 * @param[in] sig  :  signal no
 * @param[in] si   :  signal data
 * @param[in] uc   :  signal sensor
 * @return    void
 */
static void timer_handler( int sig, siginfo_t *si, void *uc )
{
    timer_t *tidp;
    tidp = si->si_value.sival_ptr;
    Timer* pTimer = get_timer(tidp);
    expire_timer(&pTimer);
}

/**
 * @brief     set the timer
 * @param[in] interval  :  timer interval (sec)
 * @param[in] periodic  :  timer periodic (sec)
 * @param[in] sensor :  when the timer expires, the data that is passed to the callback function
 * @return    NULL   if failed,
 *            Timer  if success
 */
Timer* timer_set(int sec, int nsec, int periodic, void *cb, void *parameter)
{
    struct sigevent         te;
    struct itimerspec       its;
    struct sigaction        sa;
	sigset_t mask;
    int                     sigNo = SIGRTMIN + 1;

    SPTekDebugLog(LOG_LEVEL_DEBUG, "timer_set interval %d.%d", sec, nsec);

    Timer* pTimer = (Timer*)calloc(1, sizeof(Timer)) ;
    if (pTimer == NULL)
    {
        return NULL;
    }

    memset(pTimer, 0, sizeof(Timer));
    memset(&te, 0, sizeof(te));
    
    /* Set up signal handler. */
    sa.sa_flags = SA_SIGINFO;
    sa.sa_sigaction = timer_handler;
    sigemptyset(&sa.sa_mask);
    if (sigaction(sigNo, &sa, NULL) == -1)
    {
        SPTekDebugLog(LOG_LEVEL_ERROR, "Failed to setup signal handling");
        free(pTimer);
        return 0;
    }

	sigemptyset(&mask);
	sigaddset(&mask, sigNo);
	if (sigprocmask(SIG_SETMASK, &mask, NULL) == -1) {
        SPTekDebugLog(LOG_LEVEL_ERROR, "Failed to block signal handling");
        free(pTimer);
        return 0;
	}

    /* Set and enable alarm */
    te.sigev_notify = SIGEV_SIGNAL;
    te.sigev_signo = sigNo;
    te.sigev_value.sival_ptr = &pTimer->timerID;
    if (timer_create(CLOCK_REALTIME, &te, &pTimer->timerID) == -1) {
        SPTekDebugLog(LOG_LEVEL_ERROR, "Failed to create timer");
        free(pTimer);
        return 0;
	}
    its.it_value.tv_sec = sec;
    its.it_value.tv_nsec = nsec;
	its.it_interval.tv_sec = its.it_value.tv_sec;
	its.it_interval.tv_nsec = its.it_value.tv_nsec;
    if (timer_settime(pTimer->timerID, 0, &its, NULL) == -1) {
        SPTekDebugLog(LOG_LEVEL_ERROR, "Failed to set time for timer");
        free(pTimer);
        return 0;
	}
	
	if (sigprocmask(SIG_UNBLOCK, &mask, NULL) == -1) {
        SPTekDebugLog(LOG_LEVEL_ERROR, "Failed to sigprocmask for timer");
        free(pTimer);
        return 0;
	}

    pTimer->sec			= sec;
    pTimer->nsec		= nsec;
    pTimer->periodic    = periodic ;
	pTimer->callback    = (timercb_fn)cb;
    pTimer->parameter   = parameter;
    reg_timer(pTimer);
    SPTekDebugLog(LOG_LEVEL_DEBUG, "New timer created : (%p)", pTimer);

    return pTimer ;
}

/**
 * @brief     remove the timer
 * @param[in] timer : Timer structure 
 * @return    void
 */
/*void remove_timer(Timer* timer)
{	
    struct itimerspec       its;

    if (timer == NULL)
        return;
    print_timerlist();

    Timer* pTimer = get_timer(&timer->timerID);
    if(pTimer){
        
        // Disarm any current timeouts. 
        its.it_value.tv_sec = 0;
        its.it_value.tv_nsec = 0L;
        its.it_interval.tv_sec = 0;
        its.it_interval.tv_nsec = 0;
        timer_settime(timer->timerID, 0, &its, NULL);
        SPTekDebugLog(LOG_LEVEL_DEBUG, "remove timer(%p)", timer);
        unreg_timer(timer);
        timer_delete(timer->timerID);
        free(timer);
        timer = 0;
    print_timerlist();

    } else {
        SPTekDebugLog(LOG_LEVEL_DEBUG, "remove timer fail!");
    }
}*/

/**
 * @brief     remove the timer
 * @param[in] timer : Timer structure 
 * @return    void
 */
void remove_timer(Timer** timer)
{	
    struct itimerspec       its;

    if (*timer == NULL)
        return;
//    print_timerlist();

    Timer* pTimer = get_timer(&(*timer)->timerID);
    if(pTimer){
        
        /* Disarm any current timeouts. */
        its.it_value.tv_sec = 0;
        its.it_value.tv_nsec = 0L;
        its.it_interval.tv_sec = 0;
        its.it_interval.tv_nsec = 0;
        timer_settime((*timer)->timerID, 0, &its, NULL);
        SPTekDebugLog(LOG_LEVEL_DEBUG, "remove timer(%p)", (*timer));
        unreg_timer(*timer);
        timer_delete((*timer)->timerID);
        free(*timer);
        *timer = NULL;
//    print_timerlist();

    } else {
        SPTekDebugLog(LOG_LEVEL_DEBUG, "remove timer fail!");
    }
}


/**
 * @brief     Function to use when you set the timer
 *            Set the timer. When the timer expires, the callback function is called.
 * @param[in] interval  :  timer interval (sec)
 * @param[in] periodic  :  timer periodic (sec)
 * @param[in] sensor :  when the timer expires, the data that is passed to the callback function
 * @return    NULL   if failed,
 *            Timer  if success
 */
Timer* SetTimer(int sec, int nsec, int periodic,void *cb, void *parameter)
{
    Timer* pTimer;
    pTimer = timer_set(sec, nsec, periodic, cb ,parameter);
    return pTimer;
}

/**
 * @brief     Function used when canceling the timer
 *            Cancel the timer
 * @param[in] timer : Timer structure 
 * @return    void
 */
void CancelTimer(Timer** timer)
{
    remove_timer(timer);
}

