/**
 * @file ErrorDefinition.h
 *
 * @brief Error Definition header
 *
 * Copyright (C) 2016. SK Telecom, All Rights Reserved.
 * Written 2016, by SK Telecom
 */

#ifndef __ERROR_DEFINITION_H__
#define __ERROR_DEFINITION_H__

/*
 ****************************************
 * Definition
 ****************************************
 */

#define ERROR_TYPE_SUCCESS          0
#define ERROR_TYPE_FAIL            -1
#define ERROR_TYPE_INVALID_COMMAND -2
#define ERROR_TYPE_INVALID_PACKET  -3
#define ERROR_TYPE_MEMORY_LACK     -4
#define ERROR_TYPE_INVALID_PARAM   -5
#define ERROR_TYPE_UNSUPPORT       -6
#define ERROR_TYPE_DEVICE_DISABLED -7



#endif //__ERROR_DEFINITION_H__
