/**
 * @file Orientation.c
 *
 * @brief Orientation Sensor Device Handler
 *
 * Copyright (C) 2016. SK Telecom, All Rights Reserved.
 * Written 2016, by SK Telecom
 */
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <string.h>
#include "Orientation.h"
#include "SensorManager.h"

/*
 ****************************************
 * Definition & Global Variable
 ****************************************
 */
#define BUFF_SIZE  128
#define FILE_NAME  "/sys/bus/w1/devices/28-0315030fecff/w1_slave"

static char gDummyData[3][20] = {"-360","360","180"};
//static char gDummyData[1][20] = {"-360,360,180"};
static int gIndex = 0;
int OrientationRead_X(char *data, int *len);
int OrientationRead_Y(char *data, int *len);
int OrientationRead_Z(char *data, int *len);

/*
 ****************************************
 * Orientation device Main Handle Functions
 ****************************************
 */

/**
 * @brief Orientation device init function
 * @param[in] No parameter
 * @return	 0 => Success init
 * 		-1 => Error file open
 */
int OrientationInit(void *ops, char axis)
{
	SENSOR_OPERATIONS_T *operations = (SENSOR_OPERATIONS_T *)ops;
	gIndex = 0;

    if(axis == 'X' ) {
	    operations->Read = OrientationRead_X;
    } else if ( axis == 'Y' ) {
	    operations->Read = OrientationRead_Y;
    } else if ( axis == 'Z' ) {
	    operations->Read = OrientationRead_Z;
    } else {
	    operations->Read = OrientationRead;
    }
	operations->Close = OrientationClose;
	operations->Control = OrientationControl;
	return 0;
}

/**
 * @brief Orientation device control function(sample)
 * @param[in] data Control data
 * @param[in] len  Control data length
 * @return	 result Result string
 */
char* OrientationControl(char *data, int len)
{
	char result[256];
	char cmd[8] = "";
	char id[126] = "";
    int ret = 0;

    // TODO data parsing & Control

	if( ret == 0 ) {
		sprintf(result,"{\"id\": \"%s\", \"result\": \"%s\"}",id,cmd);
	} else {
		sprintf(result,"{\"id\": \"%s\", \"error\": {\"code\": -32000, \"message\":\"Device not found\"}}",id);
	}

	return strdup(result);
}

int OrientationRead_X(char *data, int *len)
{
	strcpy(data,gDummyData[0]);
	*len = strlen(data);
	return 0;
}
int OrientationRead_Y(char *data, int *len)
{
	strcpy(data,gDummyData[1]);
	*len = strlen(data);
	return 0;
}
int OrientationRead_Z(char *data, int *len)
{
	strcpy(data,gDummyData[2]);
	*len = strlen(data);
	return 0;
}

/**
 * @brief Orientation device Orientation value read funciton
 * @param[in]  structure member mLastValue pointer
 * @return	 0 => Success read data
 * 		-3 => Error read operation
 * 		-4 => Error lseek operation
 */
int OrientationRead(char *data, int *len)
{
	strcpy(data,gDummyData[gIndex]);
	*len = strlen(data);
	return 0;
}

/**
 * @brief Orientation device close funciton
 * @param[in] No parameter
 * @return 0 = default
 */
int OrientationClose(void)
{
	return 0;
}

/**
 * @brief Orientation Extract Orientation value
 * @param[in] Raw Data
 * @return 0 = Orientation Value
 */
int getOrientationValue(char *data)
{
	return 0;
}

