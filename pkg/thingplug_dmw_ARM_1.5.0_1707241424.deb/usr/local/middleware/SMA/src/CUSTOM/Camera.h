/*
 * @file Camera.h
 *
 * @brief Camera Sensor handler header
 *
 * Copyright (C) 2016. SK Telecom, All Rights Reserved.
 * Written 2016, by SK Telecom
 */

#ifndef _CAMERA_H_
#define _CAMERA_H_

/*
 ****************************************
 * Enumerations
 ****************************************
 */


/*
 ****************************************
 * Major Functions
 ****************************************
 */

/**
 * @brief Camera device init function
 * @param[in] No parameter
 * @return	 0 => Success init
 * 		-1 => Error file open
 */
int CameraInit(void *ops);

/**
 * @brief Camera device button value read funciton
 * @param[in]  structure member mLastValue pointer
 * @return	 0 => Success read data
 * 		-1 => Error ioctl operation
 * 		-2 => Error write operation
 * 		-3 => Error read operation
 */
int CameraRead(char *data, int *len);

/**
 * @brief Camera device close funciton
 * @param[in] No parameter
 * @return 0 = default
 */
int CameraClose(void);

/**
 * @brief Camera device control function(sample)
 * @param[in] data Control data
 * @param[in] len  Control data length
 * @return	 result Result string
 */
char* CameraControl(char *data, int len);
#endif //_CAMERA_H_
