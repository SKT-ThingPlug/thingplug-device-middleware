#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>

#include "SensorManager.h"
#include "Definitions.h"
#include "SKTDebug.h"
#include "Timer.h"
#include "Definitions.h"
#include "ErrorDefinition.h"
#include "UpdateLogCommand.h"
#include "UpdateDeviceSensorStatus.h"

#include "CUSTOM/buzzer.h"
#include "UART/CM1101.h"
#include "CUSTOM/complex.h"
#include "CUSTOM/custom.h"
#include "GPIO/MC38.h"
#include "UART/PM1001.h"
#include "I2C/htu21d.h"
#include "GPIO/RGB_LED.h"
#include "I2C/bh1750.h"
#include "GPIO/HC_SR501.h"
#include "GPIO/TCACB_147.h"
#include "CUSTOM/number.h"
#include "GPIO/BUT001.h"
#include "CUSTOM/percent.h"
#include "CUSTOM/ph.h"
#include "CUSTOM/pressure.h"
#include "CUSTOM/string.h"
#include "1W/ds18b20.h"
#include "UNDEFINED/undefine.h"
#include "CUSTOM/windvane.h"
#include "CUSTOM/Accelerometer.h"
#include "CUSTOM/Altitude.h"
#include "CUSTOM/BatteryLevel.h"
#include "CUSTOM/BatteryState.h"
#include "CUSTOM/BatteryTemperature.h"
#include "CUSTOM/Camera.h"
#include "CUSTOM/Gravity.h"
#include "CUSTOM/Gyroscope.h"
#include "CUSTOM/Latitude.h"
#include "CUSTOM/Longitude.h"
#include "CUSTOM/MacAddress.h"
#include "CUSTOM/MagneticField.h"
#include "CUSTOM/Orientation.h"
#include "CUSTOM/Proximity.h"
#include "CUSTOM/PrecisionTime.h"
#include "CUSTOM/StepCount.h"
#include "CUSTOM/StepDetector.h"
#include "CUSTOM/TimeStamp.h"
#include "CUSTOM/PiCamera.h"

#include "base_directory.h"

//#define SENSOR_CONFIGURE_FILE_PATH		"./conf/iot_sensor.conf"
#define SENSOR_CONFIGURE_FILE_PATH		BASE_DIR "/conf/iot_sensor.conf"
#define BUF_SIZE 512

DMList gSensorList;
static char DEV_NAME[32] = "";

void SensorPrint(void *data)
{
    SENSOR_T *sensor = (SENSOR_T*)data;
    SKTtpDebugLog(LOG_LEVEL_DEBUG, "sensor:%p", sensor);
    SKTtpDebugLog(LOG_LEVEL_DEBUG, "ID:%s", sensor->mID);
    SKTtpDebugLog(LOG_LEVEL_DEBUG, "Name: %s", sensor->mName);
    SKTtpDebugLog(LOG_LEVEL_DEBUG, "Type: %s", sensor->mType);
    SKTtpDebugLog(LOG_LEVEL_DEBUG, "Read: %s(ms)", sensor->mReadInterval);
    SKTtpDebugLog(LOG_LEVEL_DEBUG, "OPType: %d ", sensor->mOperationType);
    SKTtpDebugLog(LOG_LEVEL_DEBUG, "Max: %d(s)", sensor->mMaxInterval);
    SKTtpDebugLog(LOG_LEVEL_DEBUG, "CTRType: %d", sensor->mControlType);
    SKTtpDebugLog(LOG_LEVEL_DEBUG, "Value: %s", sensor->mValue);
    SKTtpDebugLog(LOG_LEVEL_DEBUG, "Status: %hd", sensor->mStatus);
}

void SensorRelease(void *data)
{
    if( data != NULL) {
        free(data);
    }
}

static unsigned short UpdateSensorState(SENSOR_T *sensor, char *lastValue)
{
	int	len;
	time_t now;
	time(&now);
    pthread_mutex_lock(&sensor->mReadMutex);
	sensor->mOperations.Read(sensor->mValue,&len);
    pthread_mutex_unlock(&sensor->mReadMutex);
	// 센서 문제 발생
	if( strncmp(sensor->mValue, "N/A", strlen("N/A")) == 0) {
		sensor->mValue[strlen("N/A")] = '\0';
		char buffer[128] = "NOTICE : Sensor Driver Error return(N/A) <<";
		strcat(buffer,sensor->mName);
		strcat(buffer,">>");
		MakeUpdateLogMessage(ERROR_TYPE_DEVICE_DISABLED, buffer, sensor->mID);
		return DM_STATUS_NO;		
	}
	// 최근 값과 현재 값이 다르면 시작 시간 초기화
	if( sensor->mStartTime == 0 || strncmp(sensor->mValue, lastValue, strlen(sensor->mValue) ) != 0){
		sensor->mStartTime = now;
	} else {
		// MAX Interval 초과
		if(sensor->mMaxInterval > 0 && now - sensor->mStartTime > sensor->mMaxInterval) {
			return DM_STATUS_NO;
		}
	}
	return DM_STATUS_YES;
}

void ReadCallback(void *parameter)
{
	char lastValue[MAX_STR_LEN] = "";
	SENSOR_T *sensor = (SENSOR_T *)parameter;

	unsigned short preStatus = sensor->mStatus;

	(void)memcpy(lastValue, sensor->mValue, MAX_STR_LEN);
	sensor->mStatus = UpdateSensorState(sensor, lastValue);
	if( sensor->mStatus == DM_STATUS_NO && preStatus != sensor->mStatus) {
		char buffer[128] = "NOTICE : Get Sensor State is [DISABLE] <<";
		strcat(buffer,sensor->mName);
		strcat(buffer,">>");
		MakeUpdateLogMessage(ERROR_TYPE_DEVICE_DISABLED, buffer, sensor->mID);
	}
    SKTtpDebugLog(LOG_LEVEL_DEBUG, "<%s>-Read(%s)", sensor->mName, sensor->mValue);

	if( strncmp(lastValue, sensor->mValue, strlen(sensor->mValue)) == 0) {
		// Sensor value is not updated.
		return;
	}

	if( strncmp(sensor->mType, "motion", strlen("motion") ) == 0 ) {
		SKTtpDebugLog(LOG_LEVEL_INFO,"MOTION DETECTION: <%s>",sensor->mValue);
		UpdateDeviceSensorStatus((void*)sensor);
							
	} else if( strncmp(sensor->mType, "door", strlen("door") ) == 0 ) {
		SKTtpDebugLog(LOG_LEVEL_INFO,"DOOR CHANGED(open[1],close[0]): now -> <%s>",sensor->mValue);
		UpdateDeviceSensorStatus((void*)sensor);
	}
}

void InitSensor(void *inputSensor)
{
	SENSOR_T *sensor = (SENSOR_T *)inputSensor;

	if( strncmp( sensor->mName, "HC_SR501", sizeof("HC_SR501") ) == 0 ) {
		HC_SR501Init(&sensor->mOperations);
	} else if( strncmp( sensor->mName, "DS18B20", sizeof("DS18B20") ) == 0 ) {
		DS18B20Init(&sensor->mOperations);
	} else if( strncmp( sensor->mName, "BH1750", sizeof("BH1750") ) == 0 ) {
		BH1750Init(&sensor->mOperations);
	} else if( strncmp( sensor->mName, "HTU21D", sizeof("HTU21D") ) == 0 ) {
		HTU21DInit(&sensor->mOperations);
	} else if( strncmp( sensor->mName, "BUT001", sizeof("BUT001") ) == 0 ) {
		BUT001Init(&sensor->mOperations);
	} else if( strncmp( sensor->mName, "TCACB_147", sizeof("TCACB_147") ) == 0 ) {
		TCACB_147Init(&sensor->mOperations);
	} else if( strncmp( sensor->mName, "PM1001", sizeof("PM1001") ) == 0 ) {
		PM1001Init(&sensor->mOperations);
	} else if( strncmp( sensor->mName, "CM1101", sizeof("CM1101") ) == 0 ) {
		CM1101Init(&sensor->mOperations);
	} else if( strncmp( sensor->mName, "MC38", sizeof("MC38") ) == 0 ) {
		MC38Init(&sensor->mOperations);
	} else if( strncmp( sensor->mName, "RGB_LED", sizeof("RGB_LED") ) == 0 ) {
		RGB_LEDInit(&sensor->mOperations);
	} else if( strncmp( sensor->mName, "BUZZER", sizeof("BUZZER") ) == 0 ) {
		BUZZERInit(&sensor->mOperations);
	} else if( strncmp( sensor->mName, "PRESSURE", sizeof("PRESSURE") ) == 0 ) {
		PRESSUREInit(&sensor->mOperations);
	} else if( strncmp( sensor->mName, "WINDVANE", sizeof("WINDVANE") ) == 0 ) {
		WINDVANEInit(&sensor->mOperations);
	} else if( strncmp( sensor->mName, "PH", sizeof("PH") ) == 0 ) {
		PHInit(&sensor->mOperations);
	} else if( strncmp( sensor->mName, "PERCENT", sizeof("PERCENT") ) == 0 ) {
		PERCENTInit(&sensor->mOperations);
	} else if( strncmp( sensor->mName, "COMPLEX", sizeof("COMPLEX") ) == 0 ) {
		COMPLEXInit(&sensor->mOperations);
	} else if( strncmp( sensor->mName, "STRING", sizeof("STRING") ) == 0 ) {
		STRINGInit(&sensor->mOperations);
	} else if( strncmp( sensor->mName, "NUMBER", sizeof("NUMBER") ) == 0 ) {
		NUMBERInit(&sensor->mOperations);
	} else if( strncmp( sensor->mName, "CUSTOM", sizeof("CUSTOM") ) == 0 ) {
		CUSTOMInit(&sensor->mOperations);
	} else if( strncmp( sensor->mName, "UNDEFINED", sizeof("UNDEFINED") ) == 0 ) {
		UNDEFINEDInit(&sensor->mOperations);
	} else if( strncmp( sensor->mName, "Accelerometer_X", sizeof("Accelerometer_X") ) == 0 ) {
		AccelerometerInit(&sensor->mOperations,'X');
	} else if( strncmp( sensor->mName, "Accelerometer_Y", sizeof("Accelerometer_Y") ) == 0 ) {
		AccelerometerInit(&sensor->mOperations,'Y');
	} else if( strncmp( sensor->mName, "Accelerometer_Z", sizeof("Accelerometer_Z") ) == 0 ) {
		AccelerometerInit(&sensor->mOperations,'Z');
	} else if( strncmp( sensor->mName, "Altitude", sizeof("Altitude") ) == 0 ) {
		AltitudeInit(&sensor->mOperations);
	} else if( strncmp( sensor->mName, "BatteryLevel", sizeof("BatteryLevel") ) == 0 ) {
		BatteryLevelInit(&sensor->mOperations);
	} else if( strncmp( sensor->mName, "BatteryState", sizeof("BatteryState") ) == 0 ) {
	    BatteryStateInit(&sensor->mOperations);
	} else if( strncmp( sensor->mName, "BatteryTemperature", sizeof("BatteryTemperature") ) == 0 ) {
	    BatteryTemperatureInit(&sensor->mOperations);
	} else if( strncmp( sensor->mName, "Camera", sizeof("Camera") ) == 0 ) {
		CameraInit(&sensor->mOperations);
	} else if( strncmp( sensor->mName, "Gravity_X", sizeof("Gravity_X") ) == 0 ) {
		GravityInit(&sensor->mOperations,'X');
	} else if( strncmp( sensor->mName, "Gravity_Y", sizeof("Gravity_Y") ) == 0 ) {
		GravityInit(&sensor->mOperations,'Y');
	} else if( strncmp( sensor->mName, "Gravity_Z", sizeof("Gravity_Z") ) == 0 ) {
		GravityInit(&sensor->mOperations,'Z');
	} else if( strncmp( sensor->mName, "Gyroscope_X", sizeof("Gyroscope_X") ) == 0 ) {
		GyroscopeInit(&sensor->mOperations,'X');
	} else if( strncmp( sensor->mName, "Gyroscope_Y", sizeof("Gyroscope_Y") ) == 0 ) {
		GyroscopeInit(&sensor->mOperations,'Y');
	} else if( strncmp( sensor->mName, "Gyroscope_Z", sizeof("Gyroscope_Z") ) == 0 ) {
		GyroscopeInit(&sensor->mOperations,'Z');
	} else if( strncmp( sensor->mName, "Latitude", sizeof("Latitude") ) == 0 ) {
		LatitudeInit(&sensor->mOperations);
	} else if( strncmp( sensor->mName, "Longitude", sizeof("Longitude") ) == 0 ) {
		LongitudeInit(&sensor->mOperations);
	} else if( strncmp( sensor->mName, "MacAddress", sizeof("MacAddress") ) == 0 ) {
		MacAddressInit(&sensor->mOperations);
	} else if( strncmp( sensor->mName, "MagneticField_X", sizeof("MagneticField_X") ) == 0 ) {
		MagneticFieldInit(&sensor->mOperations,'X');
	} else if( strncmp( sensor->mName, "MagneticField_Y", sizeof("MagneticField_Y") ) == 0 ) {
		MagneticFieldInit(&sensor->mOperations,'Y');
	} else if( strncmp( sensor->mName, "MagneticField_Z", sizeof("MagneticField_Z") ) == 0 ) {
		MagneticFieldInit(&sensor->mOperations,'Z');
	} else if( strncmp( sensor->mName, "Orientation_X", sizeof("Orientation_X") ) == 0 ) {
		OrientationInit(&sensor->mOperations,'X');
	} else if( strncmp( sensor->mName, "Orientation_Y", sizeof("Orientation_Y") ) == 0 ) {
		OrientationInit(&sensor->mOperations,'Y');
	} else if( strncmp( sensor->mName, "Orientation_Z", sizeof("Orientation_Z") ) == 0 ) {
		OrientationInit(&sensor->mOperations,'Z');
	} else if( strncmp( sensor->mName, "PrecisionTime", sizeof("PrecisionTime") ) == 0 ) {
		PrecisionTimeInit(&sensor->mOperations);
	} else if( strncmp( sensor->mName, "Proximity", sizeof("Proximity") ) == 0 ) {
		ProximityInit(&sensor->mOperations);
	} else if( strncmp( sensor->mName, "StepCount", sizeof("StepCount") ) == 0 ) {
		StepCountInit(&sensor->mOperations);
	} else if( strncmp( sensor->mName, "StepDetector", sizeof("StepDetector") ) == 0 ) {
		StepDetectorInit(&sensor->mOperations);
	} else if( strncmp( sensor->mName, "TimeStamp", sizeof("TimeStamp") ) == 0 ) {
		TimeStampInit(&sensor->mOperations);
	} else if( strncmp( sensor->mName, "PiCamera", sizeof("PiCamera") ) == 0 ) {
		PiCameraInit(&sensor->mOperations);
	}
}

void LoadBasicSensor(void)
{
	SENSOR_T *sensor;
    int sec = 0;
    int nsec = 0;

	sensor = (SENSOR_T *)calloc(1, sizeof(SENSOR_T));

	if( sensor == NULL ) {
		return;
	}
	memcpy(sensor->mID,"0019",sizeof("0019"));
	memcpy(sensor->mName,"CUSTOM",sizeof("CUSTOM"));
	memcpy(sensor->mType,"custom",sizeof("custom"));
	memcpy(sensor->mReadInterval,"5000",sizeof("5000"));
	sensor->mOperationType = DM_SENSOR_PASSIVE_TYPE;
	sensor->mMaxInterval = 100;
	sensor->mControlType = DM_SENSOR_NO_CONTROL_TYPE;
	sensor->mStatus = DM_STATUS_YES;
	CUSTOMInit(&sensor->mOperations);
    sensor->mOperations.Read(sensor->mValue,/*not use*/&sec);
    sec = atoi(sensor->mReadInterval)/1000;	
    nsec = (atoi(sensor->mReadInterval)%1000)*1000000;	
    SetTimer(sec, nsec, 1, &ReadCallback, (void*)sensor);
    DMList_Add(&gSensorList, (void *)sensor);

	sensor = (SENSOR_T *)calloc(1, sizeof(SENSOR_T));
	if( sensor == NULL ) {
		return;
	}
	memcpy(sensor->mID,"0020",sizeof("0020"));
	memcpy(sensor->mName,"UNDEFINED",sizeof("UNDEFINED"));
	memcpy(sensor->mType,"undefined",sizeof("undefined"));
	memcpy(sensor->mReadInterval,"5000",sizeof("5000"));
	sensor->mOperationType = DM_SENSOR_PASSIVE_TYPE;
	sensor->mMaxInterval = 100;
	sensor->mControlType = DM_SENSOR_NO_CONTROL_TYPE;
	sensor->mStatus = DM_STATUS_YES;
	UNDEFINEDInit(&sensor->mOperations);
    sensor->mOperations.Read(sensor->mValue,/*not use*/&sec);
    sec = atoi(sensor->mReadInterval)/1000;	
    nsec = (atoi(sensor->mReadInterval)%1000)*1000000;	
    SetTimer(sec, nsec, 1, &ReadCallback, (void*)sensor);
    DMList_Add(&gSensorList, (void *)sensor);
}

void LoadSensorConfigurations(char *configurationFile)
{
	FILE *pFile;
	char strTemp[BUF_SIZE];

	SKTtpDebugLog(LOG_LEVEL_INFO,"\nskip <%s>",configurationFile);
	pFile = fopen(configurationFile,"r");

	if(pFile == NULL) {
		LoadBasicSensor();	
        DMList_Print(&gSensorList, SensorPrint);
		return;
	}
	
	while(!feof(pFile)) {
		SENSOR_T *sensor;
		char *ptr;
		int length;
		bool validation = false;
		int sec = 0;
		int nsec = 0;

		(void)memset( strTemp, 0, BUF_SIZE);
		fgets( strTemp, BUF_SIZE, pFile );
		length = strlen(strTemp);

		if (length == 0) {
			continue;
		}
		strTemp[length-1] = '\0';
		if( strTemp[0] == '#' ){
			SKTtpDebugLog(LOG_LEVEL_INFO,"\nskip <%s>",strTemp);
			continue;
		}

        if( strTemp[0] == '$' ){
            if( strTemp[1] == 'A' && strTemp[2] == 'L' && strTemp[3] == 'L'){
                ptr = strtok(strTemp, ":\r\n");
                ptr = strtok(NULL, ":\r\n");
                if(ptr == NULL) {
                    goto go_next;
                }
                memcpy( DEV_NAME, ptr, strlen(ptr));
                SKTtpDebugLog(LOG_LEVEL_INFO,"\nEACH-ALL FLAG<%s><%s><%d>",strTemp,DEV_NAME, strlen(DEV_NAME));
                continue;
            }
		}

		SKTtpDebugLog(LOG_LEVEL_INFO,"\n<%s>",strTemp);

		sensor = (SENSOR_T *)calloc(1, sizeof(SENSOR_T));
		if( sensor == NULL ) {
			// memory alloc error
			break;
		}

		ptr = strtok(strTemp, ",\r\n");
		if(ptr == NULL) {
			goto go_next;
		}
		memcpy( sensor->mType, ptr, strlen(ptr));

		ptr = strtok(NULL,",\r\n");
		if(ptr == NULL) {
			goto go_next;
		}
		memcpy( sensor->mID, ptr, strlen(ptr));

		ptr = strtok(NULL,",\r\n");
		if(ptr == NULL) {
			goto go_next;
		}
		memcpy( sensor->mName, ptr, strlen(ptr));

		ptr = strtok(NULL,",\r\n");
		if(ptr == NULL) {
			goto go_next;
		}
		memcpy( sensor->mReadInterval, ptr, strlen(ptr));

		ptr = strtok(NULL,",\r\n");
		if(ptr == NULL) {
			goto go_next;
		}
		sensor->mOperationType = atoi(ptr);

		ptr = strtok(NULL,",\r\n");
		if(ptr == NULL) {
			goto go_next;
		}
		sensor->mMaxInterval = atoi(ptr);

		ptr = strtok(NULL,",\r\n");
		if(ptr == NULL) {
			goto go_next;
		}
		sensor->mControlType = atoi(ptr);

		ptr = strtok(NULL,",\r\n");
		if(ptr == NULL) {
			goto go_next;
		}
        unsigned int tmp;
        sscanf(ptr, "%x", &tmp);
		sensor->TTV_TYPE = (unsigned char)tmp;

		ptr = strtok(NULL,",\r\n");
		if(ptr == NULL) {
			goto go_next;
		}
        sscanf(ptr, "%x", &tmp);
		sensor->TTV_DATATYPE = (unsigned char)tmp;
	
        ptr = strtok(NULL,",\r\n");
		if(ptr == NULL) {
			goto go_next;
		}
		memcpy( sensor->TTV_NAME, ptr, strlen(ptr));

		validation = true;
		InitSensor((void*)sensor);
		sensor->mStatus = DM_STATUS_YES;
        if(sensor->mOperations.Read == NULL) {
            char logMessage[128] = ""; 
            int ret = ERROR_TYPE_DEVICE_DISABLED;
            snprintf(logMessage,128,"SensorName[%s] : Driver not found, >> skip <<<",sensor->mName);
	        SKTtpDebugLog(LOG_LEVEL_ERROR,"\n=============================================\nSensorName[%s] : Driver not found, >> skip <<<\n============================================",sensor->mName);
            MakeUpdateLogMessage(ret, logMessage, sensor->mName);
			goto go_next;
        }
		sensor->mOperations.Read(sensor->mValue,/*not use*/&sec);
		sec = atoi(sensor->mReadInterval)/1000;	
		nsec = (atoi(sensor->mReadInterval)%1000)*1000000;	
		SetTimer(sec, nsec, 1, &ReadCallback, (void*)sensor);
        DMList_Add(&gSensorList, (void *)sensor);
go_next:		
		if( validation == false ) {
			free(sensor);
		}
	}

	fclose( pFile );

	if( gSensorList.count == 0 ) { 
		LoadBasicSensor();	
	}

    DMList_Print(&gSensorList, SensorPrint);
}



void SensorManagerInit(void)
{
    SKTtpDebugLog(LOG_LEVEL_INFO,"SensorManagerInit");
    DM_TimerInit();
    DMList_Init(&gSensorList, SensorRelease); 
    LoadSensorConfigurations(SENSOR_CONFIGURE_FILE_PATH);
}

void SensorManagerClose(void)
{
	SKTtpDebugLog(LOG_LEVEL_INFO,"SensorManagerClose");
	DM_TimerTerm();
    DMList_Close(&gSensorList);
}

char *GetDevName(void)
{
    return DEV_NAME;
}
