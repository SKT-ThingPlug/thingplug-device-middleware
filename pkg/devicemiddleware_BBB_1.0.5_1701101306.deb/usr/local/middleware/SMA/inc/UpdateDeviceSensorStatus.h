/**
 * @file UpdateDeviceSensorStatus.h
 *
 * @brief Update device sensor status command header
 *
 * Copyright (C) 2016. SK Telecom, All Rights Reserved.
 * Written 2016, by SK Telecom
 */

#ifndef __UPDATE_DEVICE_SENSOR_STATUS_H__
#define __UPDATE_DEVICE_SENSOR_STATUS_H__

#include "BaseCommand.h"

/*
 ****************************************
 * Public Functions
 ****************************************
 */
int UpdateDeviceSensorStatus(void *inputSensor);
int UpdateDeviceSensorStatusCommandProcess(SKTRECEIVE_MESSAGE_T *receiveMessage);
int UpdateSensorHandlerStatusCommandProcess(SKTRECEIVE_MESSAGE_T *receiveMessage, char* logMessage);
#endif /* __UPDATE_DEVICE_SENSOR_STATUS_H__*/
