/*
 * @file MC38.h
 *
 * @brief MC38 DOOR Sensor handler header
 *
 * Copyright (C) 2016. SK Telecom, All Rights Reserved.
 * Written 2016, by SK Telecom
 */

#ifndef _MC38_H_
#define _MC38_H_

/*
 ****************************************
 * Enumerations
 ****************************************
 */


/*
 ****************************************
 * Major Functions
 ****************************************
 */

/**
 * @brief MC38 device init function
 * @param[in] No parameter
 * @return	 0 => Success init
 * 		-1 => Error file open
 */
int MC38Init(void* ops);

/**
 * @brief MC38 device DOOR value read funciton
 * @param[in]  structure member mLastValue pointer
 * @return	 0 => Success read data
 * 		-1 => Error ioctl operation
 * 		-2 => Error write operation
 * 		-3 => Error read operation
 */
int MC38Read(char *data, int *len);

/**
 * @brief MC38 device close funciton
 * @param[in] No parameter
 * @return 0 = default
 */
int MC38Close(void);


#endif //_MC38_H_
