/*
 * @file htu21d.h
 *
 * @brief Humidity Sensor handler header
 *
 * Copyright (C) 2016. SK Telecom, All Rights Reserved.
 * Written 2016, by SK Telecom 
 */

#ifndef _HTU21D_H_
#define _HTU21D_H_

/*
 **************************************** 
 * Enumerations
 **************************************** 
 */


/*
 **************************************** 
 * Major Functions
 **************************************** 
 */

/**
 * @brief HTU21D device init function
 * @param[in] No parameter
 * @return	 0 => Success init
 * 		-1 => Error file open 
 */
int HTU21DInit(void *ops);

/**
 * @brief HTU21D device humidity value read funciton
 * @param[in]  structure member mLastValue pointer
 * @return	 0 => Success read data
 * 		-1 => Error ioctl operation 
 * 		-2 => Error write operation 
 * 		-3 => Error read operation 
 */
int HTU21DRead(char *data, int *len);

/**
 * @brief HTU21D device close funciton
 * @param[in] No parameter
 * @return 0 = default
 */
int HTU21DClose(void);


#endif //_HTU21D_H_
