/*
 * @file complex.h
 *
 * @brief COMPLEX Sensor handler header
 *
 * Copyright (C) 2016. SK Telecom, All Rights Reserved.
 * Written 2016, by SK Telecom
 */

#ifndef _COMPLEX_H_
#define _COMPLEX_H_

/*
 ****************************************
 * Enumerations
 ****************************************
 */


/*
 ****************************************
 * Major Functions
 ****************************************
 */

/**
 * @brief COMPLEX device init function
 * @param[in] No parameter
 * @return	 0 => Success init
 * 		-1 => Error file open
 */
int COMPLEXInit(void);

/**
 * @brief COMPLEX device button value read funciton
 * @param[in]  structure member mLastValue pointer
 * @return	 0 => Success read data
 * 		-1 => Error ioctl operation
 * 		-2 => Error write operation
 * 		-3 => Error read operation
 */
int COMPLEXRead(char *data, int *len);

/**
 * @brief COMPLEX device close funciton
 * @param[in] No parameter
 * @return 0 = default
 */
int COMPLEXClose(void);


#endif //_COMPLEX_H_
