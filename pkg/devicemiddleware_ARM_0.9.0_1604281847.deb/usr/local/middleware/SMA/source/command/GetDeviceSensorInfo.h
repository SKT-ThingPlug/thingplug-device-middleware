/**
 * @file GetDeviceSensorInfo.h
 *
 * @brief Get device sensor information command header
 *
 * Copyright (C) 2015. SPTek,All Rights Reserved.
 * Written 2015,by SPTek
 */

#ifndef __GET_DEVICE_SENSOR_INFO_H__
#define __GET_DEVICE_SENSOR_INFO_H__

#include "BaseCommand.h"

/*
 ****************************************
 * Public Functions
 ****************************************
 */
int GetDeviceSensorInfoCommandProcess(SPTekRECEIVE_MESSAGE_T *receiveMessage, char *contents, int length, SPTekSEND_MESSAGE_T *sendMessage);

#endif /* __GET_DEVICE_SENSOR_INFO_H__ */

