#include<stdio.h>
#include<string.h>    //strlen
#include <stdlib.h>  // rand(), srand()
#include <time.h>    // time()
#include "aes.h"
#include "aes_utils.h"

unsigned int seed; //to avoid it ganerate same key value at the same time zone.

/**
 * \brief          arrange length to 16 drainage.
 *
 * \param length   characters length
 *
 * \return int     16 drainage
 */
int aes_utils_make16Drainage(int length){
	int cnt = length % 16;
	if(cnt == 0){
		cnt = 16;
	}
	return length + 16 - cnt;
}

/**
 * \brief          Generate random key
 *
 * \param keybits  must be 128, 192 or 256
 *
 * \return char*   key
 */
unsigned char* aes_utils_generateKey(int keybits)
{
	// * avoid invalid key bit length * //
	if(keybits != 128 && keybits && 192 && keybits != 256 ){
		keybits = 128;
	}

	if(seed > 429515716){ // 429515716 is random number
		seed = 1; //1 is just random number
	}
	seed = seed + 13; // 13 is just random number

    // * generate a key with a given length * //
    char aes_key[keybits/8 +1];
	
    memset(aes_key, 0, keybits/8 +1);

	int i, r;
	srand(time(NULL) - seed);
	for (i = 0; i < sizeof(aes_key); i++) {
		r = rand() % 3;
		if(r == 0){
			aes_key[i] = rand() %  10 + 48; //num
		}else if(r == 1){
			aes_key[i] = rand() %  26 + 65; //capital
		}else if(r == 2){
			aes_key[i] = rand() %  26 + 97; // small letter
		}
	}

	//printf("key:\t");
    //for(i=0;i < keybits/8;i++)
    //   printf("%X ",*(_key+i));
    //printf("\n");
	
	return (unsigned char*) strndup(aes_key, 16);
}

/**
 * \brief          AES-CBC buffer encryption/decryption
 *                 Length should be a multiple of the block
 *                 size (16 bytes)
 *
 * \note           Upon exit, the content of the IV is updated so that you can
 *                 call the function same function again on the following
 *                 block(s) of data and get the same result as if it was
 *                 encrypted in one call. This allows a "streaming" usage.
 *                 If on the other hand you need to retain the contents of the
 *                 IV, you should either save it manually or use the cipher
 *                 module instead.
 *
 * \param ctx      AES context
 * \param mode     MBEDTLS_AES_ENCRYPT or MBEDTLS_AES_DECRYPT
 * \param length   length of the input data
 * \param iv       initialization vector (updated after use)
 * \param input    buffer holding the input data
 * \param output   buffer holding the output data
 *
 * \return         0 if successful, or MBEDTLS_ERR_AES_INVALID_INPUT_LENGTH
 */
int aes_utils_cbc( mbedtls_aes_context *ctx,
			int mode,
			size_t length,
			unsigned char iv[16],
			const unsigned char *input,
			unsigned char *output ){

	int len = aes_utils_make16Drainage(length);
	//printf("length %d", length);
	mbedtls_aes_crypt_cbc( ctx,  mode, len, iv, input, output );
	return( 0 );
}

/**
 * \brief          AES-ECB block encryption/decryption
 *
 * \param ctx      AES context
 * \param mode     MBEDTLS_AES_ENCRYPT or MBEDTLS_AES_DECRYPT
 * \param input    16-byte input block
 * \param output   16-byte output block
 *
 * \return         0 if successful
 */
int aes_utils_ecb( mbedtls_aes_context *ctx,
                    int mode,
					size_t length, 
                    const unsigned char *input,
                    unsigned char *output )
{
	#if defined(MBEDTLS_AESNI_C) && defined(MBEDTLS_HAVE_X86_64)
		if( mbedtls_aesni_has_support( MBEDTLS_AESNI_AES ) )
			return( mbedtls_aesni_crypt_ecb( ctx, mode, tempInput, tempOutput ) );
	#endif

	#if defined(MBEDTLS_PADLOCK_C) && defined(MBEDTLS_HAVE_X86)
		if( aes_padlock_ace )
		{
			if( mbedtls_padlock_xcryptecb( ctx, mode, tempInput, tempOutput ) == 0 )
				return( 0 );

			// If padlock data misaligned, we just fall back to
			// unaccelerated mode
		}
	#endif

	unsigned char tempInput[17] = {0,};
	unsigned char tempOutput[17] = {0,};

	int sum = 0;
	while(length > sum){
		memcpy(tempInput, &input[sum], 16);
		bzero(tempOutput, 16);


		if( mode == MBEDTLS_AES_ENCRYPT )
			mbedtls_aes_encrypt( ctx, tempInput, tempOutput );
		else
			mbedtls_aes_decrypt( ctx, tempInput, tempOutput );
		
		memcpy(&output[sum], tempOutput, 16);
		sum = sum + 16;
		//printf("output %s\n", output);
	}

    return( 0 );
	
}


/**
 * Convert Hex to Ascii code.
 */
void hexToAscii(char *in, int len, char* out)
{
	int i;
	for(i = 0; i<len; i++) {
		sprintf(&out[i*2], "%02X", in[i]);
	}
}

/**
 * Convert Ascii to Hex code.
 */
void asciiToHex(char *in, int len, char* out)
{
	unsigned int i, t, hn, ln;

	for (t = 0,i = 0; i < len; i+=2,++t) {
		hn = in[i] > '9' ? (in[i]|32) - 'a' + 10 : in[i] - '0';
		ln = in[i+1] > '9' ? (in[i+1]|32) - 'a' + 10 : in[i+1] - '0';

		out[t] = (hn << 4 ) | ln;
		// if(out[len-1]=='\n') {
		// 	out[--len] = '\0';
		// }
	}
	// out[t] = '\0';
}
