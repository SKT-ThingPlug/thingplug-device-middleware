/**
 * @file undefine.c
 *
 * @brief UNDEFINED Sensor Device Handler
 *
 * Copyright (C) 2016. SK Telecom, All Rights Reserved.
 * Written 2016, by SK Telecom
 */
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <string.h>
#include "undefine.h"
#include "SensorManager.h"



#include "1W/ds18b20.h"
#include "I2C/htu21d.h"
#include "I2C/bh1750.h"

#define MAX_LEN_LAST_VALUE  128

/*
 ****************************************
 * UNDEFINED device Main Handle Functions
 ****************************************
 */

/**
 * @brief UNDEFINED device init function
 * @param[in] No parameter
 * @return	 0 => Success init
 * 		-1 => Error file open
 */
int UNDEFINEDInit(void *ops)
{
	SENSOR_OPERATIONS_T *operations = (SENSOR_OPERATIONS_T *)ops;

	operations->Read = UNDEFINEDRead;
	operations->Close = UNDEFINEDClose;
	operations->Control = NULL;
	return 0;
}


/**
 * @brief UNDEFINED device UNDEFINED value read funciton
 * @param[in]  structure member mLastValue pointer
 * @return	 0 => Success read data
 * 		-3 => Error read operation
 * 		-4 => Error lseek operation
 */
int UNDEFINEDRead(char *data, int *len)
{
//	int	 tot_len = 0;
	char sdata[MAX_LEN_LAST_VALUE+1];

	memset(sdata, 0x00, 126);
	data[0] = '\0';
	strcat(data, "UNDEFINED:");
	strcat(data, "undefined;");
/*
	// Temp
	DS18B20Read(sdata, len);
	strcat(data, "temperature:");
	strcat(data, sdata);
	strcat(data, ";");

	// Light
	BH1750Read(sdata, len);
	strcat(data, "light:");
	strcat(data, sdata);
	strcat(data, ";");

	// Humi
	HTU21DRead(sdata, len);
	strcat(data, "humidity:");
	strcat(data, sdata);*/

	*len = strlen(data);

	return 0;
}




/**
 * @brief UNDEFINED device close funciton
 * @param[in] No parameter
 * @return 0 = default
 */
int UNDEFINEDClose(void)
{

	HTU21DClose();
	DS18B20Close();
	BH1750Close();

	return 0;
}

/**
 * @brief UNDEFINED Extract UNDEFINED value
 * @param[in] Raw Data
 * @return 0 = UNDEFINED Value
 */
int getUNDEFINEDValue(char *data)
{
	return 0;
}
